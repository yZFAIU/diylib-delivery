// Tweak.xm — diylib 入口
// 版本 26.0.1 / 名称 NPC / 作者 yZFAIU
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入
//
// 修复要点：
//   原实现在 cellForRowAtIndexPath: 里调用 [self tableView:numberOfRowsInSection:]
//   会触发 orig，orig 可能回调 cellForRowAtIndexPath: 形成递归栈溢出。
//   改为：在 viewDidLoad 缓存原始 section 行数到 ivar（通过关联对象），
//   numberOfRowsInSection: 直接 orig+1，cellForRowAtIndexPath: 用缓存的 orig 行数判断
//   是否为追加的 NPC 入口行，不再回调 numberOfRowsInSection:。

// 关联对象 key
static const void *NPCOrigRowCountKey = &NPCOrigRowCountKey;
static const void *NPCEntryEnabledKey = &NPCEntryEnabledKey;

%hook SettingViewController

- (void)viewDidLoad {
    %orig;
    // 总开关关闭时也注入入口（便于用户重新启用），但行数处理需统一
    objc_setAssociatedObject(self, NPCEntryEnabledKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UITableView *tv = nil;
        @try { tv = [self valueForKey:@"m_tableView"]; } @catch (__unused id e) {}
        if (tv) {
            [tv reloadData];
        }
    });
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    // 缓存原始行数
    objc_setAssociatedObject(self, NPCOrigRowCountKey, @(orig), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if ([DPConfig boolForSwitchKey:kSwitchEnabled]) {
        orig += 1;
    }
    return orig;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // 用缓存的原始行数判断，不再回调 numberOfRowsInSection: 避免递归
    NSNumber *cached = objc_getAssociatedObject(self, NPCOrigRowCountKey);
    NSInteger origCount = cached ? cached.integerValue : -1;
    if (origCount >= 0 && [DPConfig boolForSwitchKey:kSwitchEnabled] && indexPath.row == origCount) {
        static NSString *idt = @"NPCEntryCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idt];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idt];
        }
        cell.textLabel.text = @"NPC";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
    // 未缓存或非 NPC 入口行：走原生。numberOfRowsInSection: 必然先于本方法调用，
    // 此时 cached 已存在；若 cached 仍为 nil（极端时序），indexPath.row < origCount 不成立，
    // 也会安全走到 %orig。
    return %orig;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSNumber *cached = objc_getAssociatedObject(self, NPCOrigRowCountKey);
    NSInteger origCount = cached ? cached.integerValue : -1;
    if (origCount >= 0 && [DPConfig boolForSwitchKey:kSwitchEnabled] && indexPath.row == origCount) {
        DPPreferencesListController *vc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:vc animated:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    }
    %orig;
}
%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。
// migrateDefaults 已在 DPConfig +load 中调用，这里再调一次是幂等保险。
__attribute__((constructor))
static void diylibEntry(void) {
    @autoreleasepool {
        DPLogInfo(@"diylib v26.0.1 (NPC) by yZFAIU loaded into WeChat");
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        // 安装 AddMsg 集中分发器（幂等，只 hook 一次）。
        // 各模块在自身 +load 中按开关决定是否订阅分发器或独立 hook 自己的目标方法。
        // 注意：模块 +load 早于 constructor 执行，订阅先于 install，时序正确。
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
