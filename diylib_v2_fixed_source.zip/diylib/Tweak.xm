// Tweak.xm — diylib 入口
// 版本 26.0.1 / 名称 NPC / 作者 yZFAIU
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入
//
// 修复要点：
//   原实现在 cellForRowAtIndexPath: 里调用 [self tableView:numberOfRowsInSection:]
//   会触发 orig，orig 可能回调 cellForRowAtIndexPath: 形成递归栈溢出。
//   改为：在 viewDidLoad 缓存原始 section 行数到 ivar（通过关联对象），
//   numberOfRowsInSection: 直接 orig+1，cellForRowAtIndexPath: 用缓存的 orig 行数判断
//   是否为追加的 NPC 入口行，不再回调 numberOfRowsInSection:。

// 关联对象 key
static const void *NPCEntryEnabledKey = &NPCEntryEnabledKey;
static const void *NPCSectionCountKey = &NPCSectionCountKey;
static const void *NPCRowsCacheKey    = &NPCRowsCacheKey;

%hook SettingViewController

// 递归在视图树里找 UITableView，避免依赖具体 ivar 名（m_tableView / tableView / _tableView）。
static UITableView *npc_findTableView(UIView *view) {
    if ([view isKindOfClass:[UITableView class]]) return (UITableView *)view;
    for (UIView *sub in view.subviews) {
        UITableView *t = npc_findTableView(sub);
        if (t) return t;
    }
    return nil;
}

- (void)viewDidLoad {
    %orig;
    // 入口始终注入（不受总开关控制，方便用户随时打开设置面板）
    objc_setAssociatedObject(self, NPCEntryEnabledKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    // 延迟 reload：等微信自身把表格搭好后再刷新一次，确保我们的 +1 行被渲染出来
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try {
            UITableView *tv = npc_findTableView(self.view);
            if (tv) [tv reloadData];
        } @catch (__unused id e) {}
    });
}

// 每次页面出现也强制刷新一次，最大化入口可见性（reloadData 幂等，安全）
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try {
        UITableView *tv = npc_findTableView(self.view);
        if (tv) [tv reloadData];
    } @catch (__unused id e) {}
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    // 缓存每个 section 的原始行数（供 cellForRow/didSelect 判断 NPC 行）
    NSMutableDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    if (!rows) {
        rows = [NSMutableDictionary dictionary];
        objc_setAssociatedObject(self, NPCRowsCacheKey, rows, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    rows[@(section)] = @(orig);
    // 仅最后一个 section 追加一行 NPC 入口（避免给每个 section 都加幽灵行）
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    if (total > 0 && section == total - 1) {
        orig += 1;
    }
    return orig;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    NSDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    NSInteger lastSection = total - 1;
    NSNumber *lastRows = rows ? rows[@(lastSection)] : nil;
    NSInteger origLast = lastRows ? lastRows.integerValue : -1;
    if (total > 0 && indexPath.section == lastSection && origLast >= 0 && indexPath.row == origLast) {
        static NSString *idt = @"NPCEntryCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idt];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idt];
        }
        cell.textLabel.text = @"NPC 设置";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
    return %orig;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    NSDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    NSInteger lastSection = total - 1;
    NSNumber *lastRows = rows ? rows[@(lastSection)] : nil;
    NSInteger origLast = lastRows ? lastRows.integerValue : -1;
    if (total > 0 && indexPath.section == lastSection && origLast >= 0 && indexPath.row == origLast) {
        DPPreferencesListController *vc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:vc animated:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    }
    %orig;
}

%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。
// migrateDefaults 已在 DPConfig +load 中调用，这里再调一次是幂等保险。
__attribute__((constructor))
static void diylibEntry(void) {
    @autoreleasepool {
        DPLogInfo(@"diylib v26.0.1 (NPC) by yZFAIU loaded into WeChat");
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        // 安装 AddMsg 集中分发器（幂等，只 hook 一次）。
        // 各模块在自身 +load 中按开关决定是否订阅分发器或独立 hook 自己的目标方法。
        // 注意：模块 +load 早于 constructor 执行，订阅先于 install，时序正确。
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
