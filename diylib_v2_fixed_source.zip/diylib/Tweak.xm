// Tweak.xm — diylib 入口
// 版本 26.0.1 / 名称 NPC / 作者 yZFAIU
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入
//
// 修复要点：
//   原实现在 cellForRowAtIndexPath: 里调用 [self tableView:numberOfRowsInSection:]
//   会触发 orig，orig 可能回调 cellForRowAtIndexPath: 形成递归栈溢出。
//   改为：在 viewDidLoad 缓存原始 section 行数到 ivar（通过关联对象），
//   numberOfRowsInSection: 直接 orig+1，cellForRowAtIndexPath: 用缓存的 orig 行数判断
//   是否为追加的 NPC 入口行，不再回调 numberOfRowsInSection:。

// 关联对象 key
static const void *NPCSectionCountKey = &NPCSectionCountKey;
static const void *NPCRowsCacheKey    = &NPCRowsCacheKey;

// 递归在视图树里找 UITableView，避免依赖具体 ivar 名（m_tableView / tableView / _tableView）。
static UITableView *npc_findTableView(UIView *view) {
    if ([view isKindOfClass:[UITableView class]]) return (UITableView *)view;
    for (UIView *sub in view.subviews) {
        UITableView *t = npc_findTableView(sub);
        if (t) return t;
    }
    return nil;
}

// 入口逻辑抽成共享 helper，供 SettingViewController / NewSettingViewController 复用。
static void npc_cacheRows(id self, NSInteger section, NSInteger orig) {
    NSMutableDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    if (!rows) {
        rows = [NSMutableDictionary dictionary];
        objc_setAssociatedObject(self, NPCRowsCacheKey, rows, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    rows[@(section)] = @(orig);
}

// 仅在最后一个 section 末尾追加一行（避免每个 section 都加幽灵行/越界）。
static NSInteger npc_adjustedRowCount(id self, NSInteger orig, NSInteger section) {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    if (total > 0 && section == total - 1) orig += 1;
    return orig;
}

// 是否命中我们追加的 NPC 入口行。
static BOOL npc_isEntry(id self, NSInteger section, NSInteger row) {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    NSDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    NSInteger lastSection = total - 1;
    NSNumber *lastRows = rows ? rows[@(lastSection)] : nil;
    NSInteger origLast = lastRows ? lastRows.integerValue : -1;
    return (total > 0 && section == lastSection && origLast >= 0 && row == origLast);
}

static UITableViewCell *npc_entryCell(UITableView *tv) {
    static NSString *idt = @"NPCEntryCell";
    UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:idt];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idt];
    }
    cell.textLabel.text = @"NPC 设置";
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

static void npc_openSettings(id self, UITableView *tv, NSIndexPath *ip) {
    UIViewController *vcSelf = (UIViewController *)self;
    DPPreferencesListController *vc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
    [vcSelf.navigationController pushViewController:vc animated:YES];
    [tv deselectRowAtIndexPath:ip animated:YES];
}

// 同时为 SettingViewController 与 NewSettingViewController 生成入口注入，
// 覆盖不同微信版本的“我”页类名（经 MiYou 原版二进制确认 SettingViewController 为目标类，
// 但部分版本“我”页为 NewSettingViewController，两者都 hook 以最大化兼容）。
// 两处逻辑完全一致，均由上面的共享 C helper 实现，无重复。

%hook SettingViewController
- (void)viewDidLoad {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
    });
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    npc_cacheRows(self, section, orig);
    return npc_adjustedRowCount(self, orig, section);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(self, tableView, indexPath); return; }
    %orig;
}
%end

%hook NewSettingViewController
- (void)viewDidLoad {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
    });
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    npc_cacheRows(self, section, orig);
    return npc_adjustedRowCount(self, orig, section);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(self, tableView, indexPath); return; }
    %orig;
}
%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。
// migrateDefaults 已在 DPConfig +load 中调用，这里再调一次是幂等保险。
__attribute__((constructor))
static void diylibEntry(void) {
    @autoreleasepool {
        DPLogInfo(@"diylib v26.0.1 (NPC) by yZFAIU loaded into WeChat");
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        // 安装 AddMsg 集中分发器（幂等，只 hook 一次）。
        // 各模块在自身 +load 中按开关决定是否订阅分发器或独立 hook 自己的目标方法。
        // 注意：模块 +load 早于 constructor 执行，订阅先于 install，时序正确。
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
