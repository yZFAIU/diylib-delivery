// Tweak.xm — diylib 入口
// 版本 26.0.1 / 名称 NPC / 作者 yZFAIU
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入（多版本 / 多数据源兼容）

// 修复要点（针对微信 8.0.x，尤其 8.0.76）：
//   1) 旧版“我”页：ViewController 自身就是 UITableViewDataSource
//      （MiYou 原版即 hook SettingViewController 的 table 方法，已验证可用）。
//   2) 新版“我”页（NewSettingViewController）：表格 dataSource 是 MMTableViewInfo /
//      WCTableViewManager，ViewController 并不是 dataSource，所以只 hook VC 的
//      table 方法永远不生效 —— 这正是之前“入口不出现”的根因。
//      => 必须同时 hook MMTableViewInfo / WCTableViewManager，并按 tableView.delegate
//         的类名判断当前表是否属于“我”页。
//   3) 微信对未知 indexPath 的 tableView:heightForRowAtIndexPath: 会返回 0，导致追加行
//      高度为零、肉眼不可见。=> 必须为追加行返回固定高度（56pt）。
//
// 因此注入采用“双层”：
//   A) ViewController 层（SettingViewController / NewSettingViewController / MoreViewController）
//      覆盖“VC 即 dataSource”的旧版/部分版本。
//   B) 数据源层（MMTableViewInfo / WCTableViewManager）覆盖“数据源独立”的新版。
//   两层共用下方 C helper，互不冲突（不同对象实例）。

// 关联对象 key
static const void *NPCSectionCountKey = &NPCSectionCountKey;
static const void *NPCRowsCacheKey    = &NPCRowsCacheKey;

// 入口行高度（与微信“我”页单元格一致）
static const CGFloat NPCEntryRowHeight = 56.0f;

// 递归在视图树里找 UITableView，避免依赖具体 ivar 名（m_tableView / tableView / _tableView）。
static UITableView *npc_findTableView(UIView *view) {
    if ([view isKindOfClass:[UITableView class]]) return (UITableView *)view;
    for (UIView *sub in view.subviews) {
        UITableView *t = npc_findTableView(sub);
        if (t) return t;
    }
    return nil;
}

// 缓存某 section 的原始行数到关联对象。
static void npc_cacheRows(id self, NSInteger section, NSInteger orig) {
    NSMutableDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    if (!rows) {
        rows = [NSMutableDictionary dictionary];
        objc_setAssociatedObject(self, NPCRowsCacheKey, rows, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    rows[@(section)] = @(orig);
}

// 仅在最后一个 section 末尾追加一行（避免每个 section 都加幽灵行/越界）。
static NSInteger npc_adjustedRowCount(id self, NSInteger orig, NSInteger section) {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    if (total > 0 && section == total - 1) orig += 1;
    return orig;
}

// 是否命中我们追加的 NPC 入口行。
static BOOL npc_isEntry(id self, NSInteger section, NSInteger row) {
    NSNumber *secNum = objc_getAssociatedObject(self, NPCSectionCountKey);
    NSInteger total = secNum ? secNum.integerValue : -1;
    NSDictionary *rows = objc_getAssociatedObject(self, NPCRowsCacheKey);
    NSInteger lastSection = total - 1;
    NSNumber *lastRows = rows ? rows[@(lastSection)] : nil;
    NSInteger origLast = lastRows ? lastRows.integerValue : -1;
    return (total > 0 && section == lastSection && origLast >= 0 && row == origLast);
}

// 判断某 UITableView 是否属于“我”页。
// 微信不同版本里，“我”页表格的 delegate 可能是 ViewController 本身，
// 也可能与 dataSource 同为 MMTableViewInfo。因此：
//   1) 先看 delegate 是否已知“我”页 VC；
//   2) 否则沿 responder 链向上找到所属的 UIViewController，再判断其类。
static BOOL npc_classIsMePageVC(Class c) {
    if (!c) return NO;
    return c == [SettingViewController class] ||
           c == [NewSettingViewController class] ||
           c == [MoreViewController class];
}

static BOOL npc_isMePageTableView(UITableView *tv) {
    if (!tv) return NO;
    // 快速路径：delegate 即“我”页 VC
    id del = tv.delegate;
    if (del && npc_classIsMePageVC(object_getClass(del))) return YES;
    // 兜底：沿 responder 链找到所属 VC（覆盖 delegate 也是数据源的情况）
    UIResponder *r = tv;
    while (r) {
        if ([r isKindOfClass:[UIViewController class]] && npc_classIsMePageVC(object_getClass(r)))
            return YES;
        r = r.nextResponder;
    }
    return NO;
}

static UITableViewCell *npc_entryCell(UITableView *tv) {
    static NSString *idt = @"NPCEntryCell";
    UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:idt];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idt];
    }
    cell.textLabel.text = @"NPC 设置";
    cell.textLabel.textColor = [UIColor labelColor];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

static void npc_openSettings(UITableView *tv, NSIndexPath *ip) {
    // 从 tableView 的 responder 链找到所属 VC（数据源是 MMTableViewInfo 时 self 不是 VC）。
    UIResponder *r = tv;
    UIViewController *vcSelf = nil;
    while (r) {
        if ([r isKindOfClass:[UIViewController class]]) { vcSelf = (UIViewController *)r; break; }
        r = r.nextResponder;
    }
    if (!vcSelf && tv.delegate && [tv.delegate isKindOfClass:[UIViewController class]])
        vcSelf = (UIViewController *)tv.delegate;
    if (!vcSelf) return;
    DPPreferencesListController *vc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
    [vcSelf.navigationController pushViewController:vc animated:YES];
    if (tv && ip) { @try { [tv deselectRowAtIndexPath:ip animated:YES]; } @catch (__unused id e) {} }
}

#pragma mark - 兜底：浮动按钮（仅当表格入口未出现时才显示）

// 浮动按钮的点击目标：打开设置页。
@interface NPCFloatingTarget : NSObject
- (void)npcFloatingTap:(UIButton *)sender;
@end
@implementation NPCFloatingTarget
- (void)npcFloatingTap:(UIButton *)sender {
    UINavigationController *nav = objc_getAssociatedObject(sender, "npc_nav");
    if (nav) {
        DPPreferencesListController *vc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
        [nav pushViewController:vc animated:YES];
    }
}
@end
static NPCFloatingTarget *npc_floatTarget(void) {
    static NPCFloatingTarget *t;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ t = [[NPCFloatingTarget alloc] init]; });
    return t;
}

// 入口是否已通过表格行可见：直接问数据源“我”页最后一行的 cell 文本。
static BOOL npc_mePageEntryVisible(UITableView *tv) {
    @try {
        if (!tv || !tv.dataSource) return NO;
        NSInteger nsec = [tv numberOfSections];
        if (nsec <= 0) return NO;
        NSInteger nrow = [tv numberOfRowsInSection:nsec - 1];
        if (nrow <= 0) return NO;
        NSIndexPath *ip = [NSIndexPath indexPathForRow:nrow - 1 inSection:nsec - 1];
        UITableViewCell *c = [tv.dataSource tableView:tv cellForRowAtIndexPath:ip];
        return [c.textLabel.text isEqualToString:@"NPC 设置"];
    } @catch (__unused id e) { return NO; }
}

// 在“我”页出现后延迟检查：若表格入口没出现，则放一个浮动按钮兜底。
static void npc_ensureEntryAccessible(UIViewController *vc) {
    if (!vc || !vc.view) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try {
            if ([vc.view viewWithTag:8899]) return;               // 已存在，避免重复
            UITableView *tv = npc_findTableView(vc.view);
            if (npc_mePageEntryVisible(tv)) return;               // 表格入口已可见，无需兜底
            UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
            b.tag = 8899;
            CGFloat w = 60, h = 60;
            CGFloat x = vc.view.bounds.size.width - w - 16;
            CGFloat y = vc.view.bounds.size.height - h - 100;     // 浮在标签栏之上
            b.frame = CGRectMake(x, y, w, h);
            b.backgroundColor = [UIColor colorWithRed:0.0 green:0.48 blue:1.0 alpha:0.92];
            [b setTitle:@"NPC" forState:UIControlStateNormal];
            b.titleLabel.font = [UIFont boldSystemFontOfSize:15];
            [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            b.layer.cornerRadius = w / 2;
            b.layer.masksToBounds = YES;
            b.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin;
            if (vc.navigationController)
                objc_setAssociatedObject(b, "npc_nav", vc.navigationController, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [b addTarget:npc_floatTarget() action:@selector(npcFloatingTap:) forControlEvents:UIControlEventTouchUpInside];
            [vc.view addSubview:b];
        } @catch (__unused id e) {}
    });
}

#pragma mark - A) ViewController 层（VC 即 dataSource 的旧版 / 部分版本）

// 三个“我”页候选 VC 共用同一套 hook 逻辑，仅类名不同。
// 这里用宏把重复代码降到最低（Logos 的 %hook 不支持 C 宏展开类名，
// 所以下面显式写出三个 %hook 块，但每个块只调用上面的共享 C helper）。

// ---- SettingViewController ----
%hook SettingViewController
- (void)viewDidLoad {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
    });
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
}
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_ensureEntryAccessible((UIViewController *)self);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    npc_cacheRows(self, section, orig);
    return npc_adjustedRowCount(self, orig, section);
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return NPCEntryRowHeight;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(tableView, indexPath); return; }
    %orig;
}
%end

// ---- NewSettingViewController（8.0.x “我”页，常见类名）----
%hook NewSettingViewController
- (void)viewDidLoad {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
    });
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
}
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_ensureEntryAccessible((UIViewController *)self);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    npc_cacheRows(self, section, orig);
    return npc_adjustedRowCount(self, orig, section);
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return NPCEntryRowHeight;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(tableView, indexPath); return; }
    %orig;
}
%end

// ---- MoreViewController（更早期“我”页类名，兜底）----
%hook MoreViewController
- (void)viewDidLoad {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
    });
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    @try { UITableView *tv = npc_findTableView(self.view); if (tv) [tv reloadData]; } @catch (__unused id e) {}
}
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_ensureEntryAccessible((UIViewController *)self);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger n = %orig;
    objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    return n;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger orig = %orig;
    npc_cacheRows(self, section, orig);
    return npc_adjustedRowCount(self, orig, section);
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return NPCEntryRowHeight;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(tableView, indexPath); return; }
    %orig;
}
%end

#pragma mark - B) 数据源层（MMTableViewInfo / WCTableViewManager，新版“我”页真正的数据源）

// 这两个类是微信“我”页表格的真正 dataSource。它们被大量表格复用，
// 因此每个方法都先用 npc_isMePageTableView 限定只在“我”页表格上注入。

// ---- MMTableViewInfo ----
%hook MMTableViewInfo
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (npc_isMePageTableView(tableView)) {
        NSInteger n = %orig;
        objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return n;
    }
    return %orig;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (npc_isMePageTableView(tableView)) {
        NSInteger orig = %orig;
        npc_cacheRows(self, section, orig);
        return npc_adjustedRowCount(self, orig, section);
    }
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) return NPCEntryRowHeight;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(tableView, indexPath); return; }
    %orig;
}
%end

// ---- WCTableViewManager（部分版本的数据源类名）----
%hook WCTableViewManager
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (npc_isMePageTableView(tableView)) {
        NSInteger n = %orig;
        objc_setAssociatedObject(self, NPCSectionCountKey, @(n), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return n;
    }
    return %orig;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (npc_isMePageTableView(tableView)) {
        NSInteger orig = %orig;
        npc_cacheRows(self, section, orig);
        return npc_adjustedRowCount(self, orig, section);
    }
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) return NPCEntryRowHeight;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) return npc_entryCell(tableView);
    return %orig;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (npc_isMePageTableView(tableView) && npc_isEntry(self, indexPath.section, indexPath.row)) { npc_openSettings(tableView, indexPath); return; }
    %orig;
}
%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。
// migrateDefaults 已在 DPConfig +load 中调用，这里再调一次是幂等保险。
__attribute__((constructor))
static void diylibEntry(void) {
    @autoreleasepool {
        DPLogInfo(@"diylib v26.0.1 (NPC) by yZFAIU loaded into WeChat");
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        // 安装 AddMsg 集中分发器（幂等，只 hook 一次）。
        // 各模块在自身 +load 中按开关决定是否订阅分发器或独立 hook 自己的目标方法。
        // 注意：模块 +load 早于 constructor 执行，订阅先于 install，时序正确。
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
