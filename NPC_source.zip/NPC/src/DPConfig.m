// DPConfig.m
#import "DPConfig.h"

NSString *const kSwitchEnabled             = @"diylib_master_enabled";
NSString *const kSwitchLocationSpoof       = @"diylib_location_spoof";
NSString *const kSwitchCloseFriend         = @"diylib_close_friend";
NSString *const kSwitchAutoFollow          = @"diylib_auto_follow";
NSString *const kSwitchChatEncrypt         = @"diylib_chat_encrypt";
NSString *const kSwitchDisableFunction     = @"diylib_disable_function";
NSString *const kSwitchBackgroundKeepAlive = @"diylib_bg_keepalive";
NSString *const kSwitchAntiRevoke          = @"diylib_anti_revoke";
NSString *const kSwitchAutoAcceptFriend    = @"diylib_auto_accept_friend";
NSString *const kSwitchQuitGroupMonitor    = @"diylib_quit_group_monitor";
NSString *const kSwitchAutoAcceptTransfer  = @"diylib_auto_accept_transfer";
NSString *const kSwitchAutoRedEnvelope     = @"diylib_auto_red_envelope";
NSString *const kSwitchFriendDetector      = @"diylib_friend_detector";

NSString *const kLocationLatitude       = @"diylib_location_lat";
NSString *const kLocationLongitude      = @"diylib_location_lon";
NSString *const kLocationAddress        = @"diylib_location_addr";
NSString *const kLocationForTimeline    = @"diylib_location_timeline";

NSString *const kCloseFriendList        = @"diylib_cf_list";
NSString *const kCloseFriendRingEnable  = @"diylib_cf_ring";
NSString *const kCloseFriendTopEnable   = @"diylib_cf_top";
NSString *const kCloseFriendRedDotEnable= @"diylib_cf_reddot";

NSString *const kAutoFollowLikeEnable   = @"diylib_af_like";
NSString *const kAutoFollowCommentEnable= @"diylib_af_comment";
NSString *const kAutoFollowKeywords     = @"diylib_af_keywords";
NSString *const kAutoFollowComments     = @"diylib_af_comments";
NSString *const kAutoFollowIntervalSec  = @"diylib_af_interval";
NSString *const kAutoFollowMaxNumPerDay = @"diylib_af_max_per_day";

NSString *const kChatEncryptAESKey      = @"diylib_ce_aes_key";
NSString *const kChatEncryptGroupList   = @"diylib_ce_groups";
NSString *const kChatEncryptDisplayMode = @"diylib_ce_display_mode";
NSString *const kChatEncryptImageEnable = @"diylib_ce_image";

NSString *const kDisableMainFrameSearchBar = @"diylib_df_search_bar";
NSString *const kDisableUnReadCount        = @"diylib_df_unread_count";
NSString *const kDisableEmoticonStore      = @"diylib_df_emo_store";
NSString *const kDisableEmoticonSearch     = @"diylib_df_emo_search";
NSString *const kDisableCameraEmoticon     = @"diylib_df_emo_camera";
NSString *const kDisableDownApplet         = @"diylib_df_applet";
NSString *const kDisableWCPayTitle         = @"diylib_df_pay_title";
NSString *const kDisableWCFinder           = @"diylib_df_finder";
NSString *const kDisableSettingAboutMM     = @"diylib_df_about_mm";
NSString *const kDisableSettingLabs        = @"diylib_df_labs";
NSString *const kDisableElderMode          = @"diylib_df_elder";
NSString *const kDisableAutoGetUpdate      = @"diylib_df_auto_update";
NSString *const kDisablePatViewTips        = @"diylib_df_pat_tips";
NSString *const kDisableCopyMsgTip         = @"diylib_df_copy_tip";
NSString *const kDisableInputTips          = @"diylib_df_input_tips";
NSString *const kDisableBatchRevokeMsg     = @"diylib_df_batch_revoke";
NSString *const kDisableAVCapture          = @"diylib_df_av_capture";

NSString *const kKeepAliveAudioEnable   = @"diylib_ka_audio";
NSString *const kKeepAliveBgTaskEnable  = @"diylib_ka_bg_task";
NSString *const kKeepAliveNotifyOnKill  = @"diylib_ka_notify_kill";

NSString *const kAntiRevokeReplyEnable  = @"diylib_ar_reply_enable";
NSString *const kAntiRevokeReplyContent = @"diylib_ar_reply_content";
NSString *const kAntiRevokeNotifyEnable = @"diylib_ar_notify";
NSString *const kAntiRevokeShowOrigin    = @"diylib_ar_show_origin";

NSString *const kAutoAcceptFriendKeywords     = @"diylib_aaf_keywords";
NSString *const kAutoAcceptFriendReplyEnable  = @"diylib_aaf_reply_enable";
NSString *const kAutoAcceptFriendReplyText    = @"diylib_aaf_reply_text";

NSString *const kQuitGroupMonitorPushSelf      = @"diylib_qm_push_self";
NSString *const kQuitGroupMonitorAlert         = @"diylib_qm_alert";
NSString *const kQuitGroupMonitorReplyEnable   = @"diylib_qm_reply_enable";
NSString *const kQuitGroupMonitorReplyContent  = @"diylib_qm_reply_content";

NSString *const kAutoTransferDelaySec      = @"diylib_at_delay";
NSString *const kAutoTransferReplyEnable   = @"diylib_at_reply_enable";
NSString *const kAutoTransferReplyContent  = @"diylib_at_reply_content";

NSString *const kRedEnvelopeDelaySec       = @"diylib_re_delay";
NSString *const kRedEnvelopeGroupFilter    = @"diylib_re_group_filter";
NSString *const kRedEnvelopeKeywordFilter  = @"diylib_re_keyword_filter";
NSString *const kRedEnvelopeReplyEnable    = @"diylib_re_reply_enable";
NSString *const kRedEnvelopeReplyText      = @"diylib_re_reply_text";
NSString *const kRedEnvelopeSkipSelf       = @"diylib_re_skip_self";
NSString *const kRedEnvelopeSkipPrivate    = @"diylib_re_skip_private";

NSString *const kFriendDetectorMethod      = @"diylib_fd_method";
NSString *const kFriendDetectorAutoDelete  = @"diylib_fd_auto_delete";

NSString *const kSwitchMarkAllRead         = @"diylib_mark_all_read";
NSString *const kSwitchLongPressPlusOne    = @"diylib_longpress_plusone";

NSString *const kSwitchKeywordAutoReply    = @"diylib_kw_auto_reply";
NSString *const kKeywordAutoReplyPairs     = @"diylib_kw_reply_pairs";
NSString *const kKeywordAutoReplyOnlyGroup = @"diylib_kw_reply_only_group";
NSString *const kKeywordAutoReplySkipSelf  = @"diylib_kw_reply_skip_self";
NSString *const kKeywordAutoReplyDelay     = @"diylib_kw_reply_delay";

NSString *const kSwitchKeywordReminder     = @"diylib_kw_reminder";
NSString *const kKeywordReminderKeywords   = @"diylib_kw_reminder_keywords";
NSString *const kKeywordReminderAlert      = @"diylib_kw_reminder_alert";
NSString *const kKeywordReminderPushSelf   = @"diylib_kw_reminder_push_self";
NSString *const kKeywordReminderVibrate    = @"diylib_kw_reminder_vibrate";

NSString *const kSwitchQuickQuote          = @"diylib_quick_quote";

NSString *const kSwitchAutoConfirmLogin    = @"diylib_auto_confirm_login";
NSString *const kAutoConfirmLoginDelay     = @"diylib_auto_confirm_login_delay";

NSString *const kSwitchCameraRecognize     = @"diylib_camera_recognize";

@implementation DPConfig

// +load 在 dylib 加载时执行，早于各模块 +load（DPConfig.m 在 Makefile FILES 列表中
// 排在所有 modules 之前），确保模块 +load 读取配置时默认值已写入。
// 修复首次安装时 kSwitchEnabled 未迁移导致所有模块不加载的 bug。
+ (void)load {
    @autoreleasepool {
        [self migrateDefaults];
    }
}

+ (NSUserDefaults *)ud {
    return [NSUserDefaults standardUserDefaults];
}

+ (BOOL)boolForSwitchKey:(NSString *)key {
    // 若 key 未注册过默认值且未写入，返回 NO。
    // 对 kSwitchEnabled 特殊处理：未设置时默认 YES（与 migrateDefaults 一致），
    // 兜底防止 +load 时序异常导致首次安装插件不工作。
    if ([[self ud] objectForKey:key] == nil) {
        if ([key isEqualToString:kSwitchEnabled]) return YES;
        return NO;
    }
    return [[self ud] boolForKey:key];
}

+ (void)setBool:(BOOL)value forSwitchKey:(NSString *)key {
    [[self ud] setBool:value forKey:key];
    [[self ud] synchronize];
}

+ (nullable id)objectForKey:(NSString *)key {
    return [[self ud] objectForKey:key];
}

+ (void)setObject:(nullable id)value forKey:(NSString *)key {
    [[self ud] setObject:value forKey:key];
    [[self ud] synchronize];
}

+ (NSInteger)integerForKey:(NSString *)key {
    if ([[self ud] objectForKey:key] == nil) return 0;
    return [[self ud] integerForKey:key];
}

+ (void)setInteger:(NSInteger)value forKey:(NSString *)key {
    [[self ud] setInteger:value forKey:key];
    [[self ud] synchronize];
}

+ (double)doubleForKey:(NSString *)key {
    if ([[self ud] objectForKey:key] == nil) return 0.0;
    return [[self ud] doubleForKey:key];
}

+ (void)setDouble:(double)value forKey:(NSString *)key {
    [[self ud] setDouble:value forKey:key];
    [[self ud] synchronize];
}

+ (void)migrateDefaults {
    NSUserDefaults *ud = [self ud];
    // 总开关默认开启
    if ([ud objectForKey:kSwitchEnabled] == nil) {
        [ud setBool:YES forKey:kSwitchEnabled];
    }
    // 12 个功能默认关闭（用户在面板里手动开启）
    NSArray *switches = @[
        kSwitchLocationSpoof, kSwitchCloseFriend, kSwitchAutoFollow,
        kSwitchChatEncrypt, kSwitchDisableFunction, kSwitchBackgroundKeepAlive,
        kSwitchAntiRevoke, kSwitchAutoAcceptFriend, kSwitchQuitGroupMonitor,
        kSwitchAutoAcceptTransfer, kSwitchAutoRedEnvelope, kSwitchFriendDetector,
        // 新增 7 个功能（13~19）默认关闭
        kSwitchMarkAllRead, kSwitchLongPressPlusOne,
        kSwitchKeywordAutoReply, kSwitchKeywordReminder,
        kSwitchQuickQuote, kSwitchAutoConfirmLogin, kSwitchCameraRecognize
    ];
    for (NSString *k in switches) {
        if ([ud objectForKey:k] == nil) [ud setBool:NO forKey:k];
    }
    // 关键词自动回复：默认延迟 1 秒（防风控）
    if ([ud objectForKey:kKeywordAutoReplyDelay] == nil) [ud setDouble:1.0 forKey:kKeywordAutoReplyDelay];
    // 关键词提醒：弹窗 + 推送文件助手默认开，震动默认关
    if ([ud objectForKey:kKeywordReminderAlert] == nil)    [ud setBool:YES forKey:kKeywordReminderAlert];
    if ([ud objectForKey:kKeywordReminderPushSelf] == nil) [ud setBool:YES forKey:kKeywordReminderPushSelf];
    if ([ud objectForKey:kKeywordReminderVibrate] == nil)  [ud setBool:NO forKey:kKeywordReminderVibrate];
    // 自动确认登陆：默认延迟 1 秒
    if ([ud objectForKey:kAutoConfirmLoginDelay] == nil) [ud setDouble:1.0 forKey:kAutoConfirmLoginDelay];
    // 定位默认：北京天安门
    if ([ud objectForKey:kLocationLatitude] == nil)  [ud setDouble:39.9087 forKey:kLocationLatitude];
    if ([ud objectForKey:kLocationLongitude] == nil) [ud setDouble:116.3975 forKey:kLocationLongitude];
    if ([ud objectForKey:kLocationAddress] == nil)   [ud setObject:@"天安门广场" forKey:kLocationAddress];
    // 自动跟圈默认间隔 5 秒，每日上限 50
    if ([ud objectForKey:kAutoFollowIntervalSec] == nil) [ud setInteger:5 forKey:kAutoFollowIntervalSec];
    if ([ud objectForKey:kAutoFollowMaxNumPerDay] == nil) [ud setInteger:50 forKey:kAutoFollowMaxNumPerDay];
    // 加密显示模式默认 0=密文
    if ([ud objectForKey:kChatEncryptDisplayMode] == nil) [ud setInteger:0 forKey:kChatEncryptDisplayMode];
    // 抢红包延迟默认 1.5 秒
    if ([ud objectForKey:kRedEnvelopeDelaySec] == nil) [ud setDouble:1.5 forKey:kRedEnvelopeDelaySec];
    // 转账延迟默认 2 秒
    if ([ud objectForKey:kAutoTransferDelaySec] == nil) [ud setDouble:2.0 forKey:kAutoTransferDelaySec];
    // 好友检测方法默认 0=拉群法
    if ([ud objectForKey:kFriendDetectorMethod] == nil) [ud setInteger:0 forKey:kFriendDetectorMethod];
    // 后台保活三件套默认开启
    if ([ud objectForKey:kKeepAliveAudioEnable] == nil)  [ud setBool:YES forKey:kKeepAliveAudioEnable];
    if ([ud objectForKey:kKeepAliveBgTaskEnable] == nil) [ud setBool:YES forKey:kKeepAliveBgTaskEnable];
    if ([ud objectForKey:kKeepAliveNotifyOnKill] == nil) [ud setBool:NO forKey:kKeepAliveNotifyOnKill];
    // 默认回复话术
    if ([ud objectForKey:kAntiRevokeReplyContent] == nil) [ud setObject:@"对方撤回了一条消息" forKey:kAntiRevokeReplyContent];
    if ([ud objectForKey:kQuitGroupMonitorReplyContent] == nil) [ud setObject:@"已退出群聊" forKey:kQuitGroupMonitorReplyContent];
    if ([ud objectForKey:kAutoTransferReplyContent] == nil) [ud setObject:@"已收款，谢谢" forKey:kAutoTransferReplyContent];
    if ([ud objectForKey:kRedEnvelopeReplyText] == nil) [ud setObject:@"谢谢老板" forKey:kRedEnvelopeReplyText];
    if ([ud objectForKey:kAutoAcceptFriendReplyText] == nil) [ud setObject:@"你好，已通过你的好友请求" forKey:kAutoAcceptFriendReplyText];
    [ud synchronize];
}

@end
