// QuitGroupMonitorHook.m — 功能9: 退群监控
//
// 修复要点：
//   1) 原实现直接 hook CMessageMgr AddMsg: 与其他三模块冲突。
//      改为订阅 DPMessageDispatcher，phase=1（orig 后）检测系统消息。
//   2) 移除重复前向声明，import DPPrivateClasses.h。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

static BOOL isQuitGroupSystemMsg(NSString *content) {
    if (!content) return NO;
    NSArray *patterns = @[
        @"退出了群聊", @"被移出群聊", @"移出了群聊",
        @"被邀请加入了群聊", @"加入了群聊"
    ];
    for (NSString *p in patterns) {
        if ([content containsString:p]) return YES;
    }
    return NO;
}

static void notifyQuitGroup(NSString *groupId, NSString *content) {
    // 弹窗
    if ([DPConfig boolForSwitchKey:kQuitGroupMonitorAlert]) {
        [DPHelper showAlertOnTopWithTitle:@"退群监控" message:[NSString stringWithFormat:@"%@\n%@", groupId, content]];
    }
    // 推送到文件助手
    if ([DPConfig boolForSwitchKey:kQuitGroupMonitorPushSelf]) {
        [DPHelper after:0.5 onMain:^{
            id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
            if (!mgr) return;
            Class wrapCls = objc_getClass("CMessageWrap");
            if (!wrapCls) return;
            id msg = [[wrapCls alloc] init];
            [msg setValue:@"filehelper" forKey:@"m_nsToUsr"];
            [msg setValue:[NSString stringWithFormat:@"【退群监控】%@：%@", groupId, content] forKey:@"m_nsContent"];
            [msg setValue:@1 forKey:@"nMessageType"];
            [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[msg]];
        }];
    }
    // 自动回复到群
    if ([DPConfig boolForSwitchKey:kQuitGroupMonitorReplyEnable]) {
        [DPHelper after:1.0 onMain:^{
            id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
            if (!mgr) return;
            Class wrapCls = objc_getClass("CMessageWrap");
            if (!wrapCls) return;
            id msg = [[wrapCls alloc] init];
            [msg setValue:groupId forKey:@"m_nsToUsr"];
            [msg setValue:[DPConfig objectForKey:kQuitGroupMonitorReplyContent] ?: @"已退出群聊" forKey:@"m_nsContent"];
            [msg setValue:@1 forKey:@"nMessageType"];
            [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[msg]];
        }];
    }
}

static void onAddMsgHandler_QGM(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchQuitGroupMonitor]) return;
    if (phase != 1) return; // orig 调用后处理
    @try {
        int type = [[msg valueForKey:@"nMessageType"] intValue];
        if (type == 10000) {
            NSString *content = [msg valueForKey:@"m_nsContent"];
            NSString *from = [msg valueForKey:@"m_nsFromUsr"];
            if (isQuitGroupSystemMsg(content)) {
                DPLogInfo(@"退群监控命中：from=%@ content=%@", from, content);
                notifyQuitGroup(from, content);
            }
        }
    } @catch (NSException *e) {
        DPLogWarn(@"退群监控异常：%@", e);
    }
}

@interface QuitGroupMonitorHook : NSObject @end
@implementation QuitGroupMonitorHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 订阅 AddMsg 分发器
    [[DPMessageDispatcher shared] subscribeForKey:@"QuitGroupMonitor"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler_QGM(msg, phase);
    }];
    DPLogInfo(@"QuitGroupMonitor: 已订阅 AddMsg 分发器");
}
@end
