// ChatEncryptHook.m — 功能4: 聊天加密
//
// 修复要点：
//   1) 原实现直接 hook CMessageMgr AddMsg: 与其他三模块冲突。
//      改为订阅 DPMessageDispatcher：接收时 phase=0（orig 前）解密 m_nsContent。
//   2) 发送加密仍 hook MessageService SendMsg:（该方法只本模块 hook，无冲突，保留）。
//   3) 移除重复前向声明，import DPPrivateClasses.h。
//   4) phase=0 解密后 orig 才处理，确保微信看到的是明文。

#import <objc/runtime.h>
#import <CommonCrypto/CommonCrypto.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

#define NPC_ENC_PREFIX @"【NPC密】"

// AES-128-CBC 加密
static NSString *aesEncryptString(NSString *plain, NSString *key) {
    if (!plain || !key) return plain;
    // key 取 MD5 前 16 字节
    const char *keyC = [key UTF8String];
    unsigned char keyHash[CC_MD5_DIGEST_LENGTH];
    CC_MD5(keyC, (CC_LONG)strlen(keyC), keyHash);
    char iv[17] = "NPC_NPC_NPC_NPC_"; // 固定 IV（演示用）
    NSData *data = [plain dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableData *out = [NSMutableData dataWithLength:data.length + kCCBlockSizeAES128];
    size_t outLen = 0;
    CCCryptorStatus rc = CCCrypt(kCCEncrypt, kCCAlgorithmAES, kCCOptionPKCS7Padding,
                                 keyHash, kCCKeySizeAES128, iv,
                                 data.bytes, data.length,
                                 out.mutableBytes, out.length, &outLen);
    if (rc != kCCSuccess) return plain;
    out.length = outLen;
    return [out base64EncodedStringWithOptions:0];
}

static NSString *aesDecryptString(NSString *cipherB64, NSString *key) {
    if (!cipherB64 || !key) return cipherB64;
    const char *keyC = [key UTF8String];
    unsigned char keyHash[CC_MD5_DIGEST_LENGTH];
    CC_MD5(keyC, (CC_LONG)strlen(keyC), keyHash);
    char iv[17] = "NPC_NPC_NPC_NPC_";
    NSData *data = [[NSData alloc] initWithBase64EncodedString:cipherB64 options:0];
    if (!data) return cipherB64;
    NSMutableData *out = [NSMutableData dataWithLength:data.length + kCCBlockSizeAES128];
    size_t outLen = 0;
    CCCryptorStatus rc = CCCrypt(kCCDecrypt, kCCAlgorithmAES, kCCOptionPKCS7Padding,
                                 keyHash, kCCKeySizeAES128, iv,
                                 data.bytes, data.length,
                                 out.mutableBytes, out.length, &outLen);
    if (rc != kCCSuccess) return cipherB64;
    out.length = outLen;
    return [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] ?: cipherB64;
}

static BOOL shouldEncryptChat(NSString *chatName) {
    NSArray *groups = [DPConfig objectForKey:kChatEncryptGroupList] ?: @[];
    if (groups.count == 0) return YES; // 未配置白名单=全部加密
    return [groups containsObject:chatName];
}

// hook 发送：MessageService SendMsg:（仅本模块 hook，无冲突）
static void (*orig_SendMsg)(id, SEL, id);
static void hook_SendMsg(id self, SEL _cmd, CMessageWrap *msg) {
    if ([DPConfig boolForSwitchKey:kSwitchChatEncrypt]) {
        @try {
            NSString *to = [msg valueForKey:@"m_nsToUsr"];
            if (shouldEncryptChat(to)) {
                NSString *key = [DPConfig objectForKey:kChatEncryptAESKey] ?: @"NPC_DEFAULT_KEY";
                NSString *plain = [msg valueForKey:@"m_nsContent"];
                if (plain && ![plain hasPrefix:NPC_ENC_PREFIX]) {
                    NSString *cipher = aesEncryptString(plain, key);
                    NSString *wrapped = [NSString stringWithFormat:@"%@%@", NPC_ENC_PREFIX, cipher];
                    [msg setValue:wrapped forKey:@"m_nsContent"];
                    DPLogInfo(@"消息已加密发送 to=%@", to);
                }
            }
        } @catch (NSException *e) {
            DPLogWarn(@"消息加密异常：%@", e);
        }
    }
    if (orig_SendMsg) {
        orig_SendMsg(self, _cmd, msg);
    } else {
        // 兜底：orig 为空时不应发生，但避免空指针跳转
        DPLogErr(@"ChatEncrypt: orig_SendMsg 为空，跳过发送");
    }
}

// 接收：订阅 AddMsg 分发器，phase=0 在 orig 前解密
static void onAddMsgHandler_Enc(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchChatEncrypt]) return;
    if (phase != 0) return; // orig 调用前解密
    @try {
        NSString *content = [msg valueForKey:@"m_nsContent"];
        if (content && [content hasPrefix:NPC_ENC_PREFIX]) {
            NSString *cipher = [content substringFromIndex:NPC_ENC_PREFIX.length];
            NSString *key = [DPConfig objectForKey:kChatEncryptAESKey] ?: @"NPC_DEFAULT_KEY";
            NSString *plain = aesDecryptString(cipher, key);
            [msg setValue:plain forKey:@"m_nsContent"];
            DPLogInfo(@"密文已解密显示");
        }
    } @catch (NSException *e) {
        DPLogWarn(@"消息解密异常：%@", e);
    }
}

@interface ChatEncryptHook : NSObject @end
@implementation ChatEncryptHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 发送加密：hook MessageService SendMsg:
    Class msgSvc = objc_getClass("MessageService");
    if (msgSvc) {
        Method m = class_getInstanceMethod(msgSvc, @selector(SendMsg:));
        if (m) {
            orig_SendMsg = (void (*)(id, SEL, id))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_SendMsg);
            DPLogInfo(@"ChatEncrypt: hooked MessageService SendMsg:");
        }
    }
    // 接收解密：订阅 AddMsg 分发器
    [[DPMessageDispatcher shared] subscribeForKey:@"ChatEncrypt"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler_Enc(msg, phase);
    }];
    DPLogInfo(@"ChatEncrypt: 已订阅 AddMsg 分发器");
}
@end
