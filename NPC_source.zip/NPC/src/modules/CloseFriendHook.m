// CloseFriendHook.m — 功能2: 密友功能
//
// 修复要点：
//   1) 原实现直接 hook CMessageMgr AddMsg:，与 ChatEncrypt/QuitGroupMonitor/
//      AutoRedEnvelope 共四个模块冲突，orig 指针错乱可能递归闪退。
//      改为订阅 DPMessageDispatcher，不再自行 hook AddMsg:。
//   2) 移除重复的私有类前向声明，统一 import DPPrivateClasses.h。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

// 判断是否密友
static BOOL isCloseFriend(NSString *wxid) {
    if (!wxid) return NO;
    NSArray *list = [DPConfig objectForKey:kCloseFriendList] ?: @[];
    return [list containsObject:wxid];
}

// 密友消息处理（订阅分发器回调）
static void onAddMsgHandler(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchCloseFriend]) return;
    if (phase != 1) return; // orig 调用后处理
    @try {
        NSString *from = [msg valueForKey:@"m_nsFromUsr"];
        NSString *to = [msg valueForKey:@"m_nsToUsr"];
        // 单聊消息 from/to 一个是自己一个是对方
        NSString *peer = nil;
        if (from && ![from hasSuffix:@"@chatroom"]) peer = from;
        else if (to && ![to hasSuffix:@"@chatroom"]) peer = to;
        if (peer && isCloseFriend(peer)) {
            DPLogInfo(@"密友消息到达：%@", peer);
            // 红点提醒
            if ([DPConfig boolForSwitchKey:kCloseFriendRedDotEnable]) {
                [DPHelper after:0.0 onMain:^{
                    // 触发本地通知（与 BackgroundKeepAlive 共用通道）
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"NPC_CloseFriendMsg" object:peer userInfo:nil];
                }];
            }
        }
    } @catch (NSException *e) {
        DPLogWarn(@"密友检测异常：%@", e);
    }
}

@interface CloseFriendHook : NSObject @end
@implementation CloseFriendHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 订阅 AddMsg 分发器，不再自行 hook
    [[DPMessageDispatcher shared] subscribeForKey:@"CloseFriend"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler(msg, phase);
    }];
    DPLogInfo(@"CloseFriend: 已订阅 AddMsg 分发器");
}
@end
