// KeywordAutoReplyHook.m — 功能15: 关键词自动回复
//
// 参考 MiYou MYReplyConfig（关键词回复：mKeywordReplyMessage / mIsKeywordReplyMessage /
// mIsReplyChatRoomMessage / mIsKeywordReplySelfMessage / mReplyChatRoomList / delayTime）。
// 订阅 AddMsg 分发器(orig 后)，对命中关键词的入消息自动回复。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

// 解析 "kw1=reply1,kw2=reply2" -> {kw: reply}
static NSDictionary *parseReplyPairs(NSString *raw) {
    if (!raw.length) return @{};
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    for (NSString *pair in [raw componentsSeparatedByString:@","]) {
        NSString *p = [pair stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (!p.length) continue;
        NSRange r = [p rangeOfString:@"="];
        if (r.location != NSNotFound) {
            NSString *k = [[p substringToIndex:r.location]
                           stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            NSString *v = [[p substringFromIndex:r.location + 1]
                           stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if (k.length) map[k] = (v.length ? v : @"");
        } else {
            map[p] = @""; // 仅关键词、无回复内容
        }
    }
    return map;
}

static void onAddMsgHandler_KAR(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchKeywordAutoReply]) return;
    if (phase != 1) return; // orig 调用后处理
    @try {
        int type = [[msg valueForKey:@"nMessageType"] intValue];
        if (type == 10000) return; // 系统消息不自动回复
        NSString *content = [msg valueForKey:@"m_nsContent"];
        if (!content.length) return;
        NSString *from = [msg valueForKey:@"m_nsFromUsr"];
        if (!from.length) return;

        // 跳过自己
        if ([DPConfig boolForSwitchKey:kKeywordAutoReplySkipSelf]) {
            NSString *selfWxid = nil;
            id cmgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
            if (cmgr) {
                id selfC = [DPHelper performSelectorOnObject:cmgr sel:@selector(getSelfContact) withObjects:@[]];
                selfWxid = [selfC valueForKey:@"m_nsUsrName"];
            }
            if (selfWxid.length && [from isEqualToString:selfWxid]) return;
        }
        // 仅群聊
        BOOL isGroup = [DPHelper isGroupChat:from];
        if ([DPConfig boolForSwitchKey:kKeywordAutoReplyOnlyGroup] && !isGroup) return;

        NSDictionary *pairs = parseReplyPairs([DPConfig objectForKey:kKeywordAutoReplyPairs]);
        if (pairs.count == 0) return;

        NSMutableArray *replies = [NSMutableArray array];
        for (NSString *kw in pairs) {
            if ([content containsString:kw]) {
                NSString *r = pairs[kw];
                [replies addObject:(r.length ? r : @"")];
            }
        }
        if (replies.count == 0) return;

        double delay = [DPConfig doubleForKey:kKeywordAutoReplyDelay];
        if (delay < 0) delay = 0;
        [DPHelper after:delay onMain:^{
            id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
            if (!mgr) return;
            Class wrapCls = objc_getClass("CMessageWrap");
            if (!wrapCls) return;
            for (NSString *reply in replies) {
                id m = [[wrapCls alloc] init];
                [m setValue:from forKey:@"m_nsToUsr"];
                [m setValue:(reply.length ? reply : @"收到") forKey:@"m_nsContent"];
                [m setValue:@1 forKey:@"nMessageType"];
                [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[m]];
            }
        }];
    } @catch (NSException *e) {
        DPLogWarn(@"关键词自动回复异常：%@", e);
    }
}

@interface KeywordAutoReplyHook : NSObject @end
@implementation KeywordAutoReplyHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    [[DPMessageDispatcher shared] subscribeForKey:@"KeywordAutoReply"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler_KAR(msg, phase);
    }];
    DPLogInfo(@"KeywordAutoReply: 已订阅 AddMsg 分发器");
}
@end
