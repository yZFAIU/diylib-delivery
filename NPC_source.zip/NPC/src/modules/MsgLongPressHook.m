// MsgLongPressHook.m — 功能14(长按+1) + 功能17(消息快速引用)
//
// 参考 MiYou 的 mIsQuoteAtUser（引用并@）、消息快捷操作。
// 在聊天页(BaseMsgContentViewController)长按消息气泡的菜单中注入两个自定义项：
//   • "＋1"：向当前会话发送"1"（群内快速捧场）
//   • "引用"：把当前消息内容带入输入框作为引用（设置微信输入栏的引用消息）
//
// 修复要点（与关键词提醒同款工程纪律）：
//   1) 长按时微信会重建 UIMenuController 的 menuItems，仅 viewDidLoad 注册一次会被覆盖；
//      故监听 UIMenuControllerWillShowMenuNotification，在菜单即将展示前注入，确保生效。
//   2) 通过自加的 UILongPressGestureRecognizer(cancelsTouchesInView=NO)捕获当前消息 wrap，
//      与微信原生长按并存，不破坏原生菜单；若 forwardLongPressMenu: 存在则额外兜底捕获。
//   3) 重写 canPerformAction:withSender: 对我们两个 action 返回 YES，否则转发 orig，
//      保证菜单项可点击。
//   4) 发送走 AddMsg: 且用 DPHelper after 异步派发，避免在主线程手势回调里直接构造消息。

#import <objc/runtime.h>
#import <UIKit/UIKit.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

static const void *NPCCurMsgWrapKey = &NPCCurMsgWrapKey;

#pragma mark - 注入菜单项 / 动作（BaseMsgContentViewController 分类）
@interface BaseMsgContentViewController (NPCMsgLongPress)
- (void)npc_injectMenuItems;
- (void)npc_longPressPlusOne:(id)sender;
- (void)npc_quickQuote:(id)sender;
- (void)npc_didLongPress:(UILongPressGestureRecognizer *)g;
- (void)npc_onMenuWillShow:(NSNotification *)note;
@end

@implementation BaseMsgContentViewController (NPCMsgLongPress)

- (void)npc_injectMenuItems {
    @try {
        NSMutableArray *items = [NSMutableArray array];
        if ([DPConfig boolForSwitchKey:kSwitchLongPressPlusOne]) {
            [items addObject:[[UIMenuItem alloc] initWithTitle:@"＋1" action:@selector(npc_longPressPlusOne:)]];
        }
        if ([DPConfig boolForSwitchKey:kSwitchQuickQuote]) {
            [items addObject:[[UIMenuItem alloc] initWithTitle:@"引用" action:@selector(npc_quickQuote:)]];
        }
        if (items.count == 0) return;
        UIMenuController *mc = [UIMenuController sharedMenuController];
        NSMutableArray *all = [NSMutableArray arrayWithArray:mc.menuItems ?: @[]];
        for (UIMenuItem *it in items) {
            BOOL has = NO;
            for (UIMenuItem *e in all) { if (e.action == it.action) { has = YES; break; } }
            if (!has) [all addObject:it];
        }
        mc.menuItems = all;
    } @catch (NSException *e) {
        DPLogWarn(@"MsgLongPress 注入菜单异常：%@", e);
    }
}

- (void)npc_longPressPlusOne:(id)sender {
    id wrap = objc_getAssociatedObject(self, NPCCurMsgWrapKey);
    NSString *to = [wrap valueForKey:@"m_nsFromUsr"];
    if (!to.length) return;
    [DPHelper after:0.0 onMain:^{
        id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
        if (!mgr) return;
        Class wrapCls = objc_getClass("CMessageWrap");
        if (!wrapCls) return;
        id msg = [[wrapCls alloc] init];
        [msg setValue:to forKey:@"m_nsToUsr"];
        [msg setValue:@"1" forKey:@"m_nsContent"];
        [msg setValue:@1 forKey:@"nMessageType"];
        [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[msg]];
    }];
}

- (void)npc_quickQuote:(id)sender {
    id wrap = objc_getAssociatedObject(self, NPCCurMsgWrapKey);
    if (!wrap) return;
    NSString *content = [wrap valueForKey:@"m_nsContent"];
    if (!content.length) return;
    [DPHelper runOnMain:^{
        @try {
            id inputBar = [self valueForKey:@"m_inputBarView"] ?: [self valueForKey:@"m_textView"];
            if (inputBar && [inputBar respondsToSelector:NSSelectorFromString(@"setMQuoteMessage:")]) {
                // 微信输入栏支持引用消息对象
                [DPHelper performSelectorOnObject:inputBar sel:NSSelectorFromString(@"setMQuoteMessage:") withObjects:@[wrap]];
            } else if (inputBar && [inputBar respondsToSelector:@selector(setText:)]) {
                // 退化方案：在输入框追加引用文本
                NSString *cur = [inputBar valueForKey:@"text"] ?: @"";
                [inputBar setValue:[NSString stringWithFormat:@"「%@」\n%@", content, cur] forKey:@"text"];
            }
        } @catch (NSException *e) {
            DPLogWarn(@"MsgLongPress 引用异常：%@", e);
        }
    }];
}

// 自加长按手势：捕获当前消息 wrap（与微信原生长按并存）
- (void)npc_didLongPress:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    @try {
        UITableView *tv = [self valueForKey:@"m_tableView"];
        if (!tv) return;
        CGPoint p = [g locationInView:tv];
        NSIndexPath *ip = [tv indexPathForRowAtPoint:p];
        if (!ip) return;
        UITableViewCell *cell = [tv cellForRowAtIndexPath:ip];
        if (!cell) return;
        id wrap = nil;
        for (NSString *k in @[@"m_msgWrap", @"msgWrap"]) {
            @try { wrap = [cell valueForKey:k]; } @catch (__unused id e) {}
            if (wrap) break;
        }
        if (wrap) {
            objc_setAssociatedObject(self, NPCCurMsgWrapKey, wrap, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    } @catch (NSException *e) {
        DPLogWarn(@"MsgLongPress 捕获消息异常：%@", e);
    }
}

// 菜单即将展示：注入自定义项（最可靠注入点）
- (void)npc_onMenuWillShow:(NSNotification *)note {
    [self npc_injectMenuItems];
}

@end

#pragma mark - hook BaseMsgContentViewController
static void (*orig_BMC_viewDidLoad)(id, SEL);
static void hook_BMC_viewDidLoad(id self, SEL _cmd) {
    if (orig_BMC_viewDidLoad) orig_BMC_viewDidLoad(self, _cmd);
    if (![DPConfig boolForSwitchKey:kSwitchLongPressPlusOne] &&
        ![DPConfig boolForSwitchKey:kSwitchQuickQuote]) return;
    // 注册菜单即将展示通知（最可靠注入点）
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(npc_onMenuWillShow:)
                                                 name:UIMenuControllerWillShowMenuNotification
                                               object:nil];
    // 自加长按手势捕获消息（cancelsTouchesInView=NO 不干扰原生）
    [DPHelper after:0.3 onMain:^{
        @try {
            UITableView *tv = [self valueForKey:@"m_tableView"];
            if (tv) {
                UILongPressGestureRecognizer *lg = [[UILongPressGestureRecognizer alloc]
                                                    initWithTarget:self action:@selector(npc_didLongPress:)];
                lg.cancelsTouchesInView = NO;
                lg.minimumPressDuration = 0.6;
                [tv addGestureRecognizer:lg];
            }
        } @catch (NSException *e) {
            DPLogWarn(@"MsgLongPress 注册手势异常：%@", e);
        }
    }];
}

static void (*orig_BMC_forwardLongPress)(id, SEL, id);
static void hook_BMC_forwardLongPress(id self, SEL _cmd, id arg) {
    // 兜底捕获当前长按消息（forwardLongPressMenu: 多版本入口，可能不存在）
    if (arg) {
        id wrap = arg;
        if ([arg isKindOfClass:[NSDictionary class]]) {
            @try { wrap = [arg objectForKey:@"msgWrap"] ?: arg; } @catch (__unused id e) {}
        }
        objc_setAssociatedObject(self, NPCCurMsgWrapKey, wrap, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (orig_BMC_forwardLongPress) orig_BMC_forwardLongPress(self, _cmd, arg);
    [self npc_injectMenuItems];
}

static BOOL (*orig_BMC_canPerform)(id, SEL, SEL, id);
static BOOL hook_BMC_canPerform(id self, SEL _cmd, SEL action, id sender) {
    if (action == @selector(npc_longPressPlusOne:)) {
        return [DPConfig boolForSwitchKey:kSwitchLongPressPlusOne];
    }
    if (action == @selector(npc_quickQuote:)) {
        return [DPConfig boolForSwitchKey:kSwitchQuickQuote];
    }
    if (orig_BMC_canPerform) return orig_BMC_canPerform(self, _cmd, action, sender);
    return NO;
}

@interface MsgLongPressHook : NSObject @end
@implementation MsgLongPressHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class bmc = objc_getClass("BaseMsgContentViewController");
    if (!bmc) { DPLogWarn(@"MsgLongPress: BaseMsgContentViewController 未找到"); return; }
    Method m1 = class_getInstanceMethod(bmc, @selector(viewDidLoad));
    if (m1) { orig_BMC_viewDidLoad = (void (*)(id, SEL))method_setImplementation(m1, (IMP)hook_BMC_viewDidLoad); }
    Method m2 = class_getInstanceMethod(bmc, @selector(canPerformAction:withSender:));
    if (m2) {
        // 安全 swizzle：仅当 bmc 自己直接实现该方法时才替换；
        // 若它继承自 UIResponder/UIView，先把这个"继承来的 IMP"加到本类，
        // 否则 method_setImplementation 会覆盖 UIResponder 的全局实现、污染整个 App。
        BOOL own = NO;
        unsigned int cnt2; Method *ml = class_copyMethodList(bmc, &cnt2);
        for (unsigned int i = 0; i < cnt2; i++) {
            if (sel_isEqual(method_getName(ml[i]), @selector(canPerformAction:withSender:))) { own = YES; break; }
        }
        free(ml);
        if (!own) {
            const char *types = method_getTypeEncoding(m2);
            IMP superImp = method_getImplementation(m2);
            if (class_addMethod(bmc, @selector(canPerformAction:withSender:), superImp, types)) {
                m2 = class_getInstanceMethod(bmc, @selector(canPerformAction:withSender:));
            }
        }
        orig_BMC_canPerform = (BOOL (*)(id, SEL, SEL, id))method_setImplementation(m2, (IMP)hook_BMC_canPerform);
    }
    // forwardLongPressMenu: 仅在存在时 hook（多版本兼容）
    Method m3 = class_getInstanceMethod(bmc, @selector(forwardLongPressMenu:));
    if (m3) { orig_BMC_forwardLongPress = (void (*)(id, SEL, id))method_setImplementation(m3, (IMP)hook_BMC_forwardLongPress); }
    DPLogInfo(@"MsgLongPress: hooked BaseMsgContentViewController (+1 / 引用)");
}
@end
