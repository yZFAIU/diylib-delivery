// BackgroundKeepAlive.m — 功能6: 后台保活（参考 PKC 后台保活三件套）
//
// 修复要点：
//   1) NSTimer target:self 强引用造成循环引用。改用 block-based timer
//      配合 weak 引用，或用 DPWeakTimerProxy 间接持有。
//   2) +load 里 addObserver 从不移除，且每次 +load（dylib 重新加载）会累积。
//      改为只在首次注册一次（dispatch_once 保证），并在 dealloc 移除。
//   3) endBgTask 对 nil timer 调 invalidate 可能崩。改为 nil 检查。
//   4) 修复原文件注释乱码（GBK 被当 UTF-8 解码）。

#import <objc/runtime.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <UserNotifications/UserNotifications.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"

#pragma mark - Weak timer proxy，避免 NSTimer 强引用 target 造成循环引用

@interface DPWeakTimerProxy : NSProxy
@property (nonatomic, weak) id target;
+ (instancetype)proxyWithTarget:(id)target;
@end

@implementation DPWeakTimerProxy
+ (instancetype)proxyWithTarget:(id)target {
    DPWeakTimerProxy *p = [DPWeakTimerProxy alloc];
    p.target = target;
    return p;
}
- (BOOL)respondsToSelector:(SEL)aSelector {
    return [self.target respondsToSelector:aSelector];
}
- (void)forwardInvocation:(NSInvocation *)invocation {
    id t = self.target;
    if (t && [t respondsToSelector:[invocation selector]]) {
        [invocation invokeWithTarget:t];
    }
}
- (NSMethodSignature *)methodSignatureForSelector:(SEL)sel {
    // 优先用 target 的方法签名；target 为空时回退到 NSObject 实例方法签名
    NSMethodSignature *sig = [self.target methodSignatureForSelector:sel];
    if (sig) return sig;
    return [NSObject instanceMethodSignatureForSelector:sel];
}
@end

@interface BackgroundKeepAliveHook : NSObject <AVAudioPlayerDelegate>
@property (nonatomic, strong) AVAudioPlayer *blankPlayer;
@property (nonatomic, strong) NSTimer *bgTaskTimer;
@property (nonatomic, strong) DPWeakTimerProxy *timerProxy; // 持有 proxy 防止释放
@property (nonatomic, assign) UIBackgroundTaskIdentifier bgTaskId;
@property (nonatomic, strong) NSDate *backgroundEnteredAt;
@property (nonatomic, assign) NSTimeInterval accumulatedSeconds;
@end

@implementation BackgroundKeepAliveHook

+ (instancetype)shared {
    static BackgroundKeepAliveHook *s;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [BackgroundKeepAliveHook new]; });
    return s;
}

// 生成 1 秒静音 wav 数据
- (NSData *)generateBlankAudio {
    NSUInteger samples = 44100;
    NSMutableData *data = [NSMutableData data];
    char header[44] = {0};
    header[0]='R'; header[1]='I'; header[2]='F'; header[3]='F';
    *(uint32_t*)(header+4) = (uint32_t)(36 + samples * 2);
    header[8]='W'; header[9]='A'; header[10]='V'; header[11]='E';
    header[12]='f'; header[13]='m'; header[14]='t'; header[15]=' ';
    *(uint32_t*)(header+16) = 16;
    *(uint16_t*)(header+20) = 1;
    *(uint16_t*)(header+22) = 1;
    *(uint32_t*)(header+24) = 44100;
    *(uint32_t*)(header+28) = 88200;
    *(uint16_t*)(header+32) = 2;
    *(uint16_t*)(header+34) = 16;
    header[36]='d'; header[37]='a'; header[38]='t'; header[39]='a';
    *(uint32_t*)(header+40) = (uint32_t)(samples * 2);
    [data appendBytes:header length:44];
    // 静音样本全 0
    [data increaseLengthBy:samples * 2];
    memset((char *)data.mutableBytes + 44, 0, samples * 2);
    return data;
}

- (void)playBlankAudio {
    if (!self.blankPlayer) {
        [self setupAudioSession];
        NSData *pcm = [self generateBlankAudio];
        NSError *err = nil;
        self.blankPlayer = [[AVAudioPlayer alloc] initWithData:pcm error:&err];
        if (err || !self.blankPlayer) { DPLogWarn(@"静音音频初始化失败：%@", err); return; }
        self.blankPlayer.numberOfLoops = -1; // 无限循环
        self.blankPlayer.volume = 0.0;
        [self.blankPlayer prepareToPlay];
    }
    if (![self.blankPlayer isPlaying]) {
        [self.blankPlayer play];
        DPLogInfo(@"后台保活：静音音频已启动");
    }
}

- (void)stopBlankAudio {
    if (self.blankPlayer && [self.blankPlayer isPlaying]) {
        [self.blankPlayer stop];
        DPLogInfo(@"后台保活：静音音频已停止");
    }
}

- (void)setupAudioSession {
    AVAudioSession *s = [AVAudioSession sharedInstance];
    NSError *err = nil;
    [s setCategory:AVAudioSessionCategoryPlayback
       withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&err];
    [s setActive:YES error:&err];
}

- (void)enterBackgroundHandler {
    self.backgroundEnteredAt = [NSDate date];
    if ([DPConfig boolForSwitchKey:kKeepAliveBgTaskEnable]) {
        [self startBgTask];
    }
    if ([DPConfig boolForSwitchKey:kKeepAliveAudioEnable]) {
        [self playBlankAudio];
    }
    DPLogInfo(@"后台保活：已进入后台");
}

- (void)enterForegroundHandler {
    [self stopBlankAudio];
    [self endBgTask];
    if (self.backgroundEnteredAt) {
        NSTimeInterval sec = -[self.backgroundEnteredAt timeIntervalSinceNow];
        self.accumulatedSeconds += sec;
        DPLogInfo(@"后台保活：回到前台，本次保活 %.0f 秒，累计 %.0f 秒", sec, self.accumulatedSeconds);
    }
    self.backgroundEnteredAt = nil;
}

- (void)startBgTask {
    if (self.bgTaskId != UIBackgroundTaskInvalid) return;
    __weak typeof(self) weakSelf = self;
    self.bgTaskId = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        [weakSelf endBgTask];
        [weakSelf startBgTask];
    }];
    // 用 weak proxy 避免 NSTimer 强引用 self 造成循环引用
    self.timerProxy = [DPWeakTimerProxy proxyWithTarget:self];
    self.bgTaskTimer = [NSTimer scheduledTimerWithTimeInterval:25.0
                                                       target:self.timerProxy
                                                     selector:@selector(requestMoreTime)
                                                     userInfo:nil
                                                      repeats:YES];
    DPLogInfo(@"后台保活：Background Task 已启动 id=%lu", (unsigned long)self.bgTaskId);
}

- (void)endBgTask {
    if (self.bgTaskTimer) {
        [self.bgTaskTimer invalidate];
        self.bgTaskTimer = nil;
    }
    self.timerProxy = nil;
    if (self.bgTaskId != UIBackgroundTaskInvalid) {
        [[UIApplication sharedApplication] endBackgroundTask:self.bgTaskId];
        self.bgTaskId = UIBackgroundTaskInvalid;
    }
}

- (void)requestMoreTime {
    UIApplication *app = [UIApplication sharedApplication];
    NSTimeInterval remaining = app.backgroundTimeRemaining;
    DPLogInfo(@"后台保活：剩余时间 %.0f 秒，续命", remaining);
    if (remaining < 10) {
        [self endBgTask];
        [self startBgTask];
    }
}

- (void)pushNotification:(NSString *)title body:(NSString *)body {
    if (![DPConfig boolForSwitchKey:kKeepAliveNotifyOnKill]) return;
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    UNMutableNotificationContent *content = [UNMutableNotificationContent new];
    content.title = title;
    content.body = body;
    content.sound = [UNNotificationSound defaultSound];
    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
    UNNotificationRequest *req = [UNNotificationRequest requestWithIdentifier:@"NPC_KeepAlive" content:content trigger:trigger];
    [center addNotificationRequest:req withCompletionHandler:nil];
}

- (void)dealloc {
    if (self.bgTaskTimer) {
        [self.bgTaskTimer invalidate];
        self.bgTaskTimer = nil;
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // dispatch_once 保证只注册一次通知观察者，避免 dylib 多次加载累积观察者
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        BackgroundKeepAliveHook *instance = [self shared];
        [[NSNotificationCenter defaultCenter] addObserver:instance
                                                 selector:@selector(enterBackgroundHandler)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:instance
                                                 selector:@selector(enterForegroundHandler)
                                                     name:UIApplicationWillEnterForegroundNotification
                                                   object:nil];
        DPLogInfo(@"BackgroundKeepAlive: 监听已注册");
    });
}

@end
