// AntiRevokeHook.m — 功能7: 防撤回
//
// 修复要点：
//   1) 原实现完全吞掉 onRevokeMsg: 不调 orig，导致微信消息状态机不一致，
//      后续访问消息可能触发断言或访问已释放对象而闪退。
//      改为：先备份原 content，调用 orig（让微信完成状态更新），orig 后若开关开启
//      则恢复并标记撤回原文；若开关关闭则 orig 已正常执行撤回流程。
//   2) onRevokeMsg: 只本模块 hook，无多模块冲突，保留独立 hook。
//   3) import DPPrivateClasses.h 移除重复声明。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

static void (*orig_onRevokeMsg)(id, SEL, id);
static void hook_onRevokeMsg(id self, SEL _cmd, CMessageWrap *msg) {
    // 先备份原消息内容（orig 可能修改/清空它）
    NSString *origContent = [msg.m_nsContent copy];
    NSString *origFromUsr = [msg.m_nsFromUsr copy];

    if (![DPConfig boolForSwitchKey:kSwitchAntiRevoke]) {
        // 防撤回关闭：走原生撤回流程
        if (orig_onRevokeMsg) orig_onRevokeMsg(self, _cmd, msg);
        return;
    }

    // 防撤回开启：先让微信完成内部状态更新（避免状态机不一致），
    // 但我们在 orig 后恢复消息内容，使其不被删除/标记为撤回占位。
    if (orig_onRevokeMsg) {
        @try {
            orig_onRevokeMsg(self, _cmd, msg);
        } @catch (NSException *e) {
            DPLogWarn(@"orig_onRevokeMsg 异常：%@", e);
        }
    }

    @try {
        // 恢复原文（orig 可能已清空 content）
        if ([DPConfig boolForSwitchKey:kAntiRevokeShowOrigin]) {
            NSString *tip = [NSString stringWithFormat:@"⚠️对方撤回了一条消息：\n%@", origContent ?: @""];
            [msg setValue:tip forKey:@"m_nsContent"];
        } else {
            // 至少恢复原文，不显示"对方撤回了一条消息"
            if (origContent) [msg setValue:origContent forKey:@"m_nsContent"];
        }
        // 重置撤回标志，避免 UI 显示撤回占位
        @try { [msg setValue:@0 forKey:@"nMessageRevokFlag"]; } @catch (__unused id e) {}

        // 本地通知
        if ([DPConfig boolForSwitchKey:kAntiRevokeNotifyEnable]) {
            [DPHelper showAlertOnTopWithTitle:@"防撤回"
                                       message:[NSString stringWithFormat:@"%@ 撤回了一条消息", origFromUsr ?: @"对方"]];
        }

        // 自动回复
        if ([DPConfig boolForSwitchKey:kAntiRevokeReplyEnable]) {
            NSString *reply = [DPConfig objectForKey:kAntiRevokeReplyContent] ?: @"对方撤回了一条消息";
            [DPHelper after:1.0 onMain:^{
                // 通过 CMessageMgr 发送文本消息
                id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
                if (!mgr) return;
                CMessageWrap *wrap = [[objc_getClass("CMessageWrap") alloc] init];
                [wrap setValue:origFromUsr forKey:@"m_nsToUsr"];
                [wrap setValue:reply forKey:@"m_nsContent"];
                [wrap setValue:@1 forKey:@"nMessageType"];
                [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[wrap]];
            }];
        }
    } @catch (NSException *e) {
        DPLogWarn(@"防撤回处理异常：%@", e);
    }
}

@interface AntiRevokeHook : NSObject @end
@implementation AntiRevokeHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class cls = objc_getClass("CMessageMgr");
    if (cls) {
        Method m = class_getInstanceMethod(cls, @selector(onRevokeMsg:));
        if (m) {
            orig_onRevokeMsg = (void (*)(id, SEL, id))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_onRevokeMsg);
            DPLogInfo(@"AntiRevoke: hooked CMessageMgr onRevokeMsg:");
        }
    }
}
@end
