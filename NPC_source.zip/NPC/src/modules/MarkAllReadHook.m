// MarkAllReadHook.m — 功能13: 一键标记已读
//
// 参考 MiYou 配置项 mIsAllGroupUndeno（一键清除所有群未读）。
// 在首页(NewMainFrameViewController)导航栏右侧插入"全部已读"按钮，
// 点击后通过 CMessageMgr 标记所有会话已读并刷新红点/未读。
//
// 修复要点：
//   1) 仅 hook 一个方法(viewDidLoad)，按钮用 tag 去重，避免重复插入。
//   2) 标记已读优先调用微信原生方法(markAllMessagesRead / markAllAsRead /
//      clearAllUnReadCount)，不同版本方法名不同则逐一尝试；都不存在时
//      兜底遍历会话逐个标记，全程 @try 保护。
//   3) 用 DPHelper runOnMain 保证 UI 在主线程。

#import <objc/runtime.h>
#import <UIKit/UIKit.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

static const NSInteger NPCMarkAllReadBtnTag = 99013;

#pragma mark - 给 NewMainFrameViewController 注入按钮与点击逻辑
@interface NSObject (NPCMarkAllRead)
- (void)npc_markAllReadTapped;
- (void)npc_markEachSessionRead:(id)mgr;
@end

@implementation NSObject (NPCMarkAllRead)

- (void)npc_markAllReadTapped {
    [DPHelper runOnMain:^{
        @try {
            id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
            if (!mgr) return;
            // 优先调用微信原生"标记全部已读"，逐一尝试不同版本方法名
            NSArray<NSString *> *markSels = @[@"markAllMessagesRead", @"markAllAsRead", @"clearAllUnReadCount"];
            BOOL done = NO;
            for (NSString *sel in markSels) {
                SEL s = NSSelectorFromString(sel);
                if ([mgr respondsToSelector:s]) {
                    [DPHelper performSelectorOnObject:mgr sel:s withObjects:@[]];
                    done = YES;
                    break;
                }
            }
            if (!done) {
                [self npc_markEachSessionRead:mgr];
            }
            // 刷新首页 UI 与红点
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NPC_MarkAllReadDone" object:nil];
            [DPHelper showAlertOnTopWithTitle:@"已读" message:@"已将全部会话标记为已读"];
        } @catch (NSException *e) {
            DPLogWarn(@"MarkAllRead 执行异常：%@", e);
        }
    }];
}

- (void)npc_markEachSessionRead:(id)mgr {
    @try {
        NSArray *sessions = nil;
        if ([mgr respondsToSelector:@selector(getSessionList)]) {
            sessions = [DPHelper performSelectorOnObject:mgr sel:@selector(getSessionList) withObjects:@[]];
        } else if ([mgr respondsToSelector:@selector(getAllSessions)]) {
            sessions = [DPHelper performSelectorOnObject:mgr sel:@selector(getAllSessions) withObjects:@[]];
        }
        for (id sess in sessions) {
            @try {
                if ([sess respondsToSelector:@selector(markAllMessagesRead)]) {
                    [DPHelper performSelectorOnObject:sess sel:@selector(markAllMessagesRead) withObjects:@[]];
                } else if ([sess respondsToSelector:@selector(markRead)]) {
                    [DPHelper performSelectorOnObject:sess sel:@selector(markRead) withObjects:@[]];
                }
            } @catch (__unused id e) {}
        }
    } @catch (__unused id e) {}
}

@end

#pragma mark - hook NewMainFrameViewController
static void (*orig_NMF_MAR_viewDidLoad)(id, SEL);
static void hook_NMF_MAR_viewDidLoad(id self, SEL _cmd) {
    if (orig_NMF_MAR_viewDidLoad) orig_NMF_MAR_viewDidLoad(self, _cmd);
    if (![DPConfig boolForSwitchKey:kSwitchMarkAllRead]) return;
    [DPHelper after:0.3 onMain:^{
        @try {
            UINavigationItem *navItem = [self valueForKey:@"navigationItem"];
            if (!navItem) return;
            // tag 去重，避免重复插入
            for (UIBarButtonItem *b in navItem.rightBarButtonItems) {
                if (b.tag == NPCMarkAllReadBtnTag) return;
            }
            UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"全部已读"
                                                                     style:UIBarButtonItemStylePlain
                                                                    target:self
                                                                    action:@selector(npc_markAllReadTapped)];
            item.tag = NPCMarkAllReadBtnTag;
            NSMutableArray *arr = [NSMutableArray arrayWithArray:navItem.rightBarButtonItems ?: @[]];
            [arr addObject:item];
            navItem.rightBarButtonItems = arr;
        } @catch (NSException *e) {
            DPLogWarn(@"MarkAllRead 插入按钮异常：%@", e);
        }
    }];
}

@interface MarkAllReadHook : NSObject @end
@implementation MarkAllReadHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class nmf = objc_getClass("NewMainFrameViewController");
    if (nmf) {
        Method m = class_getInstanceMethod(nmf, @selector(viewDidLoad));
        if (m) {
            orig_NMF_MAR_viewDidLoad = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_NMF_MAR_viewDidLoad);
            DPLogInfo(@"MarkAllRead: hooked NewMainFrameViewController viewDidLoad");
        }
    }
}
@end
