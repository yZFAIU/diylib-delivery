// AutoFollowHook.m — 功能3: 自动跟圈（朋友圈自动点赞/评论）
//
// 修复要点：
//   1) import DPPrivateClasses.h 移除重复前向声明。
//   2) onDataUpdated 只本模块 hook，无多模块冲突，保留独立 hook。
//   3) orig 调用前加非空判断。
//   4) sProcessedTids 用 dispatch_once 懒初始化后，@synchronized 前确保非 nil。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

static NSMutableArray<NSString *> *sProcessedTids;
static NSInteger sTodayCount = 0;
static NSString *sTodayDate = nil;

// 确保 sProcessedTids 已初始化（线程安全）
static void ensureProcessedTids(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sProcessedTids = [NSMutableArray array];
    });
}

static BOOL shouldFollow(WCDataItem *item) {
    // 关键词过滤
    NSArray *keywords = [DPConfig objectForKey:kAutoFollowKeywords] ?: @[];
    if (keywords.count > 0) {
        NSString *content = item.m_nsContent ?: @"";
        __block BOOL hit = NO;
        [keywords enumerateObjectsUsingBlock:^(NSString *kw, NSUInteger idx, BOOL *stop) {
            if ([content containsString:kw]) { hit = YES; *stop = YES; }
        }];
        if (!hit) return NO;
    }
    return YES;
}

static void doFollowItem(WCDataItem *item) {
    if (!item || !item.m_nsTid) return;
    ensureProcessedTids();
    // 去重
    @synchronized (sProcessedTids) {
        if ([sProcessedTids containsObject:item.m_nsTid]) return;
        [sProcessedTids addObject:item.m_nsTid];
    }
    // 每日上限
    NSDateFormatter *fmt = [NSDateFormatter new];
    fmt.dateFormat = @"yyyy-MM-dd";
    fmt.timeZone = [NSTimeZone localTimeZone];
    NSString *today = [fmt stringFromDate:[NSDate date]];
    if (![today isEqualToString:sTodayDate ?: @""]) {
        sTodayDate = today;
        sTodayCount = 0;
    }
    NSInteger max = [DPConfig integerForKey:kAutoFollowMaxNumPerDay];
    if (max > 0 && sTodayCount >= max) {
        DPLogInfo(@"自动跟圈达到每日上限 %ld", (long)max);
        return;
    }
    NSTimeInterval interval = (NSTimeInterval)[DPConfig integerForKey:kAutoFollowIntervalSec];
    if (interval < 1) interval = 5;
    [DPHelper after:interval onMain:^{
        @try {
            WCFacade *facade = [objc_getClass("WCFacade") performSelector:@selector(sharedInstance)];
            if (!facade) return;
            if ([DPConfig boolForSwitchKey:kAutoFollowLikeEnable] && !item.likeFlag) {
                [facade performSelector:@selector(likeAction:) withObject:item];
                DPLogInfo(@"自动点赞 tid=%@", item.m_nsTid);
            }
            if ([DPConfig boolForSwitchKey:kAutoFollowCommentEnable]) {
                NSArray *comments = [DPConfig objectForKey:kAutoFollowComments] ?: @[];
                if (comments.count > 0) {
                    NSString *text = comments[arc4random_uniform((uint32_t)comments.count)];
                    // commentAction:text: 两个参数，用 invocation
                    NSMethodSignature *sig = [facade methodSignatureForSelector:@selector(commentAction:text:)];
                    if (sig) {
                        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
                        [inv setTarget:facade];
                        [inv setSelector:@selector(commentAction:text:)];
                        [inv setArgument:&item atIndex:2];
                        [inv setArgument:&text atIndex:3];
                        [inv invoke];
                        DPLogInfo(@"自动评论 tid=%@ text=%@", item.m_nsTid, text);
                    }
                }
            }
            sTodayCount++;
        } @catch (NSException *e) {
            DPLogWarn(@"自动跟圈执行异常：%@", e);
        }
    }];
}

// hook 朋友圈刷新完成
static void (*orig_onDataUpdated)(id, SEL);
static void hook_onDataUpdated(id self, SEL _cmd) {
    if (orig_onDataUpdated) orig_onDataUpdated(self, _cmd);
    if (![DPConfig boolForSwitchKey:kSwitchAutoFollow]) return;
    @try {
        id provider = [self valueForKey:@"m_dataProvider"];
        if ([provider respondsToSelector:@selector(allItems)]) {
            NSArray *items = [provider performSelector:@selector(allItems)];
            for (id raw in items) {
                if ([raw isKindOfClass:[WCDataItem class]]) {
                    doFollowItem((WCDataItem *)raw);
                }
            }
        }
    } @catch (NSException *e) {
        DPLogWarn(@"自动跟圈数据获取异常：%@", e);
    }
}

@interface AutoFollowHook : NSObject @end
@implementation AutoFollowHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class cls = objc_getClass("WCTimeLineViewController");
    if (cls) {
        Method m = class_getInstanceMethod(cls, @selector(onDataUpdated));
        if (m) {
            orig_onDataUpdated = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_onDataUpdated);
            DPLogInfo(@"AutoFollow: hooked WCTimeLineViewController");
        }
    }
}
@end
