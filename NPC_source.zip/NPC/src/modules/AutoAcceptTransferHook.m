// AutoAcceptTransferHook.m — 功能10: 自动接收转账
//
// 修复要点：
//   1) import DPPrivateClasses.h 移除重复前向声明。
//   2) onTransferButtonClicked: 只本模块 hook，无多模块冲突，保留独立 hook。
//   3) orig 调用前加非空判断。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

// hook 转账消息点击
static void (*orig_onTransferClick)(id, SEL, id);
static void hook_onTransferClick(id self, SEL _cmd, id sender) {
    if (orig_onTransferClick) orig_onTransferClick(self, _cmd, sender);
    if (![DPConfig boolForSwitchKey:kSwitchAutoAcceptTransfer]) return;
    NSTimeInterval delay = [DPConfig doubleForKey:kAutoTransferDelaySec];
    if (delay < 1) delay = 2.0;
    [DPHelper after:delay onMain:^{
        @try {
            // 从 self 拿 WCPayInfoItem
            id item = nil;
            @try { item = [self valueForKey:@"m_payInfoItem"]; } @catch (__unused id e) {}
            if (!item) {
                @try { item = [self valueForKey:@"payInfoItem"]; } @catch (__unused id e) {}
            }
            if (!item) return;
            NSString *payId = [item valueForKey:@"m_nsPayId"] ?: [item valueForKey:@"payId"];
            id logic = [[objc_getClass("WCPayTransferMoneyControlLogic") alloc] init];
            if (logic) {
                if (payId) {
                    [DPHelper performSelectorOnObject:logic sel:@selector(acceptTransferWithPayId:) withObjects:@[payId]];
                } else {
                    [logic performSelector:@selector(acceptTransfer)];
                }
                DPLogInfo(@"已自动接收转账 payId=%@", payId);
                // 自动回复
                if ([DPConfig boolForSwitchKey:kAutoTransferReplyEnable]) {
                    NSString *reply = [DPConfig objectForKey:kAutoTransferReplyContent] ?: @"已收款，谢谢";
                    id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
                    if (mgr) {
                        id wrap = [[objc_getClass("CMessageWrap") alloc] init];
                        NSString *peer = [self valueForKey:@"m_nsFromUsr"];
                        [wrap setValue:peer forKey:@"m_nsToUsr"];
                        [wrap setValue:reply forKey:@"m_nsContent"];
                        [wrap setValue:@1 forKey:@"nMessageType"];
                        [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[wrap]];
                    }
                }
            }
        } @catch (NSException *e) {
            DPLogWarn(@"自动接收转账异常：%@", e);
        }
    }];
}

@interface AutoAcceptTransferHook : NSObject @end
@implementation AutoAcceptTransferHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 转账消息点击 hook 类名多种可能，尝试多个
    NSArray *clsNames = @[@"WCMessageNodeView", @"WCPayTransferMsgNodeView", @"TransferMessageNodeView"];
    for (NSString *name in clsNames) {
        Class cls = objc_getClass([name UTF8String]);
        if (cls) {
            Method m = class_getInstanceMethod(cls, @selector(onTransferButtonClicked:));
            if (m) {
                orig_onTransferClick = (void (*)(id, SEL, id))method_getImplementation(m);
                method_setImplementation(m, (IMP)hook_onTransferClick);
                DPLogInfo(@"AutoAcceptTransfer: hooked %@", name);
                break;
            }
        }
    }
}
@end
