// AutoRedEnvelopeHook.m — 功能11: 抢红包
//
// 修复要点：
//   1) 原实现直接 hook CMessageMgr AddMsg: 与其他三模块冲突。
//      改为订阅 DPMessageDispatcher，phase=1（orig 后）检测红包消息。
//   2) 移除重复前向声明，import DPPrivateClasses.h。
//   3) orig_xxx 调用前加非空判断。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

static NSString *selfWxid() {
    id mgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
    if (!mgr) return @"";
    id contact = [mgr performSelector:@selector(getSelfContact)];
    return [contact valueForKey:@"m_nsUsrName"] ?: @"";
}

static BOOL isRedEnvelopeMsg(CMessageWrap *msg) {
    int type = [[msg valueForKey:@"nMessageType"] intValue];
    if (type != 49) return NO;
    NSString *content = msg.m_nsContent ?: @"";
    return [content containsString:@"wxpay"] || [content containsString:@"wcpay"] || ([content containsString:@"<appmsg"] && [content containsString:@"红包"]);
}

static BOOL shouldGrab(CMessageWrap *msg) {
    NSString *from = msg.m_nsFromUsr ?: @"";
    BOOL isGroup = [from hasSuffix:@"@chatroom"];
    // 不抢私聊
    if (!isGroup && [DPConfig boolForSwitchKey:kRedEnvelopeSkipPrivate]) return NO;
    // 不抢自己发的
    if ([DPConfig boolForSwitchKey:kRedEnvelopeSkipSelf]) {
        NSString *me = selfWxid();
        if (me.length > 0 && [from containsString:me]) return NO;
    }
    // 群白名单
    if (isGroup) {
        NSArray *filter = [DPConfig objectForKey:kRedEnvelopeGroupFilter] ?: @[];
        if (filter.count > 0 && ![filter containsObject:from]) return NO;
    }
    // 关键词过滤
    NSArray *keywords = [DPConfig objectForKey:kRedEnvelopeKeywordFilter] ?: @[];
    if (keywords.count > 0) {
        NSString *src = msg.m_nsMsgSource ?: msg.m_nsContent ?: @"";
        __block BOOL hit = NO;
        [keywords enumerateObjectsUsingBlock:^(NSString *kw, NSUInteger idx, BOOL *stop) {
            if ([src containsString:kw]) { hit = YES; *stop = YES; }
        }];
        if (!hit) return NO;
    }
    return YES;
}

static void grabRedEnvelope(CMessageWrap *msg) {
    NSTimeInterval baseDelay = [DPConfig doubleForKey:kRedEnvelopeDelaySec];
    if (baseDelay < 0.3) baseDelay = 1.5;
    // 随机抖动 ±0.5 秒
    NSTimeInterval jitter = ((arc4random_uniform(1000)) / 1000.0 - 0.5);
    NSTimeInterval delay = baseDelay + jitter;
    [DPHelper after:delay onMain:^{
        @try {
            id hbMgr = [objc_getClass("HongBaoMgr") performSelector:@selector(sharedInstance)];
            if (hbMgr) {
                [DPHelper performSelectorOnObject:hbMgr sel:@selector(openRedEnvelope:) withObjects:@[msg]];
                DPLogInfo(@"已抢红包 from=%@ delay=%.2f", msg.m_nsFromUsr, delay);
            }
            // 自动感谢
            if ([DPConfig boolForSwitchKey:kRedEnvelopeReplyEnable]) {
                NSString *reply = [DPConfig objectForKey:kRedEnvelopeReplyText] ?: @"谢谢老板";
                [DPHelper after:1.0 onMain:^{
                    id msgMgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
                    if (!msgMgr) return;
                    id wrap = [[objc_getClass("CMessageWrap") alloc] init];
                    [wrap setValue:msg.m_nsFromUsr forKey:@"m_nsToUsr"];
                    [wrap setValue:reply forKey:@"m_nsContent"];
                    [wrap setValue:@1 forKey:@"nMessageType"];
                    [DPHelper performSelectorOnObject:msgMgr sel:@selector(AddMsg:) withObjects:@[wrap]];
                }];
            }
        } @catch (NSException *e) {
            DPLogWarn(@"抢红包异常：%@", e);
        }
    }];
}

static void onAddMsgHandler_RE(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchAutoRedEnvelope]) return;
    if (phase != 1) return; // orig 调用后处理
    if (isRedEnvelopeMsg(msg) && shouldGrab(msg)) {
        grabRedEnvelope(msg);
    }
}

@interface AutoRedEnvelopeHook : NSObject @end
@implementation AutoRedEnvelopeHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 订阅 AddMsg 分发器
    [[DPMessageDispatcher shared] subscribeForKey:@"AutoRedEnvelope"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler_RE(msg, phase);
    }];
    DPLogInfo(@"AutoRedEnvelope: 已订阅 AddMsg 分发器");
}
@end
