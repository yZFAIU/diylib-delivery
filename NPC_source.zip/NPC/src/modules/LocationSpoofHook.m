// LocationSpoofHook.m — 功能1: 修改微信定位
//
// 修复要点：
//   1) 原实现用 performSelector:withObject:withObject: 传 CLLocationCoordinate2D 结构体，
//      performSelector 只接受 id，把 NSValue 指针当结构体内存读 → 内存非法访问闪退。
//      改用 NSInvocation 正确传递结构体参数。
//   2) sureSelectLocation/onSureSelectLocation 只本模块 hook，无多模块冲突，保留独立 hook。
//   3) import DPPrivateClasses.h 移除重复声明。
//   4) orig 调用前加非空判断。

#import <objc/runtime.h>
#import <CoreLocation/CoreLocation.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

// 通过 NSInvocation 安全调用 initWithCoordinate:address:（结构体参数）
static MMLocationData *newLocationDataWithCoord(CLLocationCoordinate2D coord, NSString *addr) {
    Class cls = objc_getClass("MMLocationData");
    if (!cls) return nil;
    id instance = [[cls alloc] init];
    SEL sel = @selector(initWithCoordinate:address:);
    NSMethodSignature *sig = [instance methodSignatureForSelector:sel];
    if (!sig) {
        // 该类没有此初始化方法，用 KVC 直接设值
        [instance setValue:[NSString stringWithFormat:@"%.6f", coord.latitude] forKey:@"latitude"];
        [instance setValue:[NSString stringWithFormat:@"%.6f", coord.longitude] forKey:@"longitude"];
        [instance setValue:addr forKey:@"tagName"];
        [instance setValue:addr forKey:@"address"];
        return instance;
    }
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    [inv setTarget:instance];
    [inv setSelector:sel];
    // 结构体参数必须用 setArgument: 传地址
    [inv setArgument:&coord atIndex:2];
    [inv setArgument:&addr atIndex:3];
    [inv invoke];
    // initWithCoordinate: 返回 instancetype，需取返回值。
    // ARC 下 getReturnValue: 取出的对象引用需用 __unsafe_unretained 接收，
    // 否则可能造成双重释放（ invocation 不持有返回值的所有权）。
    __unsafe_unretained id ret = nil;
    if (sig.methodReturnLength > 0) {
        [inv getReturnValue:&ret];
        if (ret) instance = ret;
    }
    // 兜底用 KVC 确保字段正确
    [instance setValue:[NSString stringWithFormat:@"%.6f", coord.latitude] forKey:@"latitude"];
    [instance setValue:[NSString stringWithFormat:@"%.6f", coord.longitude] forKey:@"longitude"];
    [instance setValue:addr forKey:@"tagName"];
    [instance setValue:addr forKey:@"address"];
    return instance;
}

static void (*orig_sureSelectLocation)(id, SEL);
static void hook_sureSelectLocation(id self, SEL _cmd) {
    if ([DPConfig boolForSwitchKey:kSwitchLocationSpoof]) {
        @try {
            double lat = [DPConfig doubleForKey:kLocationLatitude];
            double lon = [DPConfig doubleForKey:kLocationLongitude];
            NSString *addr = [DPConfig objectForKey:kLocationAddress] ?: @"自定义位置";
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lon);
            MMLocationData *fake = newLocationDataWithCoord(coord, addr);
            if (fake) {
                [self setValue:fake forKey:@"selectedLocation"];
                DPLogInfo(@"定位已伪造 lat=%.6f lon=%.6f addr=%@", lat, lon, addr);
            }
        } @catch (NSException *e) {
            DPLogWarn(@"定位伪造失败：%@", e);
        }
    }
    if (orig_sureSelectLocation) {
        orig_sureSelectLocation(self, _cmd);
    }
}

// 朋友圈"所在位置"选择
static void (*orig_onSureSelectLocation)(id, SEL);
static void hook_onSureSelectLocation(id self, SEL _cmd) {
    if ([DPConfig boolForSwitchKey:kSwitchLocationSpoof] && [DPConfig boolForSwitchKey:kLocationForTimeline]) {
        @try {
            double lat = [DPConfig doubleForKey:kLocationLatitude];
            double lon = [DPConfig doubleForKey:kLocationLongitude];
            NSString *addr = [DPConfig objectForKey:kLocationAddress] ?: @"自定义位置";
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lon);
            id loc = newLocationDataWithCoord(coord, addr);
            if (loc) {
                // 尝试多种可能的属性名
                @try { [self setValue:loc forKey:@"selectedLocation"]; } @catch (__unused id e) {}
                @try { [self setValue:loc forKey:@"location"]; } @catch (__unused id e) {}
            }
            DPLogInfo(@"朋友圈定位已伪造");
        } @catch (NSException *e) {
            DPLogWarn(@"朋友圈定位伪造失败：%@", e);
        }
    }
    if (orig_onSureSelectLocation) {
        orig_onSureSelectLocation(self, _cmd);
    }
}

@interface LocationSpoofHook : NSObject @end
@implementation LocationSpoofHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class cls = objc_getClass("SendMessageLocationController");
    if (cls) {
        Method m = class_getInstanceMethod(cls, @selector(sureSelectLocation));
        if (m) {
            orig_sureSelectLocation = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_sureSelectLocation);
            DPLogInfo(@"LocationSpoof: hooked SendMessageLocationController");
        }
    }
    Class tlCls = objc_getClass("WCSelectLocationViewController");
    if (tlCls) {
        Method m = class_getInstanceMethod(tlCls, @selector(onSureSelectLocation));
        if (m) {
            orig_onSureSelectLocation = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_onSureSelectLocation);
        }
    }
}
@end
