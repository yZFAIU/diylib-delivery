// CameraRecognizeHook.m — 功能19: 启用相机识别
//
// 参考 MiYou mIsSanCodeInCamera（在相机中启用扫一扫/二维码识别）。
// 在微信相机页启用二维码/条码识别：给 AVCaptureMetadataOutput 追加可识别类型，
// 并尝试打开微信相机内的扫码图层属性(多版本兼容，失败忽略)。
//
// 与 DisableFunctionHook(禁用扫一扫相机) 互不影响：本模块开关独立，且仅追加识别类型。

#import <objc/runtime.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

// key=Class、value=IMP 都不是 CF 对象，必须用"指针等式、不 retain"的空回调，
// 否则 kCFType 回调会对 Class 指针调用 CFRetain 而读坏类内存。
static CFDictionaryKeyCallBacks kPtrKeyCB = {0, NULL, NULL, NULL, NULL, NULL};
static CFDictionaryValueCallBacks kPtrValCB = {0, NULL, NULL, NULL};
static CFMutableDictionaryRef sOrigViewDidLoadMap = NULL;

// 按类查 orig，并向上回溯父类（兼顾"只 hook 了父类、子类实例也走此 hook"的情况）
static IMP origIMPForClass(Class cls) {
    while (cls) {
        IMP imp = CFDictionaryGetValue(sOrigViewDidLoadMap, (__bridge const void *)(cls));
        if (imp) return imp;
        cls = class_getSuperclass(cls);
    }
    return NULL;
}

static NSArray<NSString *> *cameraVCClasses(void) {
    return @[
        @"MMCameraViewController",
        @"WCCameraViewController",
        @"WeChatCaptureController",
        @"SightCaptureController"
    ];
}

// 给 capture session 的 metadataOutput 追加二维码/条码类型
static void enableQRInSession(AVCaptureSession *session) {
    @try {
        for (AVCaptureOutput *out in session.outputs) {
            if ([out isKindOfClass:[AVCaptureMetadataOutput class]]) {
                AVCaptureMetadataOutput *mo = (AVCaptureMetadataOutput *)out;
                NSMutableSet *types = [NSMutableSet setWithArray:mo.availableMetadataObjectTypes];
                [types addObjectsFromArray:@[
                    AVMetadataObjectTypeQRCode,
                    AVMetadataObjectTypeEAN13Code,
                    AVMetadataObjectTypeEAN8Code,
                    AVMetadataObjectTypeCode128Code,
                    AVMetadataObjectTypeCode39Code,
                    AVMetadataObjectTypePDF417Code,
                    AVMetadataObjectTypeAztecCode
                ]];
                mo.metadataObjectTypes = [types allObjects];
                DPLogInfo(@"CameraRecognize: 已为 metadataOutput 追加二维码识别类型");
            }
        }
    } @catch (NSException *e) {
        DPLogWarn(@"CameraRecognize session 处理异常：%@", e);
    }
}

static void hook_CR_viewDidLoad(id self, SEL _cmd) {
    IMP orig = origIMPForClass([self class]);
    if (orig) ((void (*)(id, SEL))orig)(self, _cmd);
    if (![DPConfig boolForSwitchKey:kSwitchCameraRecognize]) return;
    [DPHelper after:0.3 onMain:^{
        @try {
            // 1) 直接拿 capture session 追加识别类型（最可靠路径）
            id session = nil;
            @try { session = [self valueForKey:@"m_captureSession"] ?: [self valueForKey:@"captureSession"]; } @catch (__unused id e) {}
            if (session && [session isKindOfClass:[AVCaptureSession class]]) {
                enableQRInSession((AVCaptureSession *)session);
            }
            // 2) 尝试打开微信内置扫码图层属性（多版本兼容，失败忽略）
            NSArray<NSString *> *scanProps = @[@"m_showScanCode", @"m_isOpenScan", @"m_isSanCodeInCamera", @"m_enableScan"];
            for (NSString *p in scanProps) {
                @try { [self setValue:@YES forKey:p]; } @catch (__unused id e) {}
            }
            DPLogInfo(@"CameraRecognize: 已处理相机页(%@)", NSStringFromClass([self class]));
        } @catch (NSException *e) {
            DPLogWarn(@"CameraRecognize 异常：%@", e);
        }
    }];
}

@interface CameraRecognizeHook : NSObject @end
@implementation CameraRecognizeHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    sOrigViewDidLoadMap = CFDictionaryCreateMutable(NULL, 0, &kPtrKeyCB, &kPtrValCB);
    for (NSString *clsName in cameraVCClasses()) {
        Class cls = objc_getClass(clsName.UTF8String);
        if (!cls) continue;
        Method m = class_getInstanceMethod(cls, @selector(viewDidLoad));
        if (!m) continue;
        IMP orig = method_getImplementation(m);
        CFDictionarySetValue(sOrigViewDidLoadMap, (__bridge const void *)(cls), (const void *)orig);
        method_setImplementation(m, (IMP)hook_CR_viewDidLoad);
        DPLogInfo(@"CameraRecognize: hooked %@", clsName);
    }
}
@end
