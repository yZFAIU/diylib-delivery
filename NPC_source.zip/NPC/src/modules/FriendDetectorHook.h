// FriendDetectorHook.h — 好友检测模块头文件
//
// DPPreferencesListController.m 需要 import 本头文件以调用检测接口。

#import <Foundation/Foundation.h>

@interface FriendDetectorHook : NSObject

+ (instancetype)shared;

/// 开始检测所有好友（由设置面板按钮触发）
- (void)detectAllFriends;

@end
