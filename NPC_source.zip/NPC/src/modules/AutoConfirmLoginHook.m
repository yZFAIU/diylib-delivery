// AutoConfirmLoginHook.m — 功能18: 自动确认登陆
//
// 参考 MiYou mIsAutoConfirmLogin。
// 在"确认登录"页面(扫一扫 PC/Mac 登录确认)出现时自动点击确认按钮。
// 兼容多版本：尝试常见确认页 VC 类与确认按钮属性/动作。

#import <objc/runtime.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

// 每个候选 VC 类保存各自的 orig IMP，避免多类共用一个 orig 指针导致错乱
// （即 diylib FIXES 中强调的"多模块重复 hook 同方法"同类问题）。
// 注意：key=Class、value=IMP 都不是 CF 对象，必须用"指针等式、不 retain"的空回调，
// 否则 kCFType 回调会对 Class 指针调用 CFRetain 而读坏类内存。
static CFDictionaryKeyCallBacks kPtrKeyCB = {0, NULL, NULL, NULL, NULL, NULL};
static CFDictionaryValueCallBacks kPtrValCB = {0, NULL, NULL, NULL};
static CFMutableDictionaryRef sOrigWillAppearMap = NULL;

// 按类查 orig，并向上回溯父类（兼顾"只 hook 了父类、子类实例也走此 hook"的情况）
static IMP origIMPForClass(Class cls) {
    while (cls) {
        IMP imp = CFDictionaryGetValue(sOrigWillAppearMap, (__bridge const void *)(cls));
        if (imp) return imp;
        cls = class_getSuperclass(cls);
    }
    return NULL;
}

static NSArray<NSString *> *confirmVCClasses(void) {
    return @[
        @"WCWebloginAuthViewController",
        @"WCWebLoginViewController",
        @"WCAccountLoginControlLogic",
        @"LoginViewController",
        @"ConfirmLoginViewController"
    ];
}

// 找到并触发确认按钮 / 确认动作
static void tapConfirmIfPossible(id vc) {
    // 优先：直接找到确认按钮并触发 touchUpInside
    NSArray<NSString *> *btnKeys = @[@"m_confirmButton", @"confirmButton", @"m_okButton", @"m_loginButton"];
    for (NSString *k in btnKeys) {
        id btn = nil;
        @try { btn = [vc valueForKey:k]; } @catch (__unused id e) {}
        if (btn && [btn respondsToSelector:@selector(sendActionsForControlEvents:)]) {
            [DPHelper after:0.5 onMain:^{
                [btn sendActionsForControlEvents:UIControlEventTouchUpInside];
            }];
            DPLogInfo(@"AutoConfirmLogin: 已触发确认按钮(%@)", k);
            return;
        }
    }
    // 退而求其次：直接调用确认动作
    NSArray<NSString *> *confirmSels = @[@"onConfirmLogin", @"confirmLogin", @"onOK", @"onClickOk"];
    for (NSString *sel in confirmSels) {
        SEL s = NSSelectorFromString(sel);
        if ([vc respondsToSelector:s]) {
            [DPHelper after:0.5 onMain:^{
                [DPHelper performSelectorOnObject:vc sel:s withObjects:@[]];
            }];
            DPLogInfo(@"AutoConfirmLogin: 已调用确认方法(%@)", sel);
            return;
        }
    }
    DPLogWarn(@"AutoConfirmLogin: 未找到确认按钮/动作(%@)", NSStringFromClass([vc class]));
}

static void hook_ACL_viewWillAppear(id self, SEL _cmd, BOOL animated) {
    IMP orig = origIMPForClass([self class]);
    if (orig) ((void (*)(id, SEL, BOOL))orig)(self, _cmd, animated);
    if (![DPConfig boolForSwitchKey:kSwitchAutoConfirmLogin]) return;
    double delay = [DPConfig doubleForKey:kAutoConfirmLoginDelay];
    if (delay < 0) delay = 0;
    [DPHelper after:delay onMain:^{
        tapConfirmIfPossible(self);
    }];
}

@interface AutoConfirmLoginHook : NSObject @end
@implementation AutoConfirmLoginHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    sOrigWillAppearMap = CFDictionaryCreateMutable(NULL, 0, &kPtrKeyCB, &kPtrValCB);
    for (NSString *clsName in confirmVCClasses()) {
        Class cls = objc_getClass(clsName.UTF8String);
        if (!cls) continue;
        Method m = class_getInstanceMethod(cls, @selector(viewWillAppear:));
        if (!m) continue;
        IMP orig = method_getImplementation(m);
        CFDictionarySetValue(sOrigWillAppearMap, (__bridge const void *)(cls), (const void *)orig);
        method_setImplementation(m, (IMP)hook_ACL_viewWillAppear);
        DPLogInfo(@"AutoConfirmLogin: hooked %@", clsName);
    }
}
@end
