// DisableFunctionHook.m — 功能5: 禁用功能（黄白插件的 DisableWeChat）
//
// 修复要点：
//   1) import DPPrivateClasses.h 移除重复前向声明。
//   2) orig 调用前加非空判断，避免空指针跳转。
//   3) 移除未使用的 orig_setting_cell_hidden 声明。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

// hook NewMainFrameViewController 隐藏首页搜索栏/未读数
static void (*orig_NMF_viewDidLoad)(id, SEL);
static void hook_NMF_viewDidLoad(id self, SEL _cmd) {
    if (orig_NMF_viewDidLoad) orig_NMF_viewDidLoad(self, _cmd);
    [DPHelper after:0.3 onMain:^{
        if ([DPConfig boolForSwitchKey:kDisableMainFrameSearchBar]) {
            @try {
                id searchBar = [self valueForKey:@"m_searchBarView"];
                [searchBar setValue:@YES forKey:@"hidden"];
            } @catch (__unused id e) {}
        }
        if ([DPConfig boolForSwitchKey:kDisableUnReadCount]) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NPC_HideUnReadBadge" object:nil];
        }
    }];
}

// hook AVCaptureSession 阻止扫一扫相机
static void (*orig_AVC_startRunning)(id, SEL);
static void hook_AVC_startRunning(id self, SEL _cmd) {
    if ([DPConfig boolForSwitchKey:kDisableAVCapture]) {
        DPLogInfo(@"已拦截 AVCaptureSession startRunning");
        return;
    }
    if (orig_AVC_startRunning) orig_AVC_startRunning(self, _cmd);
}

// hook EmoticonStorePanelViewController 隐藏表情商店
static void (*orig_Emo_viewWillAppear)(id, SEL, BOOL);
static void hook_Emo_viewWillAppear(id self, SEL _cmd, BOOL animated) {
    if (orig_Emo_viewWillAppear) orig_Emo_viewWillAppear(self, _cmd, animated);
    if ([DPConfig boolForSwitchKey:kDisableEmoticonStore]) {
        UIViewController *selfVC = (UIViewController *)self;
        [selfVC.navigationController popViewControllerAnimated:NO];
    }
}

@interface DisableFunctionHook : NSObject @end
@implementation DisableFunctionHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // NewMainFrameViewController
    Class nmf = objc_getClass("NewMainFrameViewController");
    if (nmf) {
        Method m = class_getInstanceMethod(nmf, @selector(viewDidLoad));
        if (m) {
            orig_NMF_viewDidLoad = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_NMF_viewDidLoad);
        }
    }
    // AVCaptureSession
    Class avc = objc_getClass("AVCaptureSession");
    if (avc) {
        Method m = class_getInstanceMethod(avc, @selector(startRunning));
        if (m) {
            orig_AVC_startRunning = (void (*)(id, SEL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_AVC_startRunning);
        }
    }
    // EmoticonStorePanelViewController
    Class emo = objc_getClass("EmoticonStorePanelViewController");
    if (emo) {
        Method m = class_getInstanceMethod(emo, @selector(viewWillAppear:));
        if (m) {
            orig_Emo_viewWillAppear = (void (*)(id, SEL, BOOL))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_Emo_viewWillAppear);
        }
    }
    DPLogInfo(@"DisableFunction hook installed");
}
@end
