// KeywordReminderHook.m — 功能16: 关键词提醒（已修复）
//
// 参考 MiYou MiYouKeywordTipsController / MiYouKeywordListViewController（关键词提醒）。
// 订阅 AddMsg 分发器(orig 后)，命中提醒关键词时弹窗/通知/推送文件助手。
//
// 修复要点（用户标注"需修复"）：
//   原实现存在 5 类问题，已全部修复：
//   1) 重入死锁/递归：handler 内同步调用 AddMsg 会重入分发器。现改为
//      [DPHelper after:delay onMain:] 异步派发，绝不在 handler 内同步触发 AddMsg。
//   2) 系统消息误报：type==10000 系统消息（如"你邀请xxx""xxx加入群聊"）也被匹配提醒。
//      现跳过。
//   3) 自己消息误报：自己发的消息也触发提醒。现跳过自身(wxid)。
//   4) 重复提醒：同一消息或同一关键词短时间内重复命中。现按 内容hash+关键词 去重，
//      并加 3s 节流，避免刷屏。
//   5) 非主线程弹窗：通知/弹窗/震动未在主线。现统一 runOnMain / after onMain。

#import <objc/runtime.h>
#import <AudioToolbox/AudioToolbox.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"

static NSMutableSet *sRemindedHashes;       // 已提醒去重集合
static NSDate *sLastRemindTime;             // 节流时间戳
static const NSTimeInterval kRemindThrottle = 3.0;

static NSString *hashOf(NSString *from, NSString *content, NSString *kw) {
    return [NSString stringWithFormat:@"%@|%@|%@", from ?: @"", content ?: @"", kw ?: @""];
}

static void fireReminder(NSString *from, NSString *content, NSString *kw) {
    NSString *title = [NSString stringWithFormat:@"关键词提醒：%@", kw];
    NSString *body = [NSString stringWithFormat:@"来自 %@\n%@", from ?: @"?", content ?: @""];
    // 修复5：弹窗在主线程
    if ([DPConfig boolForSwitchKey:kKeywordReminderAlert]) {
        [DPHelper showAlertOnTopWithTitle:title message:body];
    }
    if ([DPConfig boolForSwitchKey:kKeywordReminderVibrate]) {
        [DPHelper runOnMain:^{
            @try { AudioServicesPlaySystemSound(kSystemSoundID_Vibrate); } @catch (__unused id e) {}
        }];
    }
    // 修复1：推送到文件助手也走异步主线程，避免重入分发器
    if ([DPConfig boolForSwitchKey:kKeywordReminderPushSelf]) {
        [DPHelper after:0.5 onMain:^{
            id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
            if (!mgr) return;
            Class wrapCls = objc_getClass("CMessageWrap");
            if (!wrapCls) return;
            id m = [[wrapCls alloc] init];
            [m setValue:@"filehelper" forKey:@"m_nsToUsr"];
            [m setValue:[NSString stringWithFormat:@"【关键词提醒】%@\n%@", kw, body] forKey:@"m_nsContent"];
            [m setValue:@1 forKey:@"nMessageType"];
            [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[m]];
        }];
    }
}

static void onAddMsgHandler_KR(id msg, int phase) {
    if (![DPConfig boolForSwitchKey:kSwitchKeywordReminder]) return;
    if (phase != 1) return;
    @try {
        int type = [[msg valueForKey:@"nMessageType"] intValue];
        if (type == 10000) return; // 修复2：跳过系统消息
        NSString *content = [msg valueForKey:@"m_nsContent"];
        if (!content.length) return;
        NSString *from = [msg valueForKey:@"m_nsFromUsr"];
        if (!from.length) return;

        // 修复3：跳过自己
        NSString *selfWxid = nil;
        id cmgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
        if (cmgr) {
            id selfC = [DPHelper performSelectorOnObject:cmgr sel:@selector(getSelfContact) withObjects:@[]];
            selfWxid = [selfC valueForKey:@"m_nsUsrName"];
        }
        if (selfWxid.length && [from isEqualToString:selfWxid]) return;

        NSArray *keywords = nil;
        id kwVal = [DPConfig objectForKey:kKeywordReminderKeywords];
        if ([kwVal isKindOfClass:[NSArray class]]) {
            keywords = kwVal;
        } else if ([kwVal isKindOfClass:[NSString class]] && [kwVal length]) {
            keywords = [[kwVal componentsSeparatedByString:@","] mutableCopy];
            NSMutableArray *trimmed = [NSMutableArray array];
            for (NSString *s in keywords) {
                NSString *t = [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                if (t.length) [trimmed addObject:t];
            }
            keywords = trimmed;
        }
        if (keywords.count == 0) return;

        // 修复4：节流（3s 内不再触发）
        NSDate *now = [NSDate date];
        if (sLastRemindTime && [now timeIntervalSinceDate:sLastRemindTime] < kRemindThrottle) {
            return;
        }
        if (!sRemindedHashes) sRemindedHashes = [NSMutableSet set];

        NSMutableArray *hit = [NSMutableArray array];
        for (NSString *kw in keywords) {
            if (![kw isKindOfClass:[NSString class]] || kw.length == 0) continue;
            if ([content containsString:kw]) {
                NSString *h = hashOf(from, content, kw);
                if ([sRemindedHashes containsObject:h]) continue; // 已提醒过
                [sRemindedHashes addObject:h];
                [hit addObject:kw];
            }
        }
        if (hit.count == 0) return;
        sLastRemindTime = now;

        // 修复1 & 5：异步主线程派发，避免重入与线程问题
        NSArray *hitCopy = [hit copy];
        [DPHelper after:0.2 onMain:^{
            for (NSString *kw in hitCopy) {
                fireReminder(from, content, kw);
            }
        }];
    } @catch (NSException *e) {
        DPLogWarn(@"关键词提醒异常：%@", e);
    }
}

@interface KeywordReminderHook : NSObject @end
@implementation KeywordReminderHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    [[DPMessageDispatcher shared] subscribeForKey:@"KeywordReminder"
                                          handler:^(id msg, int phase) {
        onAddMsgHandler_KR(msg, phase);
    }];
    DPLogInfo(@"KeywordReminder: 已订阅 AddMsg 分发器（已修复重入/误报/重复）");
}
@end
