// AutoAcceptFriendHook.m — 功能8: 自动通过好友
//
// 修复要点：
//   1) import DPPrivateClasses.h 移除重复前向声明。
//   2) onVerifyUser: 只本模块 hook，无多模块冲突，保留独立 hook。
//   3) orig 调用前加非空判断。

#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

static BOOL shouldAcceptByKeyword(NSString *applyText) {
    NSArray *keywords = [DPConfig objectForKey:kAutoAcceptFriendKeywords] ?: @[];
    if (keywords.count == 0) return YES; // 无关键词=全部通过
    for (NSString *kw in keywords) {
        if ([applyText containsString:kw]) return YES;
    }
    return NO;
}

static void autoAccept(CVerifyContactWrap *wrap) {
    if (!wrap || !wrap.m_nsUsrName) return;
    NSString *apply = wrap.verifyMessage ?: @"";
    if (!shouldAcceptByKeyword(apply)) {
        DPLogInfo(@"好友申请不命中关键词，跳过：%@ 申请语=%@", wrap.m_nsUsrName, apply);
        return;
    }
    [DPHelper after:1.5 onMain:^{
        @try {
            Class logicCls = objc_getClass("CContactVerifyLogic");
            if (!logicCls) return;
            id logic = [[logicCls alloc] init];
            [DPHelper performSelectorOnObject:logic sel:@selector(verifyUser:) withObjects:@[wrap]];
            DPLogInfo(@"已自动通过好友：%@", wrap.m_nsUsrName);
            // 通过后自动打招呼
            if ([DPConfig boolForSwitchKey:kAutoAcceptFriendReplyEnable]) {
                NSString *reply = [DPConfig objectForKey:kAutoAcceptFriendReplyText] ?: @"你好";
                [DPHelper after:1.0 onMain:^{
                    // 发送文本消息
                    id mgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
                    if (!mgr) return;
                    Class wrapCls = objc_getClass("CMessageWrap");
                    if (!wrapCls) return;
                    id msg = [[wrapCls alloc] init];
                    [msg setValue:wrap.m_nsUsrName forKey:@"m_nsToUsr"];
                    [msg setValue:reply forKey:@"m_nsContent"];
                    [msg setValue:@1 forKey:@"nMessageType"];
                    [DPHelper performSelectorOnObject:mgr sel:@selector(AddMsg:) withObjects:@[msg]];
                    DPLogInfo(@"已发送打招呼消息给 %@", wrap.m_nsUsrName);
                }];
            }
        } @catch (NSException *e) {
            DPLogWarn(@"自动通过好友异常：%@", e);
        }
    }];
}

// hook CContactMgr onVerifyUser:
static void (*orig_onVerifyUser)(id, SEL, id);
static void hook_onVerifyUser(id self, SEL _cmd, CVerifyContactWrap *wrap) {
    if ([DPConfig boolForSwitchKey:kSwitchAutoAcceptFriend]) {
        autoAccept(wrap);
        return; // 拦截原生流程，由我们接管
    }
    if (orig_onVerifyUser) {
        orig_onVerifyUser(self, _cmd, wrap);
    }
}

@interface AutoAcceptFriendHook : NSObject @end
@implementation AutoAcceptFriendHook
+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    Class cls = objc_getClass("CContactMgr");
    if (cls) {
        Method m = class_getInstanceMethod(cls, @selector(onVerifyUser:));
        if (m) {
            orig_onVerifyUser = (void (*)(id, SEL, id))method_getImplementation(m);
            method_setImplementation(m, (IMP)hook_onVerifyUser);
            DPLogInfo(@"AutoAcceptFriend: hooked CContactMgr onVerifyUser:");
        }
    }
}
@end
