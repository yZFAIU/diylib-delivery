// FriendDetectorHook.m — 功能12: 好友检测
//
// 修复要点：
//   1) 新增 FriendDetectorHook.h 头文件，供 DPPreferencesListController.m import。
//   2) import DPPrivateClasses.h 移除重复前向声明。
//   3) detectByQRMessage 原实现发送消息后立即读 nStatus，此时消息尚未发送完成，
//      nStatus 必为初始值。改为发送后短暂 sleep 再读（仍不完美，但不崩溃）。
//   4) completion block 用 weak 避免循环引用。

#import <objc/runtime.h>
#import "FriendDetectorHook.h"
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"

@implementation FriendDetectorHook

+ (instancetype)shared {
    static FriendDetectorHook *s;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [FriendDetectorHook new]; });
    return s;
}

- (void)detectAllFriends {
    NSInteger method = [DPConfig integerForKey:kFriendDetectorMethod];
    DPLogInfo(@"开始好友检测，方式=%ld", (long)method);
    [DPHelper showAlertOnTopWithTitle:@"好友检测" message:@"检测已开始，请勿操作微信，预计需要几分钟"];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        id contactMgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
        if (!contactMgr) {
            DPLogWarn(@"CContactMgr 未找到");
            return;
        }
        NSArray *contacts = [contactMgr performSelector:@selector(getContactList)];
        NSMutableArray<NSString *> *wxids = [NSMutableArray array];
        for (CContact *c in contacts) {
            NSString *wxid = c.m_nsUsrName;
            if (!wxid) continue;
            // 排除群、公众号、系统账号
            if ([wxid hasSuffix:@"@chatroom"] || [wxid hasPrefix:@"gh_"] ||
                [wxid isEqualToString:@"filehelper"] || [wxid isEqualToString:@"weixin"]) continue;
            [wxids addObject:wxid];
        }
        DPLogInfo(@"待检测好友数：%lu", (unsigned long)wxids.count);
        if (method == 0) {
            [self detectByGroupRoom:wxids];
        } else {
            [self detectByQRMessage:wxids];
        }
    });
}

// 拉群法：每批 30 人建群
- (void)detectByGroupRoom:(NSArray<NSString *> *)wxids {
    NSUInteger batchSize = 30;
    NSMutableArray<NSString *> *deletedFriends = [NSMutableArray array];
    NSUInteger total = wxids.count;
    for (NSUInteger i = 0; i < total; i += batchSize) {
        NSRange range = NSMakeRange(i, MIN(batchSize, total - i));
        NSArray *batch = [wxids subarrayWithRange:range];
        // 同步建群（通过 semaphore 模拟）
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        __block NSArray *failed = nil;
        id logic = [[objc_getClass("CContactVerifyLogic") alloc] init];
        if (logic && [logic respondsToSelector:@selector(createChatRoomWithMembers:completion:)]) {
            // runtime 调用
            NSMethodSignature *sig = [logic methodSignatureForSelector:@selector(createChatRoomWithMembers:completion:)];
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
            [inv setTarget:logic];
            [inv setSelector:@selector(createChatRoomWithMembers:completion:)];
            __weak typeof(self) weakSelf = self;
            // block 必须拷贝到堆上再传给 NSInvocation，否则若被调方法异步持有，
            // 栈 block 销毁后回调会野指针崩溃。
            void (^completion)(NSString *, NSArray *) = [^(NSString *chatroomId, NSArray *failedMembers) {
                failed = failedMembers;
                dispatch_semaphore_signal(sem);
                // 退出群聊
                if (chatroomId) {
                    [weakSelf quitGroup:chatroomId];
                }
            } copy];
            [inv setArgument:&batch atIndex:2];
            [inv setArgument:&completion atIndex:3];
            [inv invoke];
            dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(15 * NSEC_PER_SEC)));
        }
        if (failed) [deletedFriends addObjectsFromArray:failed];
        DPLogInfo(@"批次 %lu/%lu 检测完成，删除好友 %lu", (unsigned long)(i/batchSize+1), (unsigned long)((total+batchSize-1)/batchSize), (unsigned long)failed.count);
        [NSThread sleepForTimeInterval:2.0]; // 防风控
    }
    [self onDetectComplete:deletedFriends];
}

// 二维码法：逐个发消息，发送失败=已删
- (void)detectByQRMessage:(NSArray<NSString *> *)wxids {
    NSMutableArray<NSString *> *deletedFriends = [NSMutableArray array];
    id msgMgr = [objc_getClass("CMessageMgr") performSelector:@selector(sharedInstance)];
    if (!msgMgr) return;
    for (NSString *wxid in wxids) {
        @try {
            // 发送一个空内容消息，通过返回状态判断
            Class wrapCls = objc_getClass("CMessageWrap");
            id wrap = [[wrapCls alloc] init];
            [wrap setValue:wxid forKey:@"m_nsToUsr"];
            [wrap setValue:@"NPC检测" forKey:@"m_nsContent"];
            [wrap setValue:@1 forKey:@"nMessageType"];
            // 调用 AddMsg 触发发送（通过分发器或直接 runtime）
            [DPHelper performSelectorOnObject:msgMgr sel:@selector(AddMsg:) withObjects:@[wrap]];
            // 等待发送状态更新
            [NSThread sleepForTimeInterval:1.5];
            // 检查 nStatus：发送失败标志
            unsigned int status = [[wrap valueForKey:@"nStatus"] unsignedIntValue];
            if (status == 3 || status == 5) { // 失败状态码
                [deletedFriends addObject:wxid];
                DPLogInfo(@"检测到已删好友：%@", wxid);
            }
        } @catch (NSException *e) {
            DPLogWarn(@"二维码法检测 %@ 异常：%@", wxid, e);
        }
        [NSThread sleepForTimeInterval:1.0]; // 防风控
    }
    [self onDetectComplete:deletedFriends];
}

- (void)quitGroup:(NSString *)chatroomId {
    // 调用退群接口（简化）
    id mgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
    if ([mgr respondsToSelector:@selector(quitGroup:)]) {
        [mgr performSelector:@selector(quitGroup:) withObject:chatroomId];
    }
}

- (void)onDetectComplete:(NSArray<NSString *> *)deletedFriends {
    DPLogInfo(@"好友检测完成，已删好友 %lu 人", (unsigned long)deletedFriends.count);
    [DPHelper runOnMain:^{
        NSString *msg = deletedFriends.count > 0
            ? [NSString stringWithFormat:@"检测到 %lu 人已删你：\n%@", (unsigned long)deletedFriends.count, [deletedFriends componentsJoinedByString:@", "]]
            : @"未检测到已删好友";
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"好友检测完成" message:msg preferredStyle:UIAlertControllerStyleAlert];
        if (deletedFriends.count > 0 && [DPConfig boolForSwitchKey:kFriendDetectorAutoDelete]) {
            __weak typeof(self) weakSelf = self;
            [alert addAction:[UIAlertAction actionWithTitle:@"自动删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
                [weakSelf autoDelete:deletedFriends];
            }]];
        }
        [alert addAction:[UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil]];
        [[DPHelper topViewController] presentViewController:alert animated:YES completion:nil];
    }];
}

- (void)autoDelete:(NSArray<NSString *> *)wxids {
    id mgr = [objc_getClass("CContactMgr") performSelector:@selector(sharedInstance)];
    if (!mgr) return;
    for (NSString *wxid in wxids) {
        @try {
            [mgr performSelector:@selector(deleteContact:) withObject:wxid];
            DPLogInfo(@"已删除好友 %@", wxid);
        } @catch (NSException *e) {
            DPLogWarn(@"删除 %@ 异常：%@", wxid, e);
        }
    }
    [DPHelper showAlertOnTopWithTitle:@"删除完成" message:[NSString stringWithFormat:@"已删除 %lu 人", (unsigned long)wxids.count]];
}

+ (void)load {
    if (![DPConfig boolForSwitchKey:kSwitchEnabled]) return;
    // 好友检测不常驻 hook，由设置面板按钮触发
    DPLogInfo(@"FriendDetector 模块就绪（按需触发）");
}

@end
