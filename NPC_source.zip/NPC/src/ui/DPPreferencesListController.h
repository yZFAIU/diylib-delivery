// DPPreferencesListController.h
//
// 修复要点：
//   原头文件 #import <Preferences/PSListController.h> 并继承 PSListController，
//   但 .m 是纯 UIKit 实现，且 Makefile 未链接 Preferences.framework。
//   改为继承 UITableViewController，与实现一致，移除 Preferences 依赖。

#import <UIKit/UIKit.h>

@interface DPPreferencesListController : UITableViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

- (instancetype)initWithStyle:(UITableViewStyle)style;

@end
