// DPPreferencesListController.m — NPC 设置面板
//
// 修复要点：
//   1) 原头文件继承 PSListController 但实现是纯 UIKit。改为继承 UITableViewController。
//   2) 原实现 #import "FriendDetectorHook.h" 但该 .m 无 .h。
//      现已创建 FriendDetectorHook.h，import 正常。
//   3) onSwitchChanged: 用 [[sw superview] superview] 找 cell，iOS 11+ 需 3 层
//      (UISwitch→UITableViewCellContentView→UITableViewCell)，只取 2 层得 nil。
//      改为用 tag 直接计算 section/row，不依赖 view 层级。
//   4) initWithStyle: 与 UITableViewController 原生初始化方法签名一致。

#import "DPPreferencesListController.h"
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "FriendDetectorHook.h"

@interface DPPreferencesListController ()
@property (nonatomic, strong) NSArray *sections;
@end

@implementation DPPreferencesListController

typedef NS_ENUM(NSInteger, DPSection) {
    DPSectionMaster = 0,
    DPSectionModules,    // 12 个功能总开关
    DPSectionLocation,   // 定位子项
    DPSectionCloseFriend,
    DPSectionAutoFollow,
    DPSectionChatEncrypt,
    DPSectionDisable,
    DPSectionKeepAlive,
    DPSectionAntiRevoke,
    DPSectionAutoAccept,
    DPSectionQuitMonitor,
    DPSectionAutoTransfer,
    DPSectionRedEnvelope,
    DPSectionFriendDetector,
    DPSectionMarkAllRead,   // 13
    DPSectionLongPress,     // 14
    DPSectionKeywordReply,  // 15
    DPSectionKeywordReminder,// 16
    DPSectionQuickQuote,    // 17
    DPSectionAutoConfirmLogin,// 18
    DPSectionCameraRecognize,// 19
    DPSectionAbout,
};

- (instancetype)initWithStyle:(UITableViewStyle)style {
    self = [super initWithStyle:style];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"NPC";
    // UITableViewController 已自动创建 tableView 并设为 self.view，
    // 这里只需配置 dataSource/delegate，不再重建（避免 view 层级混乱）
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self buildSections];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)buildSections {
    // 每个 section 是字典 {title, items:[{type, key, title, ...}]}
    self.sections = @[
        @{ @"title": @"总开关", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchEnabled, @"title": @"启用 NPC", @"subtitle": @"关闭后仅保留设置入口" },
        ]},
        @{ @"title": @"功能模块（12 项）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchLocationSpoof,       @"title": @"1. 修改微信定位" },
            @{ @"type": @"switch", @"key": kSwitchCloseFriend,         @"title": @"2. 密友功能" },
            @{ @"type": @"switch", @"key": kSwitchAutoFollow,          @"title": @"3. 自动跟圈" },
            @{ @"type": @"switch", @"key": kSwitchChatEncrypt,         @"title": @"4. 聊天加密" },
            @{ @"type": @"switch", @"key": kSwitchDisableFunction,     @"title": @"5. 禁用功能（黄白）" },
            @{ @"type": @"switch", @"key": kSwitchBackgroundKeepAlive, @"title": @"6. 后台保活（pkc）" },
            @{ @"type": @"switch", @"key": kSwitchAntiRevoke,          @"title": @"7. 防撤回" },
            @{ @"type": @"switch", @"key": kSwitchAutoAcceptFriend,    @"title": @"8. 自动通过好友" },
            @{ @"type": @"switch", @"key": kSwitchQuitGroupMonitor,    @"title": @"9. 退群监控" },
            @{ @"type": @"switch", @"key": kSwitchAutoAcceptTransfer,  @"title": @"10. 自动接收转账" },
            @{ @"type": @"switch", @"key": kSwitchAutoRedEnvelope,     @"title": @"11. 抢红包" },
            @{ @"type": @"switch", @"key": kSwitchFriendDetector,      @"title": @"12. 好友检测" },
        ]},
        @{ @"title": @"1. 定位配置", @"items": @[
            @{ @"type": @"input", @"key": kLocationLatitude,  @"title": @"纬度", @"placeholder": @"39.9087" },
            @{ @"type": @"input", @"key": kLocationLongitude, @"title": @"经度", @"placeholder": @"116.3975" },
            @{ @"type": @"input", @"key": kLocationAddress,   @"title": @"地址描述", @"placeholder": @"天安门广场" },
            @{ @"type": @"switch", @"key": kLocationForTimeline, @"title": @"朋友圈也生效" },
        ]},
        @{ @"title": @"2. 密友配置", @"items": @[
            @{ @"type": @"switch", @"key": kCloseFriendRingEnable,   @"title": @"密友专属铃声" },
            @{ @"type": @"switch", @"key": kCloseFriendTopEnable,    @"title": @"密友置顶" },
            @{ @"type": @"switch", @"key": kCloseFriendRedDotEnable, @"title": @"密友红点提醒" },
        ]},
        @{ @"title": @"3. 自动跟圈配置", @"items": @[
            @{ @"type": @"switch", @"key": kAutoFollowLikeEnable,    @"title": @"自动点赞" },
            @{ @"type": @"switch", @"key": kAutoFollowCommentEnable, @"title": @"自动评论" },
            @{ @"type": @"input", @"key": kAutoFollowKeywords, @"title": @"关键词（逗号分隔）", @"placeholder": @"生日,快乐" },
            @{ @"type": @"input", @"key": kAutoFollowComments, @"title": @"评论话术（逗号分隔）", @"placeholder": @"好棒,点赞,精彩" },
            @{ @"type": @"input", @"key": kAutoFollowIntervalSec, @"title": @"间隔秒数", @"placeholder": @"5" },
            @{ @"type": @"input", @"key": kAutoFollowMaxNumPerDay, @"title": @"每日上限", @"placeholder": @"50" },
        ]},
        @{ @"title": @"4. 聊天加密配置", @"items": @[
            @{ @"type": @"input", @"key": kChatEncryptAESKey,      @"title": @"AES 密钥", @"placeholder": @"自定义密钥" },
            @{ @"type": @"input", @"key": kChatEncryptGroupList,   @"title": @"加密群白名单（逗号分隔，空=全部）", @"placeholder": @"xxx@chatroom" },
            @{ @"type": @"input", @"key": kChatEncryptDisplayMode, @"title": @"显示模式（0密文/1掩码/2自定义）", @"placeholder": @"0" },
            @{ @"type": @"switch", @"key": kChatEncryptImageEnable, @"title": @"图片加密" },
        ]},
        @{ @"title": @"5. 禁用功能（黄白 44 项）", @"items": @[
            @{ @"type": @"switch", @"key": kDisableMainFrameSearchBar, @"title": @"禁用首页搜索栏" },
            @{ @"type": @"switch", @"key": kDisableUnReadCount,        @"title": @"禁用未读数" },
            @{ @"type": @"switch", @"key": kDisableEmoticonStore,      @"title": @"禁用表情商店" },
            @{ @"type": @"switch", @"key": kDisableEmoticonSearch,     @"title": @"禁用表情搜索" },
            @{ @"type": @"switch", @"key": kDisableCameraEmoticon,     @"title": @"禁用自拍表情" },
            @{ @"type": @"switch", @"key": kDisableDownApplet,         @"title": @"禁用小程序" },
            @{ @"type": @"switch", @"key": kDisableWCPayTitle,         @"title": @"禁用微信支付入口" },
            @{ @"type": @"switch", @"key": kDisableWCFinder,           @"title": @"禁用视频号" },
            @{ @"type": @"switch", @"key": kDisableSettingAboutMM,     @"title": @"禁用关于微信" },
            @{ @"type": @"switch", @"key": kDisableSettingLabs,        @"title": @"禁用微信实验室" },
            @{ @"type": @"switch", @"key": kDisableElderMode,          @"title": @"禁用长辈模式" },
            @{ @"type": @"switch", @"key": kDisableAutoGetUpdate,      @"title": @"禁用自动更新" },
            @{ @"type": @"switch", @"key": kDisablePatViewTips,        @"title": @"禁用拍一拍提示" },
            @{ @"type": @"switch", @"key": kDisableCopyMsgTip,         @"title": @"禁用复制提示" },
            @{ @"type": @"switch", @"key": kDisableInputTips,          @"title": @"禁用输入提示" },
            @{ @"type": @"switch", @"key": kDisableBatchRevokeMsg,     @"title": @"禁用批量撤回" },
            @{ @"type": @"switch", @"key": kDisableAVCapture,          @"title": @"禁用扫一扫相机" },
        ]},
        @{ @"title": @"6. 后台保活配置（pkc）", @"items": @[
            @{ @"type": @"switch", @"key": kKeepAliveAudioEnable,  @"title": @"静音音频保活" },
            @{ @"type": @"switch", @"key": kKeepAliveBgTaskEnable, @"title": @"后台任务保活" },
            @{ @"type": @"switch", @"key": kKeepAliveNotifyOnKill, @"title": @"被杀后本地通知" },
        ]},
        @{ @"title": @"7. 防撤回配置", @"items": @[
            @{ @"type": @"switch", @"key": kAntiRevokeShowOrigin,   @"title": @"显示撤回原文" },
            @{ @"type": @"switch", @"key": kAntiRevokeNotifyEnable, @"title": @"撤回时弹窗" },
            @{ @"type": @"switch", @"key": kAntiRevokeReplyEnable,  @"title": @"撤回自动回复" },
            @{ @"type": @"input", @"key": kAntiRevokeReplyContent,  @"title": @"回复内容", @"placeholder": @"对方撤回了一条消息" },
        ]},
        @{ @"title": @"8. 自动通过好友配置", @"items": @[
            @{ @"type": @"input", @"key": kAutoAcceptFriendKeywords, @"title": @"申请语关键词（逗号分隔，空=全部）", @"placeholder": @"朋友介绍" },
            @{ @"type": @"switch", @"key": kAutoAcceptFriendReplyEnable, @"title": @"通过后自动打招呼" },
            @{ @"type": @"input", @"key": kAutoAcceptFriendReplyText,   @"title": @"打招呼内容", @"placeholder": @"你好" },
        ]},
        @{ @"title": @"9. 退群监控配置", @"items": @[
            @{ @"type": @"switch", @"key": kQuitGroupMonitorAlert,        @"title": @"弹窗提醒" },
            @{ @"type": @"switch", @"key": kQuitGroupMonitorPushSelf,     @"title": @"推送到文件助手" },
            @{ @"type": @"switch", @"key": kQuitGroupMonitorReplyEnable,  @"title": @"自动回复到群" },
            @{ @"type": @"input", @"key": kQuitGroupMonitorReplyContent,  @"title": @"回复内容", @"placeholder": @"已退出群聊" },
        ]},
        @{ @"title": @"10. 自动接收转账配置", @"items": @[
            @{ @"type": @"input", @"key": kAutoTransferDelaySec,     @"title": @"延迟秒数（防风控）", @"placeholder": @"2.0" },
            @{ @"type": @"switch", @"key": kAutoTransferReplyEnable, @"title": @"收款后自动回复" },
            @{ @"type": @"input", @"key": kAutoTransferReplyContent, @"title": @"回复内容", @"placeholder": @"已收款，谢谢" },
        ]},
        @{ @"title": @"11. 抢红包配置", @"items": @[
            @{ @"type": @"input", @"key": kRedEnvelopeDelaySec,      @"title": @"延迟秒数", @"placeholder": @"1.5" },
            @{ @"type": @"input", @"key": kRedEnvelopeGroupFilter,   @"title": @"群白名单（逗号分隔，空=全部）", @"placeholder": @"xxx@chatroom" },
            @{ @"type": @"input", @"key": kRedEnvelopeKeywordFilter, @"title": @"关键词过滤（逗号分隔）", @"placeholder": @"恭喜" },
            @{ @"type": @"switch", @"key": kRedEnvelopeSkipSelf,     @"title": @"不抢自己发的" },
            @{ @"type": @"switch", @"key": kRedEnvelopeSkipPrivate,  @"title": @"不抢私聊" },
            @{ @"type": @"switch", @"key": kRedEnvelopeReplyEnable,  @"title": @"抢到后感谢" },
            @{ @"type": @"input", @"key": kRedEnvelopeReplyText,     @"title": @"感谢话术", @"placeholder": @"谢谢老板" },
        ]},
        @{ @"title": @"12. 好友检测", @"items": @[
            @{ @"type": @"input", @"key": kFriendDetectorMethod,     @"title": @"检测方式（0拉群法/1二维码法）", @"placeholder": @"0" },
            @{ @"type": @"switch", @"key": kFriendDetectorAutoDelete, @"title": @"检测后自动删除" },
            @{ @"type": @"button", @"key": @"detect", @"title": @"立即检测", @"action": @"startDetect" },
        ]},
        @{ @"title": @"13. 一键标记已读（参考 MiYou mIsAllGroupUndeno）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchMarkAllRead, @"title": @"启用一键标记已读" },
            @{ @"type": @"text", @"title": @"说明", @"value": @"首页右上角出现\"全部已读\"按钮" },
        ]},
        @{ @"title": @"14. 长按信息+1（群内快速捧场）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchLongPressPlusOne, @"title": @"启用长按+1" },
            @{ @"type": @"text", @"title": @"说明", @"value": @"长按消息菜单出现\"＋1\"，发送\"1\"" },
        ]},
        @{ @"title": @"15. 关键词自动回复（参考 MiYou MYReplyConfig）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchKeywordAutoReply, @"title": @"启用关键词自动回复" },
            @{ @"type": @"input", @"key": kKeywordAutoReplyPairs, @"title": @"规则(逗号分隔)", @"placeholder": @"你好=在的,kw2=回复2" },
            @{ @"type": @"switch", @"key": kKeywordAutoReplyOnlyGroup, @"title": @"仅群聊生效" },
            @{ @"type": @"switch", @"key": kKeywordAutoReplySkipSelf, @"title": @"跳过自己发的消息" },
            @{ @"type": @"input", @"key": kKeywordAutoReplyDelay, @"title": @"延迟秒数（防风控）", @"placeholder": @"1.0" },
        ]},
        @{ @"title": @"16. 关键词提醒（参考 MiYou 关键词提醒，已修复）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchKeywordReminder, @"title": @"启用关键词提醒" },
            @{ @"type": @"input", @"key": kKeywordReminderKeywords, @"title": @"关键词(逗号分隔)", @"placeholder": @"发货,退款" },
            @{ @"type": @"switch", @"key": kKeywordReminderAlert, @"title": @"弹窗提醒" },
            @{ @"type": @"switch", @"key": kKeywordReminderPushSelf, @"title": @"推送到文件助手" },
            @{ @"type": @"switch", @"key": kKeywordReminderVibrate, @"title": @"震动提醒" },
        ]},
        @{ @"title": @"17. 消息快速引用（参考 MiYou mIsQuoteAtUser）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchQuickQuote, @"title": @"启用快速引用" },
            @{ @"type": @"text", @"title": @"说明", @"value": @"长按消息菜单出现\"引用\"" },
        ]},
        @{ @"title": @"18. 自动确认登陆（参考 MiYou mIsAutoConfirmLogin）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchAutoConfirmLogin, @"title": @"启用自动确认登陆" },
            @{ @"type": @"input", @"key": kAutoConfirmLoginDelay, @"title": @"延迟秒数", @"placeholder": @"1.0" },
        ]},
        @{ @"title": @"19. 启用相机识别（参考 MiYou mIsSanCodeInCamera）", @"items": @[
            @{ @"type": @"switch", @"key": kSwitchCameraRecognize, @"title": @"启用相机识别" },
            @{ @"type": @"text", @"title": @"说明", @"value": @"相机页启用二维码/条码识别" },
        ]},
        @{ @"title": @"关于", @"items": @[
            @{ @"type": @"text", @"title": @"插件名称", @"value": @"NPC" },
            @{ @"type": @"text", @"title": @"版本", @"value": @"26.0.1" },
            @{ @"type": @"text", @"title": @"作者", @"value": @"yZFAIU" },
            @{ @"type": @"text", @"title": @"免责声明", @"value": @"仅供安全研究与逆向学习" },
        ]},
    ];
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSDictionary *sec = self.sections[section];
    return [sec[@"items"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.sections[section][@"title"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *sec = self.sections[indexPath.section];
    NSDictionary *item = sec[@"items"][indexPath.row];
    NSString *type = item[@"type"];
    NSString *reuseId = [NSString stringWithFormat:@"%@_%ld_%ld", type, (long)indexPath.section, (long)indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseId];
    if (!cell) {
        if ([type isEqualToString:@"switch"]) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseId];
            UISwitch *sw = [UISwitch new];
            // tag 编码：section * 10000 + row（section 数量远小于 10000，避免溢出）
            sw.tag = (NSInteger)indexPath.section * 10000 + (NSInteger)indexPath.row;
            [sw addTarget:self action:@selector(onSwitchChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = sw;
            cell.textLabel.text = item[@"title"];
        } else if ([type isEqualToString:@"input"]) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseId];
            cell.textLabel.text = item[@"title"];
            UITextField *tf = [UITextField new];
            tf.tag = (NSInteger)indexPath.section * 10000 + (NSInteger)indexPath.row;
            tf.placeholder = item[@"placeholder"];
            tf.textAlignment = NSTextAlignmentRight;
            tf.frame = CGRectMake(0, 0, 180, 30);
            tf.font = [UIFont systemFontOfSize:14];
            tf.delegate = self;
            [tf addTarget:self action:@selector(onInputChanged:) forControlEvents:UIControlEventEditingDidEnd];
            cell.accessoryView = tf;
        } else if ([type isEqualToString:@"button"]) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseId];
            cell.textLabel.text = item[@"title"];
            cell.textLabel.textColor = [UIColor systemBlueColor];
            cell.textLabel.textAlignment = NSTextAlignmentCenter;
            cell.accessoryType = UITableViewCellAccessoryNone;
        } else if ([type isEqualToString:@"text"]) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseId];
            cell.textLabel.text = item[@"title"];
            cell.detailTextLabel.text = item[@"value"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }
    // 回填值
    if ([type isEqualToString:@"switch"]) {
        UISwitch *sw = (UISwitch *)cell.accessoryView;
        sw.on = [DPConfig boolForSwitchKey:item[@"key"]];
    } else if ([type isEqualToString:@"input"]) {
        UITextField *tf = (UITextField *)cell.accessoryView;
        id val = [DPConfig objectForKey:item[@"key"]];
        tf.text = val ? [NSString stringWithFormat:@"%@", val] : @"";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *sec = self.sections[indexPath.section];
    NSDictionary *item = sec[@"items"][indexPath.row];
    if ([item[@"type"] isEqualToString:@"button"]) {
        NSString *action = item[@"action"];
        if ([action isEqualToString:@"startDetect"]) {
            [[FriendDetectorHook shared] performSelector:NSSelectorFromString(@"detectAllFriends")];
        }
    }
}

// 修复：用 tag 直接计算 section/row，不依赖 view 层级（iOS 11+ superview 层级变化）
- (NSIndexPath *)indexPathFromTag:(NSInteger)tag {
    NSInteger section = tag / 10000;
    NSInteger row = tag % 10000;
    if (section < 0 || section >= (NSInteger)self.sections.count) return nil;
    NSDictionary *sec = self.sections[section];
    if (row < 0 || row >= (NSInteger)[sec[@"items"] count]) return nil;
    return [NSIndexPath indexPathForRow:row inSection:section];
}

- (void)onSwitchChanged:(UISwitch *)sw {
    NSIndexPath *ip = [self indexPathFromTag:sw.tag];
    if (!ip) return;
    NSDictionary *item = self.sections[ip.section][@"items"][ip.row];
    NSString *key = item[@"key"];
    [DPConfig setBool:sw.on forSwitchKey:key];
    DPLogInfo(@"开关 %@ = %@", key, sw.on ? @"ON" : @"OFF");
}

- (void)onInputChanged:(UITextField *)tf {
    NSIndexPath *ip = [self indexPathFromTag:tf.tag];
    if (!ip) return;
    NSDictionary *item = self.sections[ip.section][@"items"][ip.row];
    NSString *key = item[@"key"];
    NSString *text = tf.text ?: @"";
    // 简单类型推断：数字 key 走 setInteger/setDouble，其他走 setObject
    static NSSet *intKeys;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        intKeys = [NSSet setWithArray:@[
            kAutoFollowIntervalSec, kAutoFollowMaxNumPerDay,
            kChatEncryptDisplayMode, kFriendDetectorMethod
        ]];
    });
    static NSSet *doubleKeys;
    static dispatch_once_t once2;
    dispatch_once(&once2, ^{
        doubleKeys = [NSSet setWithArray:@[
            kRedEnvelopeDelaySec, kAutoTransferDelaySec,
            kKeywordAutoReplyDelay, kAutoConfirmLoginDelay
        ]];
    });
    if ([intKeys containsObject:key]) {
        [DPConfig setInteger:[text integerValue] forKey:key];
    } else if ([doubleKeys containsObject:key]) {
        [DPConfig setDouble:[text doubleValue] forKey:key];
    } else {
        // 多值字段（逗号分隔）转数组存储
        NSArray *multiKeys = @[kAutoFollowKeywords, kAutoFollowComments,
                               kChatEncryptGroupList, kAutoAcceptFriendKeywords,
                               kRedEnvelopeGroupFilter, kRedEnvelopeKeywordFilter];
        if ([multiKeys containsObject:key]) {
            NSArray *arr = [text componentsSeparatedByString:@","];
            NSMutableArray *trimmed = [NSMutableArray array];
            for (NSString *s in arr) {
                NSString *t = [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                if (t.length) [trimmed addObject:t];
            }
            [DPConfig setObject:trimmed forKey:key];
        } else {
            [DPConfig setObject:text forKey:key];
        }
    }
    DPLogInfo(@"配置 %@ = %@", key, text);
}

@end
