// DPMessageDispatcher.m — AddMsg 集中分发实现
//
// 关键点：
//   1) 只调用一次 method_setImplementation，保存唯一 orig 指针
//   2) install 幂等，多次调用安全
//   3) hook 函数内：先按订阅顺序调用 phase=0（orig 前），再调用 orig，
//      再按订阅顺序调用 phase=1（orig 后）。所有回调包 @try 防止单个模块异常影响整体。
//   4) 确保 orig 非空才调用，避免空指针跳转闪退。

#import "DPMessageDispatcher.h"
#import "DPPrivateClasses.h"
#import "DPConfig.h"
#import "DPLog.h"
#import <objc/runtime.h>

@interface DPMessageDispatcher ()
- (void)dispatchMessage:(id)msg phase:(int)phase;
@end

// 唯一的原生实现指针
static void (*orig_AddMsg_dispatch)(id, SEL, id) = NULL;
static BOOL sInstalled = NO;

// 分发器 hook 函数
static void hook_AddMsg_dispatch(id self, SEL _cmd, id msg) {
    DPMessageDispatcher *disp = [DPMessageDispatcher shared];

    // phase=0: orig 调用前（允许模块修改消息内容，如解密）
    [disp dispatchMessage:msg phase:0];

    // 调用原生实现
    if (orig_AddMsg_dispatch) {
        orig_AddMsg_dispatch(self, _cmd, msg);
    }

    // phase=1: orig 调用后（用于派生动作，如抢红包、退群监控、密友提醒）
    [disp dispatchMessage:msg phase:1];
}

@implementation DPMessageDispatcher {
    NSMutableDictionary<NSString *, DPAddMsgHandler> *_handlers;
}

+ (instancetype)shared {
    static DPMessageDispatcher *s;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [DPMessageDispatcher new]; });
    return s;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _handlers = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)install {
    if (sInstalled) return;
    Class cls = objc_getClass("CMessageMgr");
    if (!cls) {
        DPLogWarn(@"DPMessageDispatcher: CMessageMgr 类未找到，无法 hook");
        return;
    }
    Method m = class_getInstanceMethod(cls, @selector(AddMsg:));
    if (!m) {
        DPLogWarn(@"DPMessageDispatcher: CMessageMgr AddMsg: 方法未找到");
        return;
    }
    orig_AddMsg_dispatch = (void (*)(id, SEL, id))method_getImplementation(m);
    method_setImplementation(m, (IMP)hook_AddMsg_dispatch);
    sInstalled = YES;
    DPLogInfo(@"DPMessageDispatcher: 已 hook CMessageMgr AddMsg: (单点)");
}

- (void)subscribeForKey:(NSString *)key handler:(DPAddMsgHandler)handler {
    if (!key || !handler) return;
    @synchronized(self) {
        _handlers[key] = handler;
    }
}

- (void)unsubscribeForKey:(NSString *)key {
    if (!key) return;
    @synchronized(self) {
        [_handlers removeObjectForKey:key];
    }
}

- (void)dispatchMessage:(id)msg phase:(int)phase {
    // 先在锁内拷贝一份 handlers 快照，然后在锁外调用。
    // 避免 handler 内部若触发 AddMsg 重入导致 dispatch_sync 死锁
    // （串行队列上 dispatch_sync 重入会死锁）。
    NSArray<DPAddMsgHandler> *handlers = nil;
    NSArray<NSString *> *keys = nil;
    @synchronized(self) {
        handlers = [_handlers allValues];
        keys = [_handlers allKeys];
    }
    if (handlers.count == 0) return;
    for (NSUInteger i = 0; i < handlers.count; i++) {
        @try {
            handlers[i](msg, phase);
        } @catch (NSException *e) {
            DPLogWarn(@"AddMsg 分发异常 key=%@ phase=%d：%@", keys[i], phase, e);
        }
    }
}

@end
