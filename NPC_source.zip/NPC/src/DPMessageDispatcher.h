// DPMessageDispatcher.h — CMessageMgr AddMsg: 集中式单点 hook 分发器
//
// 解决的问题：
//   原实现中 CloseFriendHook / ChatEncryptHook / QuitGroupMonitorHook /
//   AutoRedEnvelopeHook 四个模块各自用独立 orig 指针 hook 同一方法，
//   后加载覆盖前加载，orig 指针错乱，可能无限递归导致栈溢出闪退。
//
// 新方案：
//   仅由本分发器 hook 一次 CMessageMgr AddMsg:，保存唯一的 orig 指针。
//   各模块通过 +subscribeOnAddMsg: 注册回调，分发器在 orig 调用前后
//   依次通知所有订阅者。彻底消除多 orig 指针冲突。

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// AddMsg 回调签名
/// @param msg 收到的 CMessageWrap 对象
/// @param phase 0 = orig 调用前（可改写内容）, 1 = orig 调用后（用于派生动作）
typedef void (^DPAddMsgHandler)(id msg, int phase);

@interface DPMessageDispatcher : NSObject

/// 获取单例
+ (instancetype)shared;

/// 安装 hook（只 hook 一次，幂等）。在总开关开启时由 Tweak.xm 入口调用。
- (void)install;

/// 订阅 AddMsg 事件。block 在主线程同步执行。
/// @param key 订阅者标识（用于去重/移除）
/// @param handler 回调，phase=0 在 orig 前，phase=1 在 orig 后
- (void)subscribeForKey:(NSString *)key handler:(DPAddMsgHandler)handler;

/// 取消订阅
- (void)unsubscribeForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
