// DPLog.h — 日志
#import <Foundation/Foundation.h>

#ifdef DEBUG
#define DPLogInfo(fmt, ...)  NSLog(@"[NPC] " fmt, ##__VA_ARGS__)
#define DPLogWarn(fmt, ...)  NSLog(@"[NPC⚠] " fmt, ##__VA_ARGS__)
#define DPLogErr(fmt, ...)   NSLog(@"[NPC✗] " fmt, ##__VA_ARGS__)
#else
#define DPLogInfo(fmt, ...)  ((void)0)
#define DPLogWarn(fmt, ...)  NSLog(@"[NPC⚠] " fmt, ##__VA_ARGS__)
#define DPLogErr(fmt, ...)   NSLog(@"[NPC✗] " fmt, ##__VA_ARGS__)
#endif
