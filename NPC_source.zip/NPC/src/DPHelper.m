// DPHelper.m
#import "DPHelper.h"
#import <objc/runtime.h>

@implementation DPHelper

+ (NSString *)weChatVersion {
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"] ?: @"";
}

+ (BOOL)isGroupChat:(NSString *)chatName {
    return [chatName hasSuffix:@"@chatroom"];
}

+ (UIViewController *)topViewController {
    UIViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    if ([vc isKindOfClass:[UINavigationController class]]) {
        UINavigationController *nav = (UINavigationController *)vc;
        return nav.visibleViewController ?: nav.topViewController;
    }
    return vc;
}

+ (void)runOnMain:(dispatch_block_t)block {
    if ([NSThread isMainThread]) block();
    else dispatch_async(dispatch_get_main_queue(), block);
}

+ (void)after:(NSTimeInterval)sec onMain:(dispatch_block_t)block {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)), dispatch_get_main_queue(), block);
}

+ (void)showAlertOnTopWithTitle:(NSString *)title message:(NSString *)message {
    [self runOnMain:^{
        UIViewController *top = [self topViewController];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil]];
        [top presentViewController:alert animated:YES completion:nil];
    }];
}

+ (id)performSelectorOnObject:(id)obj sel:(SEL)sel withObjects:(NSArray *)objs {
    if (!obj || !sel) return nil;
    NSMethodSignature *sig = [obj methodSignatureForSelector:sel];
    if (!sig) return nil;
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    [inv setTarget:obj];
    [inv setSelector:sel];
    for (NSUInteger i = 0; i < objs.count; i++) {
        id arg = objs[i];
        [inv setArgument:&arg atIndex:i + 2];
    }
    [inv invoke];
    if (sig.methodReturnLength > 0) {
        // ARC 下 getReturnValue: 取出的对象引用不经过 ARC 管理，
        // 需用 __unsafe_unretained 接收，再手动转 strong 返回。
        __unsafe_unretained id ret = nil;
        [inv getReturnValue:&ret];
        return ret;
    }
    return nil;
}

+ (NSString *)fileHelperWxid {
    return @"filehelper";
}

@end
