// DPHelper.h — 通用助手
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DPHelper : NSObject

/// 获取当前微信版本号
+ (NSString *)weChatVersion;
/// 当前是否群聊（chatName 以 @chatroom 结尾）
+ (BOOL)isGroupChat:(NSString *)chatName;
/// 安全获取顶层 VC
+ (UIViewController *)topViewController;
/// 在主线程异步执行
+ (void)runOnMain:(dispatch_block_t)block;
/// 延迟执行
+ (void)after:(NSTimeInterval)sec onMain:(dispatch_block_t)block;
/// 弹窗提示
+ (void)showAlertOnTopWithTitle:(NSString *)title message:(NSString *)message;
/// 通过 runtime 调用某对象的某方法（避免硬依赖私有类）
+ (id)performSelectorOnObject:(id)obj sel:(SEL)sel withObjects:(NSArray *)objs;
/// 文件传输助手 wxid
+ (NSString *)fileHelperWxid;

@end
