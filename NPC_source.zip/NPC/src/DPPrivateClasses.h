// DPPrivateClasses.h — 微信私有类集中前向声明
//
// 作用：避免多个模块各自 @interface 前向声明同一类，导致同一可执行文件内
//       符号冲突或属性声明不一致。所有模块统一 import 本头文件。
//
// 注意：这些是 runtime 调用所需的私有类前向声明，编译期不产生符号依赖，
//       运行时由微信主进程加载。仅声明我们用到的属性/方法。

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark - 消息相关

@interface CMessageWrap : NSObject
@property (nonatomic, copy) NSString *m_nsFromUsr;
@property (nonatomic, copy) NSString *m_nsToUsr;
@property (nonatomic, copy) NSString *m_nsContent;
@property (nonatomic, copy) NSString *m_nsMsgSource;
@property (nonatomic, assign) int nMessageType;
@property (nonatomic, assign) int nMessageRevokFlag;
@property (nonatomic, assign) unsigned int nStatus;
@end

@interface CMessageMgr : NSObject
+ (instancetype)sharedInstance;
- (void)AddMsg:(id)msg;
- (void)onRevokeMsg:(id)msg;
@end

@interface MessageService : NSObject
- (void)SendMsg:(id)msg;
@end

#pragma mark - 联系人相关

@interface CContact : NSObject
@property (nonatomic, copy) NSString *m_nsUsrName;
@property (nonatomic, copy) NSString *m_nsNickName;
@end

@interface CContactMgr : NSObject
+ (instancetype)sharedInstance;
- (id)getSelfContact;
- (NSArray *)getContactList;
- (id)getContact:(NSString *)wxid;
- (void)deleteContact:(NSString *)wxid;
- (void)onVerifyUser:(id)wrap;
- (void)quitGroup:(NSString *)chatroomId;
@end

@interface CVerifyContactWrap : NSObject
@property (nonatomic, copy) NSString *m_nsUsrName;
@property (nonatomic, copy) NSString *m_nsAntispamTicket;
@property (nonatomic, copy) NSString *verifyMessage;
@end

@interface CContactVerifyLogic : NSObject
- (void)verifyUser:(id)wrap;
- (void)createChatRoomWithMembers:(NSArray *)members completion:(void(^)(NSString *chatroomId, NSArray *failedMembers))completion;
@end

#pragma mark - 朋友圈相关

@interface WCDataItem : NSObject
@property (nonatomic, copy) NSString *m_nsUserName;
@property (nonatomic, copy) NSString *m_nsContent;
@property (nonatomic, copy) NSString *m_nsTid;
@property (nonatomic, assign) BOOL likeFlag;
@end

@interface WCTimeLineDataProvider : NSObject
- (NSArray *)allItems;
@end

@interface WCFacade : NSObject
+ (instancetype)sharedInstance;
- (void)likeAction:(WCDataItem *)item;
- (void)commentAction:(WCDataItem *)item text:(NSString *)text;
@end

@interface WCTimeLineViewController : UIViewController
- (void)onDataUpdated;
@end

#pragma mark - 红包/转账相关

@interface WCRedEnvelopesControlLogic : NSObject
- (void)OpenRedEnvelopesRequest;
@end

@interface HongBaoMgr : NSObject
+ (instancetype)sharedInstance;
- (void)openRedEnvelope:(id)msg;
@end

@interface WCPayTransferMoneyControlLogic : NSObject
- (void)acceptTransfer;
- (void)acceptTransferWithPayId:(NSString *)payId;
@end

@interface WCPayInfoItem : NSObject
@property (nonatomic, copy) NSString *m_nsPayId;
@end

#pragma mark - 定位相关

@interface MMLocationData : NSObject
@property (nonatomic, copy) NSString *longitude;
@property (nonatomic, copy) NSString *latitude;
@property (nonatomic, copy) NSString *address;
@property (nonatomic, copy) NSString *tagName;
- (id)initWithCoordinate:(CLLocationCoordinate2D)coord address:(id)addr;
@end

@interface SendMessageLocationController : UIViewController
@property (nonatomic, strong) MMLocationData *selectedLocation;
- (void)sureSelectLocation;
@end

@interface WCSelectLocationViewController : UIViewController
- (void)onSureSelectLocation;
@end

#pragma mark - 微信 UI 控制器

@interface NewMainFrameViewController : UIViewController
@end

@interface SettingViewController : UIViewController
@end

@interface NewSettingViewController : UIViewController
@end

@interface MoreViewController : UIViewController
@end

// 现代微信“我”页（NewSettingViewController）把表格数据交给 MMTableViewInfo /
// WCTableViewManager 作为 dataSource，ViewController 本身并不是 dataSource。
// 因此注入“我”页入口必须同时 hook 这两个数据源类，并按 tableView.delegate
// 判断当前表格是否属于“我”页（见 Tweak.xm 的 npc_isMePageTableView）。
@interface MMTableViewInfo : NSObject
@end

@interface WCTableViewManager : NSObject
@end

@interface EmoticonStorePanelViewController : UIViewController
- (void)viewWillAppear:(BOOL)animated;
@end

@interface WCMessageNodeView : NSObject
- (void)onTransferButtonClicked:(id)sender;
@end

#pragma mark - 聊天内容页（长按+1 / 快速引用）

@interface BaseMsgContentViewController : UIViewController
@property (nonatomic, strong) id m_inputBarView;   // 输入栏（含引用消息）
@property (nonatomic, strong) id m_textView;       // 输入框
- (void)forwardLongPressMenu:(id)arg;              // 多版本长按菜单入口（可能不存在）
@end

NS_ASSUME_NONNULL_END
