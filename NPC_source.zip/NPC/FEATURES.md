# NPC 插件功能对照表

> 版本 26.0.1 / 作者 yZFAIU
> 参考来源：HBWechatHelper（黄白）、PKCWeChatTools（pkc/curtinlv）、ZDY_v1.3.0

## 12 个功能模块对照

| # | 功能 | 实现文件 | 参考项目 | 参考 key 类/方法 | 关键 hook 目标 |
|---|------|----------|----------|------------------|----------------|
| 1 | 修改微信定位 | `LocationSpoofHook.m` | HB | `TheMsgLocationController.sureSelectLocation` / `TheMessageController.autoSendMsgToLocation*` | `SendMessageLocationController` / `WCSelectLocationViewController` |
| 2 | 密友功能 | `CloseFriendHook.m` | HB | `TheSpecialController.fixMiYouToolBar` / `ThePrivateUserRTingController` / `WCAvatarFramePrivateController` | `CMessageMgr AddMsg:` |
| 3 | 自动跟圈 | `AutoFollowHook.m` | PKC | `PyqAutoRulesInputVC` / `PKCAICommentInputVC` / `WGUivudhwrpjtktq.pkcPyqAIAutoCommnet` | `WCTimeLineViewController onDataUpdated` / `WCFacade` |
| 4 | 聊天加密 | `ChatEncryptHook.m` | PKC + HB | `WGUivudhwrpjtktq.aesEncrypt:key:` / `encryptMsg:` / `pkcJMType` / `MsgSensitiveViewController` | `MessageService SendMsg:` / `CMessageMgr AddMsg:` |
| 5 | 禁用功能 | `DisableFunctionHook.m` | HB | `DisableWeChatController`（44 项 disableXxx:） | `NewMainFrameViewController` / `AVCaptureSession` / `EmoticonStorePanelViewController` |
| 6 | 后台保活 | `BackgroundKeepAlive.m` | PKC | `DDPubelbnrfqsktabgpxclmnjgcj`（blankPlayer/playBlankAudio/bgTaskIdentifier/requestMoreTime/pushMsgNotification） | `UIApplication` / `AVAudioSession` / `AVAudioPlayer` |
| 7 | 防撤回 | `AntiRevokeHook.m` | PKC + HB | `YUXabpqlzbvyoeypregca.revokeEnable/revokeReplyContent/revokeReplyGroupList` / `TheMessageController.autoRevokMsgSec` | `CMessageMgr onRevokeMsg:` |
| 8 | 自动通过好友 | `AutoAcceptFriendHook.m` | PKC | `PKCAutoSayHelloInputVC`（70 字段）/ `WGUivudhwrpjtktq.onAddFriend:/pkcAutoOkFirends:` | `CContactMgr onVerifyUser:` / `CContactVerifyLogic verifyUser:` |
| 9 | 退群监控 | `QuitGroupMonitorHook.m` | HB + PKC | `TheGroupController.enableQuitGroupMonitor*` / `YUXabpqlzbvyoeypregca.pkcExitGroupList/pkcExitReplyContent` | `CMessageMgr AddMsg:`（type=10000 系统消息） |
| 10 | 自动接收转账 | `AutoAcceptTransferHook.m` | PKC | `WGUivudhwrpjtktq.onTransferButtonClicked:` / `WCPayTransferMoneyControlLogic` / `pkcerciquerenFlag` | `WCMessageNodeView onTransferButtonClicked:` / `WCPayTransferMoneyControlLogic` |
| 11 | 抢红包 | `AutoRedEnvelopeHook.m` | PKC + ZDY | `WGUivudhwrpjtktq.pkczdhb*`（25+ 字段）/ `ZDYDLFSViewController.configureAutoHongbaoDelay/Reply` | `CMessageMgr AddMsg:` / `HongBaoMgr openRedEnvelope:` |
| 12 | 好友检测 | `FriendDetectorHook.m` | PKC | `ZXJdikmrrhowgifbqxneocxzknxfypf.FATest:/FAReset:` / `YDUtett.pkcFriendAnalysis/pkcXxErQr` | `CContactMgr getContactList` / `CContactVerifyLogic createChatRoomWithMembers:` |
| 13 | 一键标记已读 | `MarkAllReadHook.m` | MiYou `mIsAllGroupUndeno` 一键清未读 |
| 14 | 长按信息+1 | `MsgLongPressHook.m` | MiYou 消息快捷操作（群内捧场） |
| 15 | 关键词自动回复 | `KeywordAutoReplyHook.m` | MiYou `MYReplyConfig` / `mQuickReplyView` |
| 16 | 关键词提醒（已修复） | `KeywordReminderHook.m` | MiYou `MiYouKeywordTipsController` |
| 17 | 消息快速引用 | `MsgLongPressHook.m` | MiYou `mIsQuoteAtUser` 引用并@ |
| 18 | 自动确认登陆 | `AutoConfirmLoginHook.m` | MiYou `mIsAutoConfirmLogin` |
| 19 | 启用相机识别 | `CameraRecognizeHook.m` | MiYou `mIsSanCodeInCamera` 相机内扫一扫 |

## 各功能配置项

### 1. 修改微信定位
- 纬度 / 经度 / 地址描述
- 朋友圈也生效开关

### 2. 密友功能
- 密友专属铃声
- 密友置顶
- 密友红点提醒

### 3. 自动跟圈
- 自动点赞 / 自动评论开关
- 关键词数组（命中才跟）
- 评论话术数组（随机选取）
- 间隔秒数 / 每日上限（防风控）

### 4. 聊天加密
- AES 密钥
- 加密群白名单（空=全部）
- 显示模式（密文/掩码/自定义）
- 图片加密

### 5. 禁用功能（17 项常用 + 27 项可扩展）
首页搜索栏 / 未读数 / 表情商店 / 表情搜索 / 自拍表情 / 小程序 / 微信支付入口 / 视频号 / 关于微信 / 微信实验室 / 长辈模式 / 自动更新 / 拍一拍提示 / 复制提示 / 输入提示 / 批量撤回 / 扫一扫相机

### 6. 后台保活（pkc 三件套）
- 静音音频保活（AVAudioPlayer 循环播放静音 wav）
- 后台任务保活（beginBackgroundTask 续命）
- 被杀后本地通知

### 7. 防撤回
- 显示撤回原文
- 撤回时弹窗
- 撤回自动回复 + 回复内容

### 8. 自动通过好友
- 申请语关键词（空=全部通过）
- 通过后自动打招呼 + 打招呼内容

### 9. 退群监控
- 弹窗提醒
- 推送到文件助手
- 自动回复到群 + 回复内容

### 10. 自动接收转账
- 延迟秒数（防风控）
- 收款后自动回复 + 回复内容

### 11. 抢红包
- 延迟秒数（+随机抖动±0.5s）
- 群白名单
- 关键词过滤
- 不抢自己发的 / 不抢私聊
- 抢到后感谢 + 感谢话术

### 12. 好友检测
- 检测方式（0=拉群法 30人/批，1=二维码法）
- 检测后自动删除

### 13~19. 新增功能（参考 MiYou-Reversed）
- **13. 一键标记已读**：首页导航栏"全部已读"按钮（tag 去重，不重复插入）
- **14. 长按信息+1**：聊天长按菜单注入"＋1"，向当前会话发送"1"
- **15. 关键词自动回复**：规则 `kw=reply` 逗号分隔；仅群聊 / 跳过自己 / 延迟秒数
- **16. 关键词提醒（已修复重入/误报/重复）**：关键词数组；弹窗 / 推送文件助手 / 震动
- **17. 消息快速引用**：聊天长按菜单注入"引用"，把消息带入输入栏引用对象
- **18. 自动确认登陆**：扫一扫登录确认页自动点击确认（多候选 VC 类兼容，延迟秒数）
- **19. 启用相机识别**：相机页 `AVCaptureMetadataOutput` 追加二维码/条码类型 + 微信扫码图层属性

> 实现要点：`MsgLongPressHook` 合并 14/17（同一 VC，避免重复 hook）；
> `KeywordReminderHook` 已修复 5 类问题（重入死锁、系统消息误报、自己消息误报、重复提醒、非主线程弹窗）；
> `AutoConfirmLoginHook` / `CameraRecognizeHook` 用 per-class orig IMP 映射，避免多类共用一个 orig 指针错乱
> （即 diylib FIXES 强调的"多模块重复 hook 同方法"同类问题）。

## 项目结构

```
diylib/
├── Makefile                    # theos 构建配置
├── diylib.plist                # 注入目标（WeChat）
├── Tweak.xm                    # 入口：设置页注入 + 模块加载
├── DPConfig.h                  # 配置 key 定义
├── src/
│   ├── DPConfig.m              # NSUserDefaults 配置读写
│   ├── DPLog.h                 # 日志宏
│   ├── DPHelper.h/.m           # 通用助手（顶层VC/弹窗/runtime调用）
│   ├── modules/
│   │   ├── LocationSpoofHook.m
│   │   ├── CloseFriendHook.m
│   │   ├── AutoFollowHook.m
│   │   ├── ChatEncryptHook.m
│   │   ├── DisableFunctionHook.m
│   │   ├── BackgroundKeepAlive.m
│   │   ├── AntiRevokeHook.m
│   │   ├── AutoAcceptFriendHook.m
│   │   ├── QuitGroupMonitorHook.m
│   │   ├── AutoAcceptTransferHook.m
│   │   ├── AutoRedEnvelopeHook.m
│   │   └── FriendDetectorHook.m
│   └── ui/
│       ├── DPPreferencesListController.h
│       └── DPPreferencesListController.m  # 设置面板（12功能开关+子项）
└── README.md
```

## 构建说明

```bash
# 需要 theos 环境（macOS 或 配置好的 Linux）
make package FINALPACKAGE=1
# 生成 .deb 安装包
```

## 免责声明

仅供安全研究与逆向学习。请勿用于违反微信用户协议或法律法规的用途。作者 yZFAIU 不对任何滥用行为负责。
