# diylib

越狱微信插件 dylib

- 版本：26.0.1
- 插件名称：NPC
- 作者：yZFAIU
- 目标进程：WeChat
- 最低系统：iOS 14.0
- 架构：arm64 / arm64e

## 功能列表

| # | 功能 | 模块文件 | 参考实现 |
|---|------|----------|----------|
| 1 | 修改微信定位 | `LocationSpoofHook.m` | HB `TheMsgLocationController` |
| 2 | 密友功能 | `CloseFriendHook.m` | HB `TheSpecialController` / `ThePrivateUserRTingController` |
| 3 | 自动跟圈 | `AutoFollowHook.m` | PKC `PyqAutoRulesInputVC` / `PKCAICommentInputVC` |
| 4 | 聊天加密 | `ChatEncryptHook.m` | PKC AES 加密 + HB `MsgSensitive` |
| 5 | 禁用功能 | `DisableFunctionHook.m` | HB `DisableWeChatController` (44 项) |
| 6 | 后台保活 | `BackgroundKeepAlive.m` | PKC `DDPubelbnrfqsktabgpxclmnjgcj` |
| 7 | 防撤回 | `AntiRevokeHook.m` | PKC `revokeReplyContent` + HB `autoRevokMsgSec` |
| 8 | 自动通过好友 | `AutoAcceptFriendHook.m` | PKC `PKCAutoSayHelloInputVC` |
| 9 | 退群监控 | `QuitGroupMonitorHook.m` | HB `TheGroupController` + PKC `pkcExitGroupList` |
| 10 | 自动接收转账 | `AutoAcceptTransferHook.m` | PKC `WCPayTransferMoneyControlLogic` |
| 11 | 抢红包 | `AutoRedEnvelopeHook.m` | PKC `pkczdhb*` + ZDY `AutoHongbaoHelper` |
| 12 | 好友检测 | `FriendDetectorHook.m` | PKC `FATest:` 拉群法 |
| 13 | 一键标记已读 | `MarkAllReadHook.m` | MiYou `mIsAllGroupUndeno` |
| 14 | 长按信息+1 | `MsgLongPressHook.m` | MiYou 消息快捷操作 |
| 15 | 关键词自动回复 | `KeywordAutoReplyHook.m` | MiYou `MYReplyConfig` |
| 16 | 关键词提醒(已修复) | `KeywordReminderHook.m` | MiYou `MiYouKeywordTipsController` |
| 17 | 消息快速引用 | `MsgLongPressHook.m` | MiYou `mIsQuoteAtUser` |
| 18 | 自动确认登陆 | `AutoConfirmLoginHook.m` | MiYou `mIsAutoConfirmLogin` |
| 19 | 启用相机识别 | `CameraRecognizeHook.m` | MiYou `mIsSanCodeInCamera` |

## 构建

```bash
make package FINALPACKAGE=1
```

## 配置入口

设置 → NPC，列出 12 个功能开关与子项配置。

## 免责声明

仅供安全研究与逆向学习。请勿用于违反微信用户协议或法律法规的用途。作者 yZFAIU 不对任何滥用行为负责。
