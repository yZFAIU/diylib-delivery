// DPConfig.h — 全局配置管理
// 用 NSUserDefaults 持久化 12 个功能模块的开关与子项配置。
// 所有 key 集中定义，便于面板与模块共享。

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 12 个功能模块的总开关 key（与 DPPreferencesListController 一一对应）
extern NSString *const kSwitchEnabled;            // 插件总开关
extern NSString *const kSwitchLocationSpoof;      // 1. 修改微信定位
extern NSString *const kSwitchCloseFriend;        // 2. 密友功能
extern NSString *const kSwitchAutoFollow;         // 3. 自动跟圈
extern NSString *const kSwitchChatEncrypt;        // 4. 聊天加密
extern NSString *const kSwitchDisableFunction;    // 5. 禁用功能
extern NSString *const kSwitchBackgroundKeepAlive;// 6. 后台保活
extern NSString *const kSwitchAntiRevoke;         // 7. 防撤回
extern NSString *const kSwitchAutoAcceptFriend;   // 8. 自动通过好友
extern NSString *const kSwitchQuitGroupMonitor;   // 9. 退群监控
extern NSString *const kSwitchAutoAcceptTransfer; // 10. 自动接收转账
extern NSString *const kSwitchAutoRedEnvelope;    // 11. 抢红包
extern NSString *const kSwitchFriendDetector;     // 12. 好友检测

/// 子项配置 key（按功能分组）
// 1. 定位
extern NSString *const kLocationLatitude;
extern NSString *const kLocationLongitude;
extern NSString *const kLocationAddress;
extern NSString *const kLocationForTimeline;      // 朋友圈也生效

// 2. 密友
extern NSString *const kCloseFriendList;          // 密友 wxid 数组
extern NSString *const kCloseFriendRingEnable;    // 密友专属铃声
extern NSString *const kCloseFriendTopEnable;     // 密友置顶
extern NSString *const kCloseFriendRedDotEnable;  // 密友红点提醒

// 3. 自动跟圈
extern NSString *const kAutoFollowLikeEnable;     // 自动点赞
extern NSString *const kAutoFollowCommentEnable;  // 自动评论
extern NSString *const kAutoFollowKeywords;       // 关键词数组（命中才跟）
extern NSString *const kAutoFollowComments;       // 评论话术数组
extern NSString *const kAutoFollowIntervalSec;    // 间隔秒数
extern NSString *const kAutoFollowMaxNumPerDay;   // 每日上限

// 4. 聊天加密
extern NSString *const kChatEncryptAESKey;        // AES 密钥
extern NSString *const kChatEncryptGroupList;     // 加密群白名单
extern NSString *const kChatEncryptDisplayMode;   // 0=密文 1=掩码 2=自定义
extern NSString *const kChatEncryptImageEnable;   // 图片加密

// 5. 禁用功能（每项一个 bool）
extern NSString *const kDisableMainFrameSearchBar;
extern NSString *const kDisableUnReadCount;
extern NSString *const kDisableEmoticonStore;
extern NSString *const kDisableEmoticonSearch;
extern NSString *const kDisableCameraEmoticon;
extern NSString *const kDisableDownApplet;
extern NSString *const kDisableWCPayTitle;
extern NSString *const kDisableWCFinder;
extern NSString *const kDisableSettingAboutMM;
extern NSString *const kDisableSettingLabs;
extern NSString *const kDisableElderMode;
extern NSString *const kDisableAutoGetUpdate;
extern NSString *const kDisablePatViewTips;
extern NSString *const kDisableCopyMsgTip;
extern NSString *const kDisableInputTips;
extern NSString *const kDisableBatchRevokeMsg;
extern NSString *const kDisableAVCapture;

// 6. 后台保活
extern NSString *const kKeepAliveAudioEnable;     // 静音音频保活
extern NSString *const kKeepAliveBgTaskEnable;    // 后台任务保活
extern NSString *const kKeepAliveNotifyOnKill;    // 被杀后本地通知

// 7. 防撤回
extern NSString *const kAntiRevokeReplyEnable;    // 撤回自动回复
extern NSString *const kAntiRevokeReplyContent;   // 自动回复内容
extern NSString *const kAntiRevokeNotifyEnable;   // 撤回时本地通知
extern NSString *const kAntiRevokeShowOrigin;     // 显示原文

// 8. 自动通过好友
extern NSString *const kAutoAcceptFriendKeywords; // 申请语关键词
extern NSString *const kAutoAcceptFriendReplyEnable; // 通过后自动打招呼
extern NSString *const kAutoAcceptFriendReplyText;   // 打招呼内容

// 9. 退群监控
extern NSString *const kQuitGroupMonitorPushSelf; // 推送到文件助手
extern NSString *const kQuitGroupMonitorAlert;    // 弹窗提醒
extern NSString *const kQuitGroupMonitorReplyEnable;
extern NSString *const kQuitGroupMonitorReplyContent;

// 10. 自动接收转账
extern NSString *const kAutoTransferDelaySec;     // 延迟秒数（防风控）
extern NSString *const kAutoTransferReplyEnable;
extern NSString *const kAutoTransferReplyContent;

// 11. 抢红包
extern NSString *const kRedEnvelopeDelaySec;      // 抢红包延迟
extern NSString *const kRedEnvelopeGroupFilter;   // 群白名单
extern NSString *const kRedEnvelopeKeywordFilter; // 关键词过滤
extern NSString *const kRedEnvelopeReplyEnable;   // 抢到后感谢
extern NSString *const kRedEnvelopeReplyText;
extern NSString *const kRedEnvelopeSkipSelf;      // 不抢自己发的
extern NSString *const kRedEnvelopeSkipPrivate;   // 不抢私聊

// 12. 好友检测
extern NSString *const kFriendDetectorMethod;     // 0=拉群法 1=二维码法
extern NSString *const kFriendDetectorAutoDelete; // 检测后自动删除

// 13. 一键标记已读（参考 MiYou mIsAllGroupUndeno 一键清未读）
extern NSString *const kSwitchMarkAllRead;        // 总开关

// 14. 长按信息+1（群内快速捧场，发送"1"）
extern NSString *const kSwitchLongPressPlusOne;   // 总开关

// 15. 关键词自动回复（参考 MiYou MYReplyConfig / mQuickReplyView）
extern NSString *const kSwitchKeywordAutoReply;   // 总开关
extern NSString *const kKeywordAutoReplyPairs;    // "kw1=reply1,kw2=reply2"
extern NSString *const kKeywordAutoReplyOnlyGroup;// 仅群聊生效
extern NSString *const kKeywordAutoReplySkipSelf; // 跳过自己发的消息
extern NSString *const kKeywordAutoReplyDelay;    // 延迟秒数（防风控）

// 16. 关键词提醒（参考 MiYou MiYouKeywordTipsController，已修复重入/误报/重复）
extern NSString *const kSwitchKeywordReminder;    // 总开关
extern NSString *const kKeywordReminderKeywords;  // 逗号分隔关键词数组
extern NSString *const kKeywordReminderAlert;     // 弹窗提醒
extern NSString *const kKeywordReminderPushSelf;  // 推送到文件助手
extern NSString *const kKeywordReminderVibrate;   // 震动提醒

// 17. 消息快速引用（参考 MiYou mIsQuoteAtUser 引用并@）
extern NSString *const kSwitchQuickQuote;         // 总开关

// 18. 自动确认登陆（参考 MiYou mIsAutoConfirmLogin）
extern NSString *const kSwitchAutoConfirmLogin;   // 总开关
extern NSString *const kAutoConfirmLoginDelay;    // 延迟秒数

// 19. 启用相机识别（参考 MiYou mIsSanCodeInCamera 相机内扫一扫）
extern NSString *const kSwitchCameraRecognize;    // 总开关

@interface DPConfig : NSObject

/// 读取 bool 配置
+ (BOOL)boolForSwitchKey:(NSString *)key;
/// 写入 bool 配置
+ (void)setBool:(BOOL)value forSwitchKey:(NSString *)key;
/// 读取对象配置
+ (nullable id)objectForKey:(NSString *)key;
/// 写入对象配置
+ (void)setObject:(nullable id)value forKey:(NSString *)key;
/// 读取整数
+ (NSInteger)integerForKey:(NSString *)key;
+ (void)setInteger:(NSInteger)value forKey:(NSString *)key;
/// 读取 double
+ (double)doubleForKey:(NSString *)key;
+ (void)setDouble:(double)value forKey:(NSString *)key;

/// 初始化默认值（首次安装时写入）
+ (void)migrateDefaults;

@end

NS_ASSUME_NONNULL_END
