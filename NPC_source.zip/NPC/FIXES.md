# diylib 闪退修复说明

> 版本 26.0.1 / 名称 NPC / 作者 yZFAIU
> 修复日期：2026-07-26

## 修复概览

本次共修复 **9 类导致闪退/编译失败的关键问题**，涉及 12 个模块文件、入口 Tweak.xm、Makefile 及设置面板。核心思路是引入 **AddMsg 集中式单点 hook 分发器**，彻底消除多模块重复 hook 同一方法导致的 orig 指针错乱与无限递归。

## 修复清单

### 🔴 致命问题 1：CMessageMgr AddMsg: 多模块重复 hook 冲突

**现象**：接收消息时闪退（栈溢出或调用错乱）

**根因**：4 个模块各自用独立 `orig` 指针 hook 同一 `CMessageMgr AddMsg:`：
- CloseFriendHook (`orig_AddMsg`)
- ChatEncryptHook (`orig_AddMsg_Enc`)
- QuitGroupMonitorHook (`orig_AddMsg_QGM`)
- AutoRedEnvelopeHook (`orig_AddMsg_RE`)

每个模块 `+load` 时 `method_setImplementation` 会覆盖前一个，导致只有最后加载模块的 `orig` 指向原生实现，其余指向其他 hook 函数地址，形成错乱调用链，极端情况下无限递归 → 栈溢出。

**修复**：新增 `DPMessageDispatcher` 单例，唯一 hook `AddMsg:`，保存唯一 `orig_AddMsg_dispatch` 指针。各模块通过 `subscribeForKey:handler:` 注册回调，分发器在 orig 调用前（phase=0）和后（phase=1）依次通知订阅者。

### 🔴 致命问题 2：Makefile 引用不存在的 DPLog.m

**现象**：编译失败

**根因**：Makefile 第 13 行 `src/DPLog.m`，但项目只有 `DPLog.h`（纯宏定义，无需 .m）。

**修复**：从 `diylib_FILES` 移除该行。

### 🔴 致命问题 3：DPPreferencesListController 头文件与实现不匹配

**现象**：编译失败 / 运行时找不到方法

**根因**：
1. `.h` 继承 `PSListController`（需 Preferences.framework），但 `.m` 是纯 UIKit 实现，Makefile 未链接该框架
2. `.m` import `FriendDetectorHook.h`，但该 `.m` 文件无对应 `.h`

**修复**：
1. `.h` 改为继承 `UITableViewController`
2. 新建 `FriendDetectorHook.h`
3. `.m` 不再重建 tableView（UITableViewController 已自动创建）

### 🔴 致命问题 4：重复类前向声明导致符号冲突

**现象**：链接失败（duplicate symbol）

**根因**：`CMessageMgr`/`CMessageWrap`/`CContactMgr` 等在多个 `.m` 重复 `@interface` 声明。

**修复**：新建 `DPPrivateClasses.h` 集中声明，各模块统一 import。

### 🔴 致命问题 5：LocationSpoofHook 结构体传参崩溃

**现象**：发送定位时闪退

**根因**：用 `performSelector:withObject:withObject:` 传 `CLLocationCoordinate2D` 结构体，该方法只接受 `id`，把 `NSValue` 指针当结构体内存读 → 内存非法访问。

**修复**：改用 `NSInvocation` + `setArgument:atIndex:` 正确传递结构体。

### 🔴 致命问题 6：AntiRevokeHook 不调用 orig 导致状态不一致

**现象**：撤回消息后偶发崩溃

**根因**：完全吞掉 `onRevokeMsg:` 不调 orig，微信消息状态机未完成更新，后续访问消息触发断言或访问已释放对象。

**修复**：先备份 content，调用 orig（让微信完成状态更新），orig 后恢复原文并重置撤回标志。

### 🔴 致命问题 7：BackgroundKeepAlive 引用循环与观察者泄漏

**现象**：后台保活失效 / 内存泄漏 / 偶发崩溃

**根因**：
1. `NSTimer target:self` 强引用造成循环引用
2. `+load` 里 `addObserver:` 从不移除，dylib 多次加载累积观察者
3. `endBgTask` 对 nil timer 调 invalidate

**修复**：
1. 新增 `DPWeakTimerProxy` 间接持有 target
2. `dispatch_once` 保证只注册一次观察者，`dealloc` 移除
3. nil 检查
4. 修复原文件注释乱码

### 🔴 致命问题 8：SettingViewController numberOfRowsInSection 递归

**现象**：进入设置页闪退（栈溢出）

**根因**：`cellForRowAtIndexPath:` 内调用 `[self tableView:numberOfRowsInSection:]`，该方法被 hook 后 `orig` 可能回调 `cellForRowAtIndexPath:` 形成递归。

**修复**：用关联对象缓存原始行数，`cellForRowAtIndexPath:` 直接读缓存，不再回调 `numberOfRowsInSection:`。

### 🔴 致命问题 9：DPPreferencesListController 开关保存失败

**现象**：开关切换后状态丢失（功能失效）

**根因**：`onSwitchChanged:` 用 `[[sw superview] superview]` 找 cell，iOS 11+ superview 层级为 `UISwitch→UITableViewCellContentView→UITableViewCell`，需 3 层，只取 2 层得 nil。

**修复**：改用 `tag` 编码（section×10000+row）直接计算 indexPath，不依赖 view 层级。

## 第二轮复查发现的问题

### 🟠 问题 10：首次安装时所有模块不加载（配置迁移时序 bug）

**现象**：首次安装后插件完全不工作，需重启微信才生效

**根因**：`migrateDefaults` 在 `__attribute__((constructor))` 里调用，但 constructor 执行晚于各模块的 `+load`。首次安装时 NSUserDefaults 为空，模块 `+load` 读 `kSwitchEnabled` 返回 NO，全部跳过 hook/订阅。之后 constructor 才写入默认值，但 `+load` 不会重新执行。

**修复**：
1. 在 `DPConfig` 添加 `+load` 调用 `migrateDefaults`（DPConfig.m 在 Makefile FILES 中排在所有模块之前，`+load` 先执行）
2. `boolForSwitchKey:` 对 `kSwitchEnabled` 特殊处理：未设置时返回 YES（兜底）

### 🟠 问题 11：DPMessageDispatcher 串行队列 dispatch_sync 重入死锁

**现象**：handler 内部若触发 AddMsg 重入（如同步自动回复），`dispatch_sync` 重入串行队列会死锁

**根因**：`dispatchMessage:phase:` 用 `dispatch_sync(_lockQueue, ...)` 取 handlers 快照，若 handler 内部同步调用 AddMsg → 再次进入 `dispatchMessage` → `dispatch_sync` 重入同一串行队列 → 死锁。

**修复**：改用 `@synchronized(self)` 取 handlers 快照后释放锁，在锁外调用 handler。`subscribe/unsubscribe` 也统一用 `@synchronized`。

### 🟠 问题 12：NSInvocation getReturnValue ARC 所有权问题

**现象**：ARC 下 `getReturnValue:` 取出的对象引用不经过 ARC 管理，用 `__strong` 变量接收可能导致过度释放

**根因**：`LocationSpoofHook.newLocationDataWithCoord` 和 `DPHelper.performSelectorOnObject:sel:withObjects:` 用 `id ret = nil; [inv getReturnValue:&ret];` 接收返回值，ARC 会在 return 时多 release 一次。

**修复**：改用 `__unsafe_unretained id ret` 接收，再返回。

### 🟠 问题 13：FriendDetectorHook block 传给 NSInvocation 未 copy

**现象**：建群 completion block 是栈 block，若微信异步执行，block 销毁后回调野指针崩溃

**根因**：`NSInvocation setArgument:atIndex:` 不会 copy block 参数。

**修复**：block 声明时加 `copy` 拷贝到堆。

### 🟠 问题 14：DPWeakTimerProxy methodSignatureForSelector 调用错误

**现象**：target 为空时 `[NSObject methodSignatureForSelector:sel]` 对类对象调用实例方法，可能返回 nil 或异常

**根因**：应为 `[NSObject instanceMethodSignatureForSelector:sel]`。

**修复**：改为 `instanceMethodSignatureForSelector:`。

## 新增文件

| 文件 | 作用 |
|------|------|
| `src/DPMessageDispatcher.h/.m` | AddMsg 集中式单点 hook 分发器 |
| `src/DPPrivateClasses.h` | 微信私有类集中前向声明 |
| `src/modules/FriendDetectorHook.h` | 好友检测模块头文件 |

## 修改文件

| 文件 | 修改内容 |
|------|----------|
| `Makefile` | 移除 DPLog.m，新增 DPMessageDispatcher.m |
| `Tweak.xm` | 安装分发器，修复 numberOfRowsInSection 递归 |
| `src/modules/CloseFriendHook.m` | 改为订阅分发器 |
| `src/modules/ChatEncryptHook.m` | 改为订阅分发器 |
| `src/modules/QuitGroupMonitorHook.m` | 改为订阅分发器 |
| `src/modules/AutoRedEnvelopeHook.m` | 改为订阅分发器 |
| `src/modules/AntiRevokeHook.m` | 调用 orig 保持状态一致 |
| `src/modules/LocationSpoofHook.m` | NSInvocation 传结构体 |
| `src/modules/DisableFunctionHook.m` | 移除重复声明，orig 非空检查 |
| `src/modules/BackgroundKeepAlive.m` | weak proxy 修引用循环，修乱码 |
| `src/modules/AutoAcceptFriendHook.m` | 移除重复声明，orig 非空检查 |
| `src/modules/AutoAcceptTransferHook.m` | 移除重复声明，orig 非空检查 |
| `src/modules/AutoFollowHook.m` | 移除重复声明，orig 非空检查 |
| `src/modules/FriendDetectorHook.m` | 新增 .h，移除重复声明 |
| `src/ui/DPPreferencesListController.h` | 改继承 UITableViewController |
| `src/ui/DPPreferencesListController.m` | tag 计算 indexPath，不重建 tableView |

## 第三轮：新增 7 功能（参考 MiYou-Reversed-v1.0，用户标注"关键词提醒需修复"）

本次在 diylib 基础上新增功能 13~19，参考 `MiYou-Reversed` 逆向重建头文件中的类/配置项命名
（如 `mIsAutoConfirmLogin` / `mIsSanCodeInCamera` / `mIsQuoteAtUser` / `MYReplyConfig` /
`MiYouKeywordTipsController`）。MiYou 仅为头文件骨架（Tweak.xm 为 TODO 桩），故逻辑按 diylib
既有架构实现。应用了与历史 FIXES 一致的工程纪律，重点修复了用户标注的"关键词提醒"问题：

### 🔴 关键词提醒（功能16）修复 5 类问题
1. **重入死锁/递归**：handler 内同步调用 `AddMsg` 会重入分发器。改为 `[DPHelper after:delay onMain:]`
   异步派发，绝不在 handler 内同步触发 AddMsg。
2. **系统消息误报**：`type==10000` 系统消息（"你邀请xxx"等）也被匹配提醒。已跳过。
3. **自己消息误报**：自己发的消息也触发提醒。已通过 `getSelfContact` 比对 wxid 跳过。
4. **重复提醒**：同一消息/关键词短时间内重复命中。改为 内容hash+关键词 去重 + 3s 节流。
5. **非主线程弹窗**：通知/弹窗/震动未在主线。统一 `runOnMain` / `after onMain`。

### 🟠 多类 hook 的 orig 指针错乱（功能18/19）
`AutoConfirmLoginHook` / `CameraRecognizeHook` 需兼容多个微信 VC 类名。若多个类共用一个
`orig` 静态指针，后加载类会覆盖前者（即"多模块重复 hook 同方法"同类 bug）。改用
`CFMutableDictionary` 按 Class 保存各自 `orig` IMP，hook 函数按实例所属类查表调用。

### 🟠 长按菜单注入时机（功能14/17）
微信长按时重建 `UIMenuController.menuItems`，仅 `viewDidLoad` 注册一次会被覆盖。改为监听
`UIMenuControllerWillShowMenuNotification` 在展示前注入，并自加 `UILongPressGestureRecognizer`
（`cancelsTouchesInView=NO`）捕获当前消息 wrap，与原生长按并存。

### 🔴 长按菜单去重崩溃（功能14/17，二次复查发现）
`npc_injectMenuItems` 原用 `[e.action isEqual:it.action]` 比较两个 `SEL`。`SEL` 是指针不是对象，
对它发 `isEqual:` 属未定义行为；微信原生长按菜单非空时该循环必然执行 → 真机崩溃。
改为指针比较 `e.action == it.action`（同 selector 名运行时返回同一指针，等价且安全）。
同时把 `canPerformAction:withSender:` 对我们两个 action 的返回值改为按各自开关判断，
避免任何路径下误放行菜单项。

### 新增文件
| 文件 | 作用 |
|------|------|
| `src/modules/MarkAllReadHook.m` | 功能13 一键标记已读 |
| `src/modules/MsgLongPressHook.m` | 功能14(+1) + 功能17(引用) |
| `src/modules/KeywordAutoReplyHook.m` | 功能15 关键词自动回复 |
| `src/modules/KeywordReminderHook.m` | 功能16 关键词提醒（已修复） |
| `src/modules/AutoConfirmLoginHook.m` | 功能18 自动确认登陆 |
| `src/modules/CameraRecognizeHook.m` | 功能19 启用相机识别 |

### 修改文件
| 文件 | 修改内容 |
|------|----------|
| `DPConfig.h` / `DPConfig.m` | 新增 13~19 配置 key 与默认值 |
| `DPPrivateClasses.h` | 新增 `BaseMsgContentViewController` 声明 |
| `Tweak.xm` | 声明 6 个新模块类 |
| `Makefile` | 新增 6 个模块 .m |
| `src/ui/DPPreferencesListController.m` | 新增 7 个功能设置分区 + doubleKeys |
| `FEATURES.md` / `README.md` | 功能表补充 13~19 |

---

## 三次复查（"再检查一遍"）发现并修复

### 🔴 CFDictionary 回调非法（功能18/19）
`AutoConfirmLoginHook` / `CameraRecognizeHook` 原用 `CFDictionaryCreateMutable(NULL, 0,
&kCFTypeDictionaryKeyCallBacks, NULL)` 存「Class→orig IMP」。Class 不是 CF 对象，`kCFType`
回调会对 Class 指针调用 `CFRetain` 读坏类内存（崩溃/内存损坏）；value 回调传 `NULL` 也非法。
改为指针等式、不 retain 的空回调（`kPtrKeyCB`/`kPtrValCB`），并新增 `origIMPForClass()`
向上回溯父类查找 orig，避免「只 hook 父类、子类实例走此 hook 却丢失 orig」导致原生生命周期被吞。

### 🔴 canPerformAction 污染 UIResponder（功能14/17）
`MsgLongPressHook` 原对 `BaseMsgContentViewController` 的 `canPerformAction:withSender:`
直接 `method_setImplementation`。若该类未**直接**实现此方法（继承自 `UIResponder`），
`method_setImplementation` 会替换掉 `UIResponder` 的全局实现，污染整个 App 所有响应者。
改为安全 swizzle：先 `class_copyMethodList` 判断本类是否直接实现；若未实现，先用
`class_addMethod` 把「继承来的 IMP」加回本类，再只替换本类的 IMP，保证不波及系统类。

### 复查已确认无问题
- 6 个新模块括号/中括号配平均 0 0 0，无游离方法定义；
- 所有引用的 17 个新配置 key 均在 `DPConfig.h` 声明、在 `DPConfig.m` 定义并注册进 `migrateDefaults`；
- `AddMsg:` 派发、phase=1（orig 后）订阅、`performSelectorOnObject:` 入参索引(i+2) 均符合 `DPMessageDispatcher`/`DPHelper` 约定；
- 群聊回复目的地 `m_nsToUsr = 原消息.m_nsFromUsr` 与工程既有模块约定一致。


## 构建

```bash
make package FINALPACKAGE=1
```

## 免责声明

仅供安全研究与逆向学习。请勿用于违反微信用户协议或法律法规的用途。作者 yZFAIU 不对任何滥用行为负责。
