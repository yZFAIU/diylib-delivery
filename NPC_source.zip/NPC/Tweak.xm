// Tweak.xm — diylib 入口
// 版本 26.0.2 / 名称 NPC / 作者 yZFAIU
// 注：26.0.2 为换包名后新版本，日志 "loaded into WeChat" 会打印 v26.0.2，便于确认未读旧缓存。
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入（搬备份包 XJWeChatPay 的方案：主设置页顶部 tableHeaderView 按钮）

// 做法（参考备份包 XJWeChatPay_v3.0 的 Req1，已在多版本验证）：
//   不 hook 表格 dataSource（新版“我”页数据源是 MMTableViewInfo，只 hook VC 表格方法无效），
//   改为 hook UIViewController 的 viewDidAppear:，当前页是“主设置页”时，直接把入口做成
//   tableHeaderView 按钮插到表格顶部。tableHeaderView 一定生效，与微信版本/数据源结构无关，
//   也不存在“未知行高度为 0 不可见”的问题。
//
//   主设置页判定：类名含 "Setting" 且不是子设置页（Group/Chat/Room/Contact/.../Wallet 等）。

// 递归在视图树里找 UITableView，避免依赖具体 ivar 名（m_tableView / tableView / _tableView）。
static UITableView *npc_findTableView(UIView *view) {
    if ([view isKindOfClass:[UITableView class]]) return (UITableView *)view;
    for (UIView *sub in view.subviews) {
        UITableView *t = npc_findTableView(sub);
        if (t) return t;
    }
    return nil;
}

// 判断是否为微信“主设置页”（排除子设置页）。
static BOOL npc_isMainSettingsVC(NSString *cls) {
    if (![cls containsString:@"Setting"]) return NO;
    NSArray *exclude = @[@"Group", @"Chat", @"Room", @"Contact", @"Friend", @"Member",
                         @"Privacy", @"Account", @"About", @"General", @"Notification",
                         @"Message", @"Help", @"Label", @"Device", @"Security", @"Wallet"];
    for (NSString *e in exclude) {
        if ([cls containsString:e]) return NO;
    }
    return YES;
}

// 打开插件设置页（NPC 配置面板）。
static void npc_openPluginSettings(UIViewController *vc) {
    if (!vc) return;
    DPPreferencesListController *pc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
    [vc.navigationController pushViewController:pc animated:YES];
}

// 注入“NPC 设置”入口按钮到设置页表格头部（仿微信原生设置行样式）。
static void npc_injectSettingsHeader(UIViewController *vc) {
    if (objc_getAssociatedObject(vc, "npc_settings_injected")) return;
    if (!vc.isViewLoaded || !vc.view.window) return;
    UITableView *tv = npc_findTableView(vc.view);
    if (!tv) return;
    objc_setAssociatedObject(vc, "npc_settings_injected", @(1), OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    CGFloat cardH = 48;   // 与原生设置行高度一致
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tv.bounds.size.width, cardH + 8)];
    header.backgroundColor = [UIColor clearColor];

    UIButton *card = [UIButton buttonWithType:UIButtonTypeCustom];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    card.layer.cornerRadius = 0;
    card.layer.masksToBounds = YES;
    [card addTarget:vc action:@selector(npc_openPluginSettingsAction) forControlEvents:UIControlEventTouchUpInside];
    [card addTarget:card action:@selector(npc_touchDown:) forControlEvents:UIControlEventTouchDown];
    [card addTarget:card action:@selector(npc_touchUp:) forControlEvents:(UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel)];

    [header addSubview:card];
    [header addConstraints:@[
        [card.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:0],
        [card.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:0],
        [card.topAnchor constraintEqualToAnchor:header.topAnchor constant:4],
        [card.heightAnchor constraintEqualToConstant:cardH],
    ]];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = @"NPC 设置";
    titleLabel.font = [UIFont systemFontOfSize:15];
    titleLabel.textColor = [UIColor labelColor];
    [card addSubview:titleLabel];

    UIImageView *chevron = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"chevron.right"]];
    if (chevron.image) {
        chevron.translatesAutoresizingMaskIntoConstraints = NO;
        chevron.tintColor = [UIColor tertiaryLabelColor];
        chevron.contentMode = UIViewContentModeScaleAspectFit;
        [card addSubview:chevron];
        [NSLayoutConstraint activateConstraints:@[
            [chevron.centerYAnchor constraintEqualToAnchor:card.centerYAnchor],
            [chevron.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-12],
            [chevron.widthAnchor constraintEqualToConstant:9],
            [chevron.heightAnchor constraintEqualToConstant:14],
        ]];
    } else {
        UILabel *chevLbl = [[UILabel alloc] init];
        chevLbl.translatesAutoresizingMaskIntoConstraints = NO;
        chevLbl.text = @"\u203A";
        chevLbl.font = [UIFont systemFontOfSize:18 weight:UIFontWeightLight];
        chevLbl.textColor = [UIColor tertiaryLabelColor];
        chevLbl.textAlignment = NSTextAlignmentCenter;
        [card addSubview:chevLbl];
        [NSLayoutConstraint activateConstraints:@[
            [chevLbl.centerYAnchor constraintEqualToAnchor:card.centerYAnchor],
            [chevLbl.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-12],
        ]];
    }

    UIView *separator = [[UIView alloc] init];
    separator.translatesAutoresizingMaskIntoConstraints = NO;
    separator.backgroundColor = [UIColor separatorColor];
    [card addSubview:separator];
    [NSLayoutConstraint activateConstraints:@[
        [separator.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16],
        [separator.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:0],
        [separator.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],
        [separator.heightAnchor constraintEqualToConstant:0.5],
    ]];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:16],
        [titleLabel.centerYAnchor constraintEqualToAnchor:card.centerYAnchor],
        [titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:card.trailingAnchor constant:-28],
    ]];

    tv.tableHeaderView = header;
    [tv layoutIfNeeded];
}

// 按钮触摸反馈（轻微缩放）。
@interface UIButton (NPCTouchFeedback)
- (void)npc_touchDown:(id)sender;
- (void)npc_touchUp:(id)sender;
@end
@implementation UIButton (NPCTouchFeedback)
- (void)npc_touchDown:(id)sender {
    [UIView animateWithDuration:0.12 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.transform = CGAffineTransformMakeScale(0.97, 0.97);
        self.alpha = 0.9;
    } completion:nil];
}
- (void)npc_touchUp:(id)sender {
    [UIView animateWithDuration:0.2 delay:0 usingSpringWithDamping:0.6 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.transform = CGAffineTransformIdentity;
        self.alpha = 1.0;
    } completion:nil];
}
@end

// 入口按钮点击：打开插件设置（加到 UIViewController 分类，避免依赖具体 VC 类）。
@interface UIViewController (NPCPluginSettings)
- (void)npc_openPluginSettingsAction;
@end
@implementation UIViewController (NPCPluginSettings)
- (void)npc_openPluginSettingsAction { npc_openPluginSettings(self); }
@end

// 主设置页识别后注入入口按钮（覆盖所有“我 → 设置”主设置页，与微信版本无关）。
%hook UIViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    NSString *cls = NSStringFromClass([self class]);
    if (npc_isMainSettingsVC(cls)) {
        npc_injectSettingsHeader(self);
    }
}
%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。
// migrateDefaults 已在 DPConfig +load 中调用，这里再调一次是幂等保险。
__attribute__((constructor))
static void diylibEntry(void) {
    @autoreleasepool {
        DPLogInfo(@"diylib v26.0.2 (NPC) by yZFAIU loaded into WeChat");
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        // 安装 AddMsg 集中分发器（幂等，只 hook 一次）。
        // 各模块在自身 +load 中按开关决定是否订阅分发器或独立 hook 自己的目标方法。
        // 注意：模块 +load 早于 constructor 执行，订阅先于 install，时序正确。
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
