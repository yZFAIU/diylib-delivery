// npc_substrate_shim.c
// 提供 MSHookMessageEx 的安全转发实现，消除“运行环境缺 Substrate/ElleKit 时
// dylib 一加载就崩溃”的问题（之前的设置入口用 Logos %hook，编译成对 MSHookMessageEx
// 的调用；环境缺 substrate 时该符号解析不到，调用即崩）。
//
// 机制：
//   - 若进程里已加载真正的 Substrate/ElleKit（导出 MSHookMessageEx），转发给它，hook 正常工作；
//   - 若找不到（只找到本 shim 自身），则安全 no-op，不崩，App 照常运行（插件处于休眠状态）。
// 功能模块用 method_setImplementation，不依赖此符号，不受影响。
#include <dlfcn.h>
#include <objc/runtime.h>

typedef void (*NPC_MSHookMsgFn)(Class cls, SEL sel, IMP imp, IMP *orig);

// 用 -1 哨兵表示“尚未解析”，避免与 NULL 函数指针混淆。
static NPC_MSHookMsgFn npc_real_hookmsg = (NPC_MSHookMsgFn)-1;

void MSHookMessageEx(Class cls, SEL sel, IMP imp, IMP *orig) {
    if (npc_real_hookmsg == (NPC_MSHookMsgFn)-1) {
        void *sym = dlsym(RTLD_DEFAULT, "MSHookMessageEx");
        // 排除“找到的只是本 shim 自身”的情况（说明真正的 substrate 不存在）
        if (sym && sym != (void *)&MSHookMessageEx) {
            npc_real_hookmsg = (NPC_MSHookMsgFn)sym;
        } else {
            npc_real_hookmsg = NULL;
        }
    }
    if (npc_real_hookmsg) {
        npc_real_hookmsg(cls, sel, imp, orig);
    }
}
