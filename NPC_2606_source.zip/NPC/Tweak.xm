// Tweak.xm — diylib 入口
// 版本 26.0.6 / 名称 NPC / 作者 yZFAIU
// 注：26.0.6 修复“缺 Substrate/ElleKit 时 dylib 一加载就崩”——内置 MSHookMessageEx 安全转发 shim
//     （真 substrate 在则转发、不在则 no-op）；26.0.5 已修复链接平台误用 darwin 导致 dyld 拒载。
//
// 本文件负责：
//   1) 注入微信设置页入口（NPC 配置面板）
//   2) 在 dylib 加载时按总开关初始化：安装 AddMsg 集中分发器，
//      各功能模块在自身 +load 中订阅分发器或独立 hook 自身目标方法。
//
// 12 个功能模块的 hook 逻辑放在 src/modules/*.m，各自独立，互不依赖。
// CMessageMgr AddMsg: 由 DPMessageDispatcher 单点 hook，各模块订阅，避免多 orig 冲突。

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import "DPConfig.h"
#import "DPLog.h"
#import "DPHelper.h"
#import "DPPrivateClasses.h"
#import "DPMessageDispatcher.h"
#import "DPPreferencesListController.h"

// ===== 模块初始化声明（每个模块提供 +load 按需 hook）=====
@interface LocationSpoofHook : NSObject @end
@interface CloseFriendHook : NSObject @end
@interface AutoFollowHook : NSObject @end
@interface ChatEncryptHook : NSObject @end
@interface DisableFunctionHook : NSObject @end
@interface BackgroundKeepAliveHook : NSObject @end
@interface AntiRevokeHook : NSObject @end
@interface AutoAcceptFriendHook : NSObject @end
@interface QuitGroupMonitorHook : NSObject @end
@interface AutoAcceptTransferHook : NSObject @end
@interface AutoRedEnvelopeHook : NSObject @end
@interface FriendDetectorHook : NSObject @end
// 新增 7 个功能（13~19，参考 MiYou-Reversed）
@interface MarkAllReadHook : NSObject @end
@interface MsgLongPressHook : NSObject @end
@interface KeywordAutoReplyHook : NSObject @end
@interface KeywordReminderHook : NSObject @end
@interface AutoConfirmLoginHook : NSObject @end
@interface CameraRecognizeHook : NSObject @end

#pragma mark - 微信设置页入口注入（搬 MiYou/PKC 验证做法：hook 表格数据源注入分区）

// 做法（已在 PKC / HB / ZDY 等多个微信插件上验证，8.0.76 通用）：
//   微信「我 → 设置」页(NewSettingViewController / MoreViewController) 的表格 dataSource 是
//   MMTableViewInfo(或新版 WCTableViewManager)，VC 自身的表格方法不会被调用。
//   因此直接 hook 数据源的 UITableViewDataSource 方法，在“设置页”表格里追加一个「NPC」分区 + 一行「NPC 设置」。
//   通过给数据源实例打 associatedObject 标记，只在设置页表格注入，其它表格(聊天/通讯录等)完全不受影响。

// 递归在视图树里找 UITableView（不依赖具体 ivar 名）。
static UITableView *npc_findTableView(UIView *view) {
    if ([view isKindOfClass:[UITableView class]]) return (UITableView *)view;
    for (UIView *sub in view.subviews) {
        UITableView *t = npc_findTableView(sub);
        if (t) return t;
    }
    return nil;
}

// 由 UITableView 经响应链找所在的 UIViewController。
static UIViewController *npc_ownerVC(UIView *view) {
    UIResponder *r = view;
    while (r) {
        if ([r isKindOfClass:[UIViewController class]]) return (UIViewController *)r;
        r = r.nextResponder;
    }
    return nil;
}

// 打开插件设置页（NPC 配置面板）。
static void npc_openPluginSettings(UIViewController *vc) {
    if (!vc) return;
    DPPreferencesListController *pc = [[DPPreferencesListController alloc] initWithStyle:UITableViewStyleGrouped];
    [vc.navigationController pushViewController:pc animated:YES];
}

// 生成「NPC 设置」入口 Cell（仿原生设置行）。
static UITableViewCell *npc_makeEntryCell(void) {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.textLabel.text = @"NPC 设置";
    cell.textLabel.font = [UIFont systemFontOfSize:17];
    cell.textLabel.textColor = [UIColor labelColor];
    cell.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    return cell;
}

// 轻量 toast：黑底白字、居中靠下，约 2.2 秒后自动淡出。用于「插件已加载」等提示。
// 带重试：启动早期 keyWindow 可能尚未就绪，最多重试若干次直到拿到窗口。
static void npc_showToastImpl(NSString *msg, int tries) {
    if (!msg.length || tries <= 0) return;
    UIWindow *win = nil;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                UIWindowScene *ws = (UIWindowScene *)scene;
                for (UIWindow *w in ws.windows) { if (w.isKeyWindow) { win = w; break; } }
                if (win) break;
            }
        }
    } else {
        win = [UIApplication sharedApplication].keyWindow;
    }
    if (!win || win.bounds.size.width < 1) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            npc_showToastImpl(msg, tries - 1);
        });
        return;
    }
    UILabel *label = [[UILabel alloc] init];
    label.text = msg;
    label.textColor = [UIColor whiteColor];
    label.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.82];
    label.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.layer.cornerRadius = 12;
    label.clipsToBounds = YES;
    CGFloat maxW = MIN(win.bounds.size.width - 60, 280);
    CGSize s = [label sizeThatFits:CGSizeMake(maxW, CGFLOAT_MAX)];
    CGFloat bw = s.width + 28;
    CGFloat bh = s.height + 18;
    label.frame = CGRectMake((win.bounds.size.width - bw) / 2, win.bounds.size.height - 140, bw, bh);
    label.alpha = 0;
    [win addSubview:label];
    [UIView animateWithDuration:0.28 animations:^{ label.alpha = 1; }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.4 animations:^{ label.alpha = 0; } completion:^(BOOL f){ [label removeFromSuperview]; }];
    });
}

static void npc_showToast(NSString *msg) {
    npc_showToastImpl(msg, 8);
}

// 诊断：dylib 被加载时立即写标记文件 + 探测 hooking substrate，用于确认是否真正注入成功。
// 不依赖任何 hook / UI，只要镜像被 dyld 加载就会执行（构造函数最早期）。
static void npc_writeDiag(void) {
    void *h = dlopen(NULL, RTLD_NOW);
    // 用 MSHookFunction 判定“真正的 substrate”是否存在（本 dylib 自带的 MSHookMessageEx shim 不导出 MSHookFunction）。
    void *f = h ? dlsym(h, "MSHookFunction") : NULL;
    BOOL subOK = (f != NULL);
    NSString *home = (NSHomeDirectory() ?: @"?");
    NSString *info = [NSString stringWithFormat:
        @"[NPC diylib] loaded v26.0.6\nhome=%@\nsubstrate(MSHookFunction)=%@\ntime=%@\n",
        home, subOK ? @"YES" : @"NO", [NSDate date]];
    // 1) 写入 App 沙盒 Documents（可用 Filza 查看）
    NSString *dir = [home stringByAppendingPathComponent:@"Documents"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *path = [dir stringByAppendingPathComponent:@"npc_loaded.txt"];
    [info writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    // 2) 也尝试写 /var/mobile（无权限则忽略）
    [@"[NPC diylib] loaded" writeToFile:@"/var/mobile/npc_loaded.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

// 标记“设置页”表格的数据源，并触发一次 reload 让新增分区生效（幂等）。
static void npc_markSettingsInfo(UIViewController *vc) {
    if (objc_getAssociatedObject(vc, "npc_marked")) return;
    UITableView *tv = npc_findTableView(vc.view);
    if (!tv) return;
    id info = tv.dataSource;
    if (!info) {
        // 退路：直接拿 VC 上的数据源属性（不同微信版本命名不同）。
        info = [vc valueForKey:@"m_tableViewInfo"];
        if (!info) info = [vc valueForKey:@"m_tableViewMgr"];
        if (!info) info = [vc valueForKey:@"tableViewInfo"];
    }
    if (!info) return;
    objc_setAssociatedObject(info, "npc_isSettingsInfo", @(1), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(vc, "npc_marked", @(1), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [tv reloadData];
    DPLogInfo(@"[NPC] 设置页数据源已标记，准备注入 NPC 分区");
}

// 设置页 VC：出现后标记其表格数据源（覆盖 8.0.x 各版本的主设置页）。
%hook NewSettingViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_markSettingsInfo(self);
}
%end
%hook MoreViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_markSettingsInfo(self);
}
%end
%hook SettingViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    npc_markSettingsInfo(self);
}
%end

%hook MMTableViewInfo
// 注入逻辑：仅当本数据源实例被打上 npc_isSettingsInfo 标记（即设置页表格）时生效。
// 所有 section/row 索引相关方法对“我的分区”都返回安全值，避免越界崩溃。
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv {
    NSInteger orig = %orig;
    if (objc_getAssociatedObject(self, "npc_isSettingsInfo")) {
        objc_setAssociatedObject(self, "npc_origSections", @(orig), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return orig + 1;
    }
    return orig;
}
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 1;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return npc_makeEntryCell();
    return %orig;
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        npc_openPluginSettings(npc_ownerVC(tv));
        return;
    }
    %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return 56;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv estimatedHeightForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return 56;
    return %orig;
}
- (void)tableView:(UITableView *)tv willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) { cell.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor]; return; }
    %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv estimatedHeightForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (UIView *)tableView:(UITableView *)tv viewForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (BOOL)tableView:(UITableView *)tv canEditRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return NO;
    return %orig;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tv editingStyleForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return UITableViewCellEditingStyleNone;
    return %orig;
}
- (BOOL)tableView:(UITableView *)tv shouldHighlightRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return YES;
    return %orig;
}
- (NSIndexPath *)tableView:(UITableView *)tv willSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return ip;
    return %orig;
}
- (id)tableView:(UITableView *)tv trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return nil;
    return %orig;
}
- (id)tableView:(UITableView *)tv leadingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return nil;
    return %orig;
}

%end

%hook WCTableViewManager
// 注入逻辑：仅当本数据源实例被打上 npc_isSettingsInfo 标记（即设置页表格）时生效。
// 所有 section/row 索引相关方法对“我的分区”都返回安全值，避免越界崩溃。
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv {
    NSInteger orig = %orig;
    if (objc_getAssociatedObject(self, "npc_isSettingsInfo")) {
        objc_setAssociatedObject(self, "npc_origSections", @(orig), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return orig + 1;
    }
    return orig;
}
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 1;
    return %orig;
}
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return npc_makeEntryCell();
    return %orig;
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        npc_openPluginSettings(npc_ownerVC(tv));
        return;
    }
    %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return 56;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv estimatedHeightForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return 56;
    return %orig;
}
- (void)tableView:(UITableView *)tv willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) { cell.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor]; return; }
    %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv estimatedHeightForHeaderInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (CGFloat)tableView:(UITableView *)tv heightForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return 0;
    return %orig;
}
- (UIView *)tableView:(UITableView *)tv viewForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)section {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && section == n.integerValue) return nil;
    return %orig;
}
- (BOOL)tableView:(UITableView *)tv canEditRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return NO;
    return %orig;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tv editingStyleForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return UITableViewCellEditingStyleNone;
    return %orig;
}
- (BOOL)tableView:(UITableView *)tv shouldHighlightRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return YES;
    return %orig;
}
- (NSIndexPath *)tableView:(UITableView *)tv willSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return ip;
    return %orig;
}
- (id)tableView:(UITableView *)tv trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return nil;
    return %orig;
}
- (id)tableView:(UITableView *)tv leadingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)ip {
    NSNumber *n = objc_getAssociatedObject(self, "npc_origSections");
    if (n && ip.section == n.integerValue && ip.row == 0) return nil;
    return %orig;
}

%end

#pragma mark - 启动初始化

// 构造函数：在 dylib 加载时执行（晚于 +load）。使用较低 priority 编号使其尽早运行。
__attribute__((constructor(50)))
static void diylibEntry(void) {
    @autoreleasepool {
        // 1) 最先写诊断标记（只要镜像被加载就一定执行），随后可读 npc_loaded.txt 确认。
        npc_writeDiag();
        DPLogInfo(@"diylib v26.0.6 (NPC) by yZFAIU loaded into WeChat");
        DPLogInfo(@"yZFAIU 插件已加载");
        // 2) 探测 hooking substrate 是否可用（用 MSHookFunction：真正的 substrate 才导出，
        //    本 dylib 自带的 MSHookMessageEx shim 不导出它，故可区分“真 substrate”与“自身 shim”）。
        void *h = dlopen(NULL, RTLD_NOW);
        BOOL subOK = (h && dlsym(h, "MSHookFunction") != NULL);
        NSString *toast = subOK ? @"yZFAIU 插件已加载" : @"yZFAIU 已加载（substrate 缺失？）";
        // 3) 启动后约 1.5s 用带重试的计时器弹 toast（不依赖 becomeActive 时机）。
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            npc_showToast(toast);
        });
        [DPConfig migrateDefaults];
        if (![DPConfig boolForSwitchKey:kSwitchEnabled]) {
            DPLogInfo(@"diylib 总开关关闭，仅注入设置入口");
            return;
        }
        [[DPMessageDispatcher shared] install];
        DPLogInfo(@"19 个功能模块就绪（12 原功能 + 7 新增参考 MiYou），AddMsg 分发器已安装");
    }
}
